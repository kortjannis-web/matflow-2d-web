"""Zeichnet die Anlage (Editor) bzw. den Simulationszustand auf die Zeichenfläche."""
from __future__ import annotations

import math

import pygame

from matflow.core.geometry import center, dist
from matflow.model.components import CONVEYOR, LIFT, STATIC
from matflow.model.layout import Layout
from matflow.sim.engine import Engine
from matflow.sim.entities import C_LABELS, KIND_LABELS, CState, Container, Epb, EpbState, Rbg, RbgState
from matflow.ui import render
from matflow.ui import theme as T
from matflow.ui.camera import Camera


def draw_label(surf, cam: Camera, text: str, x: float, y: float, dim: bool = False) -> None:
    s = T.text_surface(text, 11 if cam.zoom < 40 else 12, (255, 255, 255))
    sx, sy = cam.w2s(x, y)
    r = s.get_rect(midbottom=(round(sx), round(sy) - 2))
    bg = r.inflate(8, 2)
    pygame.draw.rect(surf, (84, 98, 118) if dim else T.BADGE, bg, border_radius=4)
    surf.blit(s, r)


def draw_static(surf, cam: Camera, lay: Layout, level: int, ghost_levels: bool, show_prefill: bool) -> None:
    x0, y0, x1, y1 = cam.visible_cells()

    def visible(c) -> bool:
        return x0 - 1 <= c.x <= x1 and y0 - 1 <= c.y <= y1

    if ghost_levels:
        for c in lay.static.values():
            if c.level != level and visible(c):
                render.draw_component_cached(surf, cam, c, lay, ghost=True, show_prefill=False, show_text=False)
    # Höhenraum der Heber auf dieser Ebene
    for c in lay.static.values():
        if c.type == LIFT and c.level != level and visible(c):
            lo, hi = sorted((c.level, c.target_level))
            if lo <= level <= hi:
                render.draw_lift_shadow(surf, cam, c)
    for c in lay.static.values():
        if c.level == level and visible(c):
            render.draw_component_cached(surf, cam, c, lay, show_prefill=show_prefill)


def conveyor_cells(lay: Layout, level: int) -> dict[tuple[int, int], tuple]:
    """Förderzellen der Ebene mit vorberechneten offenen Seiten (für laufende Rollen in der Simulation)."""
    out = {}
    for c in lay.static.values():
        if c.level == level and c.type == CONVEYOR:
            out[(c.x, c.y)] = (c, frozenset(render.open_sides(c, lay)))
    return out


def draw_edit_vehicles(surf, cam: Camera, lay: Layout, level: int, ghost_levels: bool) -> None:
    for c in lay.vehicles.values():
        if c.level == level:
            render.draw_component(surf, cam, c, lay)
        elif ghost_levels:
            render.draw_component(surf, cam, c, lay, ghost=True)


def draw_labels(surf, cam: Camera, lay: Layout, level: int, show_all: bool, vehicles: bool = True) -> None:
    if cam.zoom < 16:
        return
    for c in lay.by_id.values():
        if c.level != level or (not vehicles and c.spec.layer != STATIC):
            continue
        if c.label or (show_all and cam.zoom >= 30):
            cx, cy = center(c.cell)
            off = 0.5 if c.spec.layer == STATIC else 0.2
            draw_label(surf, cam, c.display_name, cx, cy - off, dim=not c.label)


def draw_issue_cells(surf, cam: Camera, cells_err: set, cells_warn: set, level: int) -> None:
    for cells, col in ((cells_warn, T.WARN_CELL), (cells_err, T.ERROR_CELL)):
        for c in cells:
            if c[2] != level:
                continue
            r = cam.cell_rect(c[0], c[1]).inflate(-2, -2)
            pygame.draw.rect(surf, col, r, 2, border_radius=2)


# ---------------------------------------------------------------------- Simulation
def container_level(c: Container) -> int:
    if isinstance(c.carrier, Epb):
        return c.carrier.track.level
    if isinstance(c.carrier, Rbg):
        return c.carrier.level
    if c.state in (CState.ON_CONVEYOR, CState.ON_LIFT, CState.WAITING_FOR_EPB, CState.WAITING_FOR_RBG,
                   CState.BLOCKED) and c.nodes:
        return c.nodes[min(c.seg, len(c.nodes) - 1)][2]
    return int(round(c.z))


RBG_TRANSFERS = ("to_storage", "to_rbg", "from_storage", "from_rbg")

# Fahrzeugzustände (deutsch) und Status-LED: fährt / wartet / lädt / frei
EPB_STATE_DE = {
    EpbState.IDLE: "frei", EpbState.MOVING_TO_PICKUP: "fährt zur Aufnahme",
    EpbState.WAITING_FOR_CONTAINER: "wartet auf Behälter", EpbState.LOADING: "lädt",
    EpbState.TRANSPORTING: "transportiert", EpbState.UNLOADING: "gibt ab",
}
RBG_STATE_DE = {
    RbgState.IDLE: "frei", RbgState.MOVING_TO_PICKUP: "fährt zur Aufnahme",
    RbgState.WAITING_FOR_CONTAINER: "wartet auf Behälter", RbgState.LOADING: "lädt",
    RbgState.MOVING_TO_STORAGE: "fährt zum Lagerplatz", RbgState.STORING: "lagert ein",
    RbgState.MOVING_TO_RETRIEVE: "fährt zur Auslagerung", RbgState.RETRIEVING: "lagert aus",
    RbgState.MOVING_TO_DROP: "fährt zur Abgabe", RbgState.DROPPING: "gibt ab",
}
_EPB_LOAD = {EpbState.LOADING, EpbState.UNLOADING}
_RBG_LOAD = {RbgState.LOADING, RbgState.STORING, RbgState.RETRIEVING, RbgState.DROPPING}
LED_LABELS = (("fährt", T.LED_MOVE), ("wartet", T.LED_WAIT), ("lädt / gibt ab", T.LED_LOAD), ("frei", T.LED_IDLE))


def state_text(v) -> str:
    if isinstance(v, Epb):
        return EPB_STATE_DE.get(v.state, v.state.value)
    return RBG_STATE_DE.get(v.state, v.state.value)


def vehicle_led(v):
    """LED-Farbe eines Fahrzeugs: lädt/gibt ab (blau), fährt (grün), wartet (gelb), frei (grau)."""
    if v.state in (_EPB_LOAD if isinstance(v, Epb) else _RBG_LOAD):
        return T.LED_LOAD
    if v.moved > 0:
        return T.LED_MOVE
    if v.state in (EpbState.IDLE, RbgState.IDLE):
        return T.LED_IDLE
    return T.LED_WAIT


class SimFx:
    """Darstellungszustand der Simulation: Rollenphase, laufende Förderzellen, Übergabe-Blitze.

    Reine Anzeige, liest die Engine nur (außer dem Leeren ihres Übergabe-Puffers).
    """
    MAX_FLASHES = 48

    def __init__(self):
        self.engine: Engine | None = None
        self.phase = 0.0
        self.prev: dict[int, tuple[float, float]] = {}
        self.flashes: list[list] = []         # [x, y, Ebene, Alter in s]
        self.levels: dict[int, tuple[int, int]] = {}

    def sync(self, eng: Engine, dt: float, speed: float, running: bool) -> None:
        if eng is not self.engine:
            self.engine = eng
            self.phase = 0.0
            self.prev = {}
            self.flashes = []
            self.levels = {}
            eng.fx.clear()
        if running:
            # Echtzeit-Phase (bei hoher Simulationsgeschwindigkeit gedeckelt, sonst Stroboskop-Effekt)
            v = eng.params.conveyor_speed * render.ROLLERS_PER_M
            self.phase = (self.phase + dt * min(speed, 2.0) * v) % 1.0
        for f in self.flashes:
            f[3] += dt
        self.flashes = [f for f in self.flashes if f[3] < render.FLASH_T]
        while eng.fx:
            pos, veh = eng.fx.popleft()
            lv = veh.track.level if isinstance(veh, Epb) else veh.level
            self.flashes.append([pos[0], pos[1], lv, 0.0])
        if len(self.flashes) > self.MAX_FLASHES:
            self.flashes = self.flashes[-self.MAX_FLASHES:]

    def rbg_height(self, r: Rbg) -> float | None:
        span = self.levels.get(r.system.id)
        if span is None:
            lv = r.system.levels
            span = (lv[0], lv[-1])
            self.levels[r.system.id] = span
        lo, hi = span
        return None if hi <= lo else (r.z - lo) / (hi - lo)


def draw_sim(surf, cam: Camera, eng: Engine, level: int, ghost_levels: bool, show_labels: bool,
             highlight: object | None, fx: SimFx | None = None, anim_cells: dict | None = None) -> None:
    # Laufende Rollen unter bewegten Behältern
    if fx is not None:
        prev, new_prev, moving = fx.prev, {}, set()
        for c in eng.containers:
            if c.state is not CState.ON_CONVEYOR or c.carrier is not None or c.pos is None:
                continue
            p = c.pos
            new_prev[id(c)] = p
            q = prev.get(id(c))
            if q is not None and q != p and anim_cells and container_level(c) == level:
                x, y = p
                for cx in {math.floor(x - 0.24), math.floor(x + 0.24)}:
                    for cy in {math.floor(y - 0.24), math.floor(y + 0.24)}:
                        moving.add((cx, cy))
        fx.prev = new_prev
        if moving:
            idx = int(fx.phase * render.ROLLER_PHASES) % render.ROLLER_PHASES
            for cell in moving:
                hit = anim_cells.get(cell)
                if hit is not None:
                    comp, opens = hit
                    surf.blit(render.conveyor_tile(cam, comp, opens, idx), cam.cell_rect(comp.x, comp.y))
    # Lagerplatz-Reservierung (Einlagerung gelb, Auslagerauftrag türkis)
    for sp in eng.storages.values():
        comp = sp.info.comp
        if comp.level == level and (sp.reserved or sp.retrieving):
            r = cam.cell_rect(comp.x, comp.y).inflate(-4, -4)
            pygame.draw.rect(surf, T.STORAGE_RESERVED if sp.reserved else T.CONTAINER_OUT, r, 2)
    # Behälter auf Förderer / Übergaben / eingelagert
    for c in eng.containers:
        if c.pos is None or c.carrier is not None:
            continue
        if c.transfer is not None and c.transfer.kind in RBG_TRANSFERS:
            continue
        lv = container_level(c)
        ghost = lv != level
        if ghost and (not ghost_levels or c.state == CState.STORED):
            continue                    # Lagerbestand anderer Ebenen nicht einblenden (wirkt sonst wie belegt)
        scale = 1.0
        if c.state == CState.ON_LIFT or (c.nodes and not ghost and abs(c.z - lv) > 1e-3):
            scale = 1.0 + 0.35 * min(1.0, abs(c.z - lv))
        render.draw_container(surf, cam, c.pos[0], c.pos[1], prefilled=c.prefilled, ghost=ghost, scale=scale,
                              highlight=highlight is c, kind=c.kind, shadow=c.state != CState.STORED)
    # EPBs
    for e in eng.epbs:
        ghost = e.track.level != level
        if ghost and not ghost_levels:
            continue
        x, y, h = e.track.pos(e.s)
        render.draw_epb(surf, cam, x, y, h, ghost=ghost, highlight=highlight is e,
                        led=None if ghost else vehicle_led(e))
        if e.container is not None and e.container.carrier is e:
            render.draw_container(surf, cam, x, y, ghost=ghost, highlight=highlight is e.container,
                                  prefilled=e.container.prefilled, kind=e.container.kind, shadow=False)
    # RBGs
    for r in eng.rbgs:
        ghost = r.level != level
        if ghost and level in r.system.levels:
            # Mast steht auf allen Ebenen der Gasse, der Hubwagen ist auf einer anderen Ebene
            render.draw_rbg_mast(surf, cam, r.xy[0], r.xy[1], r.system.axis, r.level, level)
            continue
        if ghost and not ghost_levels:
            continue
        x, y = r.xy
        # Behälter, der gerade eingeschoben/aufgenommen wird, liegt auf dem Ausleger → erst RBG zeichnen
        render.draw_rbg(surf, cam, x, y, r.system.axis, r.arm, r.arm_side, ghost=ghost, highlight=highlight is r,
                        led=None if ghost else vehicle_led(r),
                        height=fx.rbg_height(r) if fx is not None and not ghost else None)
        if r.container is not None and r.container.carrier is r:
            render.draw_container(surf, cam, x, y, ghost=ghost, highlight=highlight is r.container,
                                  prefilled=r.container.prefilled, kind=r.container.kind, shadow=False)
    for c in eng.containers:
        if c.transfer is not None and c.transfer.kind in RBG_TRANSFERS and container_level(c) == level:
            render.draw_container(surf, cam, c.pos[0], c.pos[1], highlight=highlight is c, prefilled=c.prefilled,
                                  kind=c.kind)
    # Übergabe-Blitze
    if fx is not None:
        for fx_x, fx_y, lv, age in fx.flashes:
            if lv == level:
                render.draw_flash(surf, cam, fx_x, fx_y, age)
    # Wartende Behälter an Quellen
    for s in eng.sources:
        n = len(eng.backlog[s.id])
        if n and s.level == level and cam.zoom >= 14:
            cx, cy = center(s.cell)
            sx, sy = cam.w2s(cx + 0.38, cy - 0.38)
            t = T.text_surface(str(n), 11, (255, 255, 255), True)
            rad = max(9, t.get_width() // 2 + 4)
            pygame.draw.circle(surf, (255, 255, 255), (round(sx), round(sy)), rad + 2)
            pygame.draw.circle(surf, T.DANGER, (round(sx), round(sy)), rad)
            surf.blit(t, t.get_rect(center=(round(sx), round(sy))))
    if show_labels and cam.zoom >= 16:
        for e in eng.epbs:
            if e.track.level == level:
                x, y, _ = e.track.pos(e.s)
                draw_label(surf, cam, e.label, x, y - 0.45)
        for r in eng.rbgs:
            if r.level == level:
                x, y = r.xy
                draw_label(surf, cam, r.label, x, y - 0.5)


def pick_entity(eng: Engine, level: int, wx: float, wy: float):
    """Objekt unter dem Mauszeiger (Behälter vor Fahrzeug)."""
    best, bd = None, 0.45
    for c in eng.containers:
        if c.pos is None or container_level(c) != level:
            continue
        d = dist(c.pos, (wx, wy))
        if d < min(bd, 0.3):
            best, bd = c, d
    if best is not None:
        return best
    for e in eng.epbs:
        if e.track.level == level:
            x, y, _ = e.track.pos(e.s)
            d = dist((x, y), (wx, wy))
            if d < bd:
                best, bd = e, d
    for r in eng.rbgs:
        if r.level == level:
            d = dist(r.xy, (wx, wy))
            if d < bd:
                best, bd = r, d
    return best


def describe_entity(eng: Engine, ent) -> str:
    if isinstance(ent, Container):
        lines = [f"Behälter {ent.id}", f"Zustand: {C_LABELS.get(ent.state, ent.state.value)} ({ent.state.value})",
                 f"Art: {KIND_LABELS.get(ent.kind, ent.kind)}"]
        if ent.prefilled:
            lines.append("vorbelegt (Startbestand)")
        else:
            src = eng.layout.get(ent.source_id)
            lines.append(f"Quelle: {src.display_name if src else ent.source_id}")
            lines.append(f"Erzeugt: {ent.created_t:.1f} s")
        if ent.storage_id:
            lines.append(f"Lagerplatz: {ent.storage_id}")
        if ent.route:
            lines.append("Weg: " + " → ".join(ent.route.describe(eng.topo)))
        return "\n".join(lines)
    if isinstance(ent, Epb):
        lines = [f"EPB {ent.label}", f"Zustand: {state_text(ent)}",
                 f"Transporte: {ent.stats.jobs}", f"Auslastung: {100 * ent.stats.busy / max(eng.time, 1e-9):.0f} %"]
        if ent.request is not None:
            lines.append(f"Auftrag: {ent.request.container.id}")
        return "\n".join(lines)
    if isinstance(ent, Rbg):
        lines = [f"RBG {ent.label}", f"Zustand: {state_text(ent)}", f"Hubwagen auf Ebene E{ent.z:.1f}".replace(".", ","),
                 f"Einlagerungen: {ent.stats.jobs}",
                 f"Auslagerungen: {ent.stats.retrievals}",
                 f"Auslastung: {100 * ent.stats.busy / max(eng.time, 1e-9):.0f} %"]
        if ent.storage is not None:
            lines.append(f"Lagerplatz: {ent.storage.id}")
        if ent.drop is not None:
            lines.append(f"Abgabe: {eng.layout.static[ent.drop.flow_cell].id}")
        return "\n".join(lines)
    return ""
