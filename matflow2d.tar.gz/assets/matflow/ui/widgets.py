"""Kleines Immediate-Mode-UI für pygame: Buttons, Eingabefelder, Checkboxen, Texte.

Ablauf pro Frame: ui.begin(events) → Widgets zeichnen/abfragen → ui.end().
"""
from __future__ import annotations

from dataclasses import dataclass

import pygame

from matflow.ui import icons
from matflow.ui import theme as T


@dataclass
class Tooltip:
    text: str
    pos: tuple[int, int]


class UI:
    def __init__(self, screen: pygame.Surface):
        self.screen = screen
        self.mouse = (0, 0)
        self.down = False            # linke Maustaste in diesem Frame gedrückt
        self.up = False
        self.held = False
        self.wheel = 0
        self.focus: str | None = None
        self.buffer = ""
        self.focus_rect: pygame.Rect | None = None
        self.commit: tuple[str, str] | None = None
        self.consumed = False        # Klick wurde von einem Widget verarbeitet
        self.keys: list[pygame.event.Event] = []
        self.clip: pygame.Rect | None = None
        self.tooltip: Tooltip | None = None
        self.cursor = 0
        self.fresh = False           # Inhalt markiert: erste Eingabe ersetzt ihn
        self._blink = 0
        self.modal_active = False    # Modaldialog offen → nur Modal-Widgets reagieren
        self.in_modal = False

    # ------------------------------------------------------------------ Frame
    def begin(self, events: list[pygame.event.Event]) -> None:
        self.mouse = pygame.mouse.get_pos()
        for ev in events:
            if ev.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
                self.mouse = ev.pos
        self.down = self.up = False
        self.wheel = 0
        self.consumed = False
        self.keys = []
        self.tooltip = None
        self._blink = (self._blink + 1) % 60
        for ev in events:
            if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                self.down = True
                self.held = True
                if self.focus and self.focus_rect and not self.focus_rect.collidepoint(ev.pos):
                    self._commit_focus()
            elif ev.type == pygame.MOUSEBUTTONUP and ev.button == 1:
                self.up = True
                self.held = False
            elif ev.type == pygame.MOUSEWHEEL:
                self.wheel += ev.y
            elif ev.type in (pygame.KEYDOWN, pygame.TEXTINPUT) and self.focus:
                self.keys.append(ev)

    def end(self) -> None:
        self.commit = None
        if self.tooltip:
            self._draw_tooltip(self.tooltip)

    @property
    def typing(self) -> bool:
        return self.focus is not None

    def _commit_focus(self) -> None:
        if self.focus:
            self.commit = (self.focus, self.buffer)
        self.focus = None
        self.focus_rect = None
        pygame.key.stop_text_input()

    def unfocus(self) -> None:
        self._commit_focus()

    def hit(self, rect: pygame.Rect) -> bool:
        if self.modal_active and not self.in_modal:
            return False
        if self.clip is not None and not self.clip.collidepoint(self.mouse):
            return False
        return rect.collidepoint(self.mouse)

    # ------------------------------------------------------------------ Zeichnen
    def text(self, s: str, pos: tuple[int, int], size: int = 14, color=T.TEXT, bold: bool = False,
             anchor: str = "topleft", max_w: int | None = None) -> pygame.Rect:
        surf = T.text_surface(s, size, color, bold)
        if max_w is not None and surf.get_width() > max_w:
            f = T.font_for(s, size, bold)
            while s and f.size(s + "…")[0] > max_w:
                s = s[:-1]
            surf = T.text_surface(s + "…", size, color, bold)
        r = surf.get_rect(**{anchor: pos})
        self.screen.blit(surf, r)
        return r

    def button(self, rect: pygame.Rect, label: str, active: bool = False, enabled: bool = True,
               dark: bool = False, tooltip: str | None = None, size: int = 13, color=None,
               bold: bool = False, icon: str | None = None) -> bool:
        hov = enabled and self.hit(rect)
        if dark:
            bg = T.ACCENT if active else (T.BTN_DARK_HOVER if hov else T.BTN_DARK)
            fg = (255, 255, 255) if enabled else (130, 140, 155)
            border = None
        else:
            bg = T.ACCENT_SOFT if active else (T.BTN_HOVER if hov else T.BTN)
            fg = (T.ACCENT if active else T.TEXT) if enabled else T.TEXT_DIM
            border = T.ACCENT if active else T.BTN_BORDER
        if color is not None and enabled:
            bg = color if not hov else tuple(min(255, c + 18) for c in color)
            fg = (255, 255, 255)
            border = None
        pygame.draw.rect(self.screen, bg, rect, border_radius=7)
        if border:
            pygame.draw.rect(self.screen, border, rect, 1, border_radius=7)
        if icon:
            isz = 16 if rect.h >= 26 else 14
            ic = icons.get(icon, isz, tuple(fg))
            if label:
                tw = min(T.text_surface(label, size, fg, bold).get_width(), rect.w - isz - 18)
                x0 = rect.centerx - (isz + 6 + tw) // 2
                self.screen.blit(ic, (x0, rect.centery - isz // 2))
                self.text(label, (x0 + isz + 6, rect.centery), size, fg, bold=bold, anchor="midleft",
                          max_w=rect.w - isz - 18)
            else:
                self.screen.blit(ic, (rect.centerx - isz // 2, rect.centery - isz // 2))
        else:
            self.text(label, rect.center, size, fg, bold=bold, anchor="center", max_w=rect.w - 8)
        if hov and tooltip:
            self.tooltip = Tooltip(tooltip, (self.mouse[0] + 14, self.mouse[1] + 18))
        if hov and self.down:
            self.consumed = True
            return True
        return False

    def checkbox(self, rect: pygame.Rect, label: str, value: bool) -> bool | None:
        box = pygame.Rect(rect.x, rect.centery - 8, 16, 16)
        hov = self.hit(rect)
        pygame.draw.rect(self.screen, T.INPUT_BG, box, border_radius=3)
        pygame.draw.rect(self.screen, T.ACCENT if (value or hov) else T.BTN_BORDER, box, 2, border_radius=3)
        if value:
            pygame.draw.lines(self.screen, T.ACCENT, False,
                              [(box.x + 3, box.centery), (box.x + 7, box.bottom - 4), (box.right - 3, box.y + 3)], 3)
        self.text(label, (box.right + 8, rect.centery), 13, T.TEXT, anchor="midleft")
        if hov and self.down:
            self.consumed = True
            return not value
        return None

    def input(self, wid: str, rect: pygame.Rect, value: str, numeric: bool = True) -> str | None:
        """Eingabefeld. Liefert den neuen Text beim Bestätigen (Enter / Klick daneben), sonst None."""
        result = None
        if self.commit and self.commit[0] == wid:
            result = self.commit[1]
            self.commit = None
        focused = self.focus == wid
        hov = self.hit(rect)
        if hov and self.down and not focused:
            if self.focus:
                self._commit_focus()
                if self.commit and self.commit[0] == wid:
                    self.commit = None
            self.focus = wid
            self.buffer = value
            self.cursor = len(value)
            self.fresh = True
            self.focus_rect = rect.copy()
            focused = True
            self.consumed = True
            pygame.key.start_text_input()
        if focused:
            self.focus_rect = rect.copy()
            for ev in self.keys:
                if ev.type == pygame.TEXTINPUT:
                    ch = ev.text
                    if numeric and not all(c in "0123456789.,-" for c in ch):
                        continue
                    if self.fresh:
                        self.buffer, self.cursor, self.fresh = "", 0, False
                    self.buffer = self.buffer[:self.cursor] + ch + self.buffer[self.cursor:]
                    self.cursor += len(ch)
                elif ev.type == pygame.KEYDOWN:
                    if ev.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_TAB):
                        result = self.buffer
                        self.focus = None
                        self.focus_rect = None
                        pygame.key.stop_text_input()
                        focused = False
                        break
                    if ev.key == pygame.K_ESCAPE:
                        self.focus = None
                        self.focus_rect = None
                        pygame.key.stop_text_input()
                        focused = False
                        break
                    if ev.key in (pygame.K_BACKSPACE, pygame.K_DELETE) and self.fresh:
                        self.buffer, self.cursor, self.fresh = "", 0, False
                        continue
                    if ev.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_HOME, pygame.K_END):
                        self.fresh = False
                    if ev.key == pygame.K_BACKSPACE and self.cursor > 0:
                        self.buffer = self.buffer[:self.cursor - 1] + self.buffer[self.cursor:]
                        self.cursor -= 1
                    elif ev.key == pygame.K_DELETE:
                        self.buffer = self.buffer[:self.cursor] + self.buffer[self.cursor + 1:]
                    elif ev.key == pygame.K_LEFT:
                        self.cursor = max(0, self.cursor - 1)
                    elif ev.key == pygame.K_RIGHT:
                        self.cursor = min(len(self.buffer), self.cursor + 1)
                    elif ev.key == pygame.K_HOME:
                        self.cursor = 0
                    elif ev.key == pygame.K_END:
                        self.cursor = len(self.buffer)
                    elif ev.key == pygame.K_a and ev.mod & pygame.KMOD_CTRL:
                        self.buffer = ""
                        self.cursor = 0
            self.keys = []
        shown = self.buffer if focused else value
        pygame.draw.rect(self.screen, T.INPUT_BG, rect, border_radius=5)
        pygame.draw.rect(self.screen, T.ACCENT if focused else (T.ACCENT if hov else T.BTN_BORDER), rect,
                         2 if focused else 1, border_radius=5)
        f = T.font(13)
        tx = rect.x + 7
        surf = f.render(shown, True, T.TEXT)
        old = self.screen.get_clip()
        inner = rect.inflate(-4, -2)
        self.screen.set_clip(inner.clip(old) if old else inner)
        if focused and self.fresh and shown:
            sel = pygame.Rect(tx - 2, rect.y + 5, surf.get_width() + 4, rect.h - 10)
            pygame.draw.rect(self.screen, T.ACCENT_SOFT, sel, border_radius=3)
        self.screen.blit(surf, (tx, rect.centery - surf.get_height() // 2))
        if focused and self._blink < 34:
            cx = tx + f.size(shown[:self.cursor])[0]
            pygame.draw.line(self.screen, T.TEXT, (cx, rect.y + 5), (cx, rect.bottom - 5), 1)
        self.screen.set_clip(old)
        return result

    def section(self, y: int, x: int, w: int, title: str) -> int:
        pygame.draw.rect(self.screen, T.ACCENT, (x, y + 2, 3, 12), border_radius=1)
        self.text(title.upper(), (x + 9, y), 11, T.SECTION, bold=True)
        pygame.draw.line(self.screen, T.PANEL_BORDER, (x, y + 20), (x + w, y + 20))
        return y + 28

    def _draw_tooltip(self, tip: Tooltip) -> None:
        lines = tip.text.split("\n")
        f = T.font(12)
        w = max(f.size(l)[0] for l in lines) + 16
        h = len(lines) * 17 + 10
        sw, sh = self.screen.get_size()
        x = min(tip.pos[0], sw - w - 4)
        y = min(tip.pos[1], sh - h - 4)
        r = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, T.BADGE, r, border_radius=7)
        for i, l in enumerate(lines):
            self.screen.blit(T.text_surface(l, 12, (240, 244, 250)), (x + 8, y + 5 + i * 17))


def parse_float(s: str) -> float | None:
    try:
        return float(s.replace(",", ".").strip())
    except ValueError:
        return None
