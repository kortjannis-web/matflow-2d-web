"""Obere Leiste, linke Palette, rechter Einstellungs-/Statistikbereich, Statuszeile, Modaldialog."""
from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

import pygame

from matflow.core.geometry import DIR_NAMES
from matflow.model.components import (
    BRANCH_NAMES, CONVEYOR, CONVEYOR_SWITCH, EPB, EPB_CURVE, EPB_RAIL, EPB_SWITCH, LIFT, NIO, RBG, RBG_RAIL, SINK, SOURCE, STORAGE, TYPES,
)
from matflow.model.params import DISTANCE_FIELDS, FLOW_FIELDS, SIM_FIELDS, SPEED_FIELDS, STRATEGY_FIELDS
from matflow.sim.statistics import fmt_time, snapshot
from matflow.sim.topology import ERROR
import time

from matflow.ui import canvas, icons, render
from matflow.ui import theme as T
from matflow.ui.editor import ERASE_TOOL, TOOLS
from matflow.ui.settings import ERASE_MAX, VIEW_BOOL_FIELDS, VIEW_NUMBER_FIELDS
from matflow.ui.widgets import Tooltip, parse_float

if TYPE_CHECKING:
    from matflow.ui.app import App

SPEEDS = [0.5, 1.0, 1.5, 2.0, 5.0, 10.0, 20.0, 50.0]
_icons: dict[str, pygame.Surface] = {}


def icon(key: str) -> pygame.Surface:
    if key not in _icons:
        if key == "select":
            s = pygame.Surface((30, 30), pygame.SRCALPHA)
            pygame.draw.polygon(s, T.TEXT, [(9, 5), (9, 24), (14, 19), (18, 27), (21, 26), (17, 18), (24, 18)])
        elif key == "erase":
            s = pygame.Surface((30, 30), pygame.SRCALPHA)
            pygame.draw.polygon(s, (236, 110, 110), [(6, 18), (16, 8), (25, 17), (15, 27)])
            pygame.draw.polygon(s, (120, 40, 40), [(6, 18), (16, 8), (25, 17), (15, 27)], 2)
        else:
            s = render.icon(key, 30)
        _icons[key] = s
    return _icons[key]


@lru_cache(maxsize=512)
def wrap(text: str, size: int, width: int) -> list[str]:
    f = T.font(size)
    out, cur = [], ""
    for word in text.split(" "):
        test = (cur + " " + word).strip()
        if f.size(test)[0] <= width:
            cur = test
        else:
            if cur:
                out.append(cur)
            cur = word
    if cur:
        out.append(cur)
    return out or [""]


# ============================================================================ Oben
def draw_topbar(app: "App") -> None:
    ui, scr = app.ui, app.screen
    w = scr.get_width()
    bar = pygame.Rect(0, 0, w, T.TOP_H)
    scr.fill(T.TOPBAR, bar)
    # Logo: kleines Förderband-Symbol + Name
    pygame.draw.rect(scr, T.ACCENT, (14, 13, 24, 24), border_radius=6)
    scr.blit(icons.get("sim", 16, (255, 255, 255)), (18, 17))
    ui.text("MatFlow 2D", (46, T.TOP_H // 2), 17, (255, 255, 255), bold=True, anchor="midleft")
    x = 150
    y, h = 9, T.TOP_H - 18
    # Modus als Segmentschalter
    seg = pygame.Rect(x - 3, y - 3, 118 + 112 + 10, h + 6)
    pygame.draw.rect(scr, (9, 13, 22), seg, border_radius=9)
    if ui.button(pygame.Rect(x, y, 118, h), "Konstruktion", active=app.mode == "edit", dark=True,
                 tooltip="Anlage bearbeiten", icon="edit"):
        app.back_to_edit()
    x += 122
    if ui.button(pygame.Rect(x, y, 112, h), "Simulation", active=app.mode == "sim", dark=True,
                 tooltip="Layout prüfen und in den Simulationsmodus wechseln (F5)", icon="play"):
        app.enter_sim()
    x += 128
    edit = app.mode == "edit"
    for label, ic, fn, tip, wdt in (
        ("Neu", "new", app.cmd_new, "Neue leere Anlage (Strg+N)", 64),
        ("Öffnen", "open", app.cmd_open, "Projekt öffnen (Strg+O)", 82),
        ("Speichern", "save", app.cmd_save, "Projekt speichern (Strg+S)", 102),
        ("", "save_as", app.cmd_save_as, "Speichern unter: Projekt unter neuem Namen speichern (Strg+Umschalt+S)", 34),
        ("Beispiel", "example", app.cmd_example, "Beispielanlage laden (nur Testfall, frei veränderbar)", 90),
        ("Beispiel 2", "example2", app.cmd_example_demo,
         "Beispiel mit Auslagerung, NIO-Anteil und Weichen im Dauerbetrieb (60 min)", 104),
    ):
        if ui.button(pygame.Rect(x, y, wdt, h), label, dark=True, tooltip=tip, icon=ic,
                     enabled=edit or ic in ("save", "save_as")):
            fn()
        x += wdt + 4
    x += 8
    if ui.button(pygame.Rect(x, y, 34, h), "", dark=True, enabled=edit and bool(app.editor.undo_stack),
                 tooltip="Rückgängig (Strg+Z)", icon="undo"):
        app.editor.undo()
    x += 38
    if ui.button(pygame.Rect(x, y, 34, h), "", dark=True, enabled=edit and bool(app.editor.redo_stack),
                 tooltip="Wiederholen (Strg+Y)", icon="redo"):
        app.editor.redo()
    x += 48
    # Ebenen
    scr.blit(icons.get("layers", 16, T.TOPBAR_DIM), (x, T.TOP_H // 2 - 8))
    x += 22
    if ui.button(pygame.Rect(x, y, 28, h), "", dark=True, enabled=app.level > 0, tooltip="Ebene tiefer (Bild ab)",
                 icon="prev"):
        app.set_level(app.level - 1)
    x += 30
    pygame.draw.rect(scr, (9, 13, 22), (x, y, 66, h), border_radius=7)
    ui.text(f"E{app.level}  / {app.layout.levels}", (x + 33, T.TOP_H // 2), 13, (255, 255, 255), bold=True,
            anchor="center")
    x += 68
    if ui.button(pygame.Rect(x, y, 28, h), "", dark=True, enabled=app.level < app.layout.levels - 1,
                 tooltip="Ebene höher (Bild auf)", icon="next"):
        app.set_level(app.level + 1)
    x += 30
    if ui.button(pygame.Rect(x, y, 28, h), "", dark=True, enabled=edit, tooltip="Neue Ebene hinzufügen", icon="plus"):
        app.add_level()
    x += 40
    name = app.layout.name + (" *" if app.dirty else "")
    if w - x > 120:
        ui.text(name, (w - 16, T.TOP_H // 2), 13, T.TOPBAR_DIM, anchor="midright", max_w=w - x - 30)


# ============================================================================ Links
def draw_left(app: "App") -> None:
    ui, scr = app.ui, app.screen
    rect = app.left_rect
    scr.fill(T.PANEL, rect)
    pygame.draw.line(scr, T.PANEL_BORDER, rect.topright, rect.bottomright)
    x, y, w = rect.x + 12, rect.y + 12, rect.w - 24
    if app.mode == "edit":
        y = ui.section(y, x, w, "Komponenten")
        rh = 31
        for t in TOOLS:
            r = pygame.Rect(x - 4, y, w + 8, rh - 2)
            active = app.editor.tool == t.key
            hov = ui.hit(r) and t.enabled
            if active:
                pygame.draw.rect(scr, T.ACCENT_SOFT, r, border_radius=7)
                pygame.draw.rect(scr, T.ACCENT, r, 1, border_radius=7)
            elif hov:
                pygame.draw.rect(scr, T.BTN_HOVER, r, border_radius=7)
            ic = icon(t.key)
            if not t.enabled:
                ic = ic.copy()
                ic.set_alpha(90)
            scr.blit(ic, (r.x + 6, r.y + (r.h - ic.get_height()) // 2))
            ui.text(t.name, (r.x + 44, r.centery), 13, T.TEXT if t.enabled else T.TEXT_DIM, anchor="midleft",
                    bold=active)
            ui.text(t.shortcut if t.enabled else "V2", (r.right - 10, r.centery), 12, T.TEXT_DIM, anchor="midright")
            if hov and ui.down:
                ui.consumed = True
                app.editor.set_tool(t.key)
            if hov:
                ui.tooltip = Tooltip(t.hint, (ui.mouse[0] + 14, ui.mouse[1] + 18))
            y += rh
        y += 8
        y = ui.section(y, x, w, "Werkzeug")
        ed = app.editor
        if ed.tool == ERASE_TOOL:
            n = app.settings.erase_size
            ui.text(f"Radiergröße: {n}×{n} Zellen", (x, y), 13)
            y += 22
            bw = (w - 4 * 4) // ERASE_MAX
            for k in range(1, ERASE_MAX + 1):
                if ui.button(pygame.Rect(x + (k - 1) * (bw + 4), y, bw, 28), f"{k}", active=k == n,
                             tooltip=f"{k}×{k} Zellen  ([ und ] ändern)"):
                    app.set_view("erase_size", k)
            y += 38
        else:
            dname = DIR_NAMES[ed.tool_rot]
            if ed.tool == EPB_CURVE:
                dname += " · " + ("B" if ed.tool_flip else "A")
            elif ed.tool == EPB_SWITCH:
                dname += " · " + ("Zusammenf." if ed.tool_flip else "Verzweig.") + " · " + (
                    "links" if ed.tool_mirror else "rechts")
            elif ed.tool == CONVEYOR_SWITCH:
                dname += " · Abzweig " + BRANCH_NAMES[ed.tool_branch]
            ui.text(f"Richtung: {dname}", (x, y), 13, max_w=w)
            y += 22
            bw = (w - 6) // 2
            if ui.button(pygame.Rect(x, y, bw, 28), "Drehen (R)"):
                ed.rotate(1)
            if ui.button(pygame.Rect(x + bw + 6, y, bw, 28), "Umkehren (F)"):
                ed.flip()
            y += 34
            if ed.tool in (EPB_SWITCH, CONVEYOR_SWITCH):
                if ui.button(pygame.Rect(x, y, w, 28), "Abzweig wechseln (M)"):
                    ed.mirror()
                y += 34
            y += 4
        for line in ("Rechte Maustaste: verschieben", "Mausrad: zoomen", "Entf: Auswahl löschen",
                     "Pfeiltasten: Auswahl bewegen", "Strg+C / Strg+V: kopieren", "Strg+A: alles wählen",
                     "F5: Simulation"):
            if y + 18 > rect.bottom:
                break
            ui.text(line, (x, y), 12, T.TEXT_DIM)
            y += 18
    else:
        y = ui.section(y, x, w, "Legende")
        items = [
            (CONVEYOR, "Fördertechnik"), (CONVEYOR_SWITCH, "FT-Weiche"), (LIFT, "Heber"), (SOURCE, "Quelle"), (EPB_RAIL, "EPB-Schiene"),
            (EPB_SWITCH, "EPB-Weiche"), (RBG_RAIL, "RBG-Schiene"), (STORAGE, "Lagerplatz frei"),
            (SINK, "Ausgang"), (NIO, "NIO-Ausgang"), ("container", "Behälter eingelagert"),
            ("box", "Behälter Einlagerung"), ("box_nio", "Behälter NIO"), ("box_out", "Behälter Auslagerung"),
            (EPB, "EPB"), (RBG, "RBG"), ("reserved", "Platz reserviert"),
        ]
        for key, label in items:
            if y > rect.bottom - 29:
                break
            if key == "reserved":
                s = pygame.Surface((30, 30), pygame.SRCALPHA)
                pygame.draw.rect(s, T.STORAGE_FREE, (3, 3, 24, 24))
                pygame.draw.rect(s, T.STORAGE_FRAME, (3, 3, 24, 24), 2)
                pygame.draw.rect(s, T.STORAGE_RESERVED, (6, 6, 18, 18), 2)
            else:
                s = icon(key)
            scr.blit(s, (x, y))
            ui.text(label, (x + 40, y + 15), 13, anchor="midleft")
            y += 29
        y += 6
        if y < rect.bottom - 60:
            # Bedeutung der Status-LEDs (Farbe immer mit Text)
            y = ui.section(y, x, w, "Status-LED")
            cw = w // 2
            for i, (label, col) in enumerate(canvas.LED_LABELS):
                lx, ly = x + (i % 2) * cw, y + (i // 2) * 20
                pygame.draw.circle(scr, (30, 30, 30), (lx + 6, ly + 8), 6)
                pygame.draw.circle(scr, col, (lx + 6, ly + 8), 5)
                ui.text(label, (lx + 17, ly + 8), 12, anchor="midleft", max_w=cw - 20)
            y += 46
        if app.engine is not None and y < rect.bottom - 50:
            y = ui.section(y, x, w, "Fahrzeuge")
            eng = app.engine
            t = max(eng.time, 1e-9)
            for v in list(eng.epbs) + list(eng.rbgs):
                if y > rect.bottom - 34:
                    break
                util = v.stats.busy / t
                pygame.draw.circle(scr, (30, 30, 30), (x + 5, y + 8), 5)
                pygame.draw.circle(scr, canvas.vehicle_led(v), (x + 5, y + 8), 4)
                ui.text(v.label, (x + 15, y), 12, bold=True, max_w=64)
                ui.text(f"{100 * util:.0f} %", (x + w, y), 12, T.TEXT, anchor="topright")
                ui.text(canvas.state_text(v), (x + 15, y + 15), 11, T.TEXT_DIM, max_w=w - 15)
                bar = pygame.Rect(x + 82, y + 6, w - 82 - 40, 4)
                pygame.draw.rect(scr, T.BAR_BG, bar, border_radius=2)
                pygame.draw.rect(scr, T.ACCENT, (bar.x, bar.y, round(bar.w * min(1.0, util)), bar.h), border_radius=2)
                y += 34


# ============================================================================ Rechts
class RightPanel:
    def __init__(self, app: "App"):
        self.app = app
        self.scroll = 0
        self.content_h = 0
        self.details = False            # ausführliche Kennzahlen aufgeklappt
        self._snap: tuple | None = None   # (Engine, Simulationszeit, Echtzeit, Gruppen)

    def snapshot(self, eng, running: bool):
        """Kennzahlen höchstens 5× pro Sekunde neu berechnen; im Stillstand immer den aktuellen Stand."""
        now = time.perf_counter()
        c = self._snap
        if c is not None and c[0] is eng and (c[1] == eng.time or (running and now - c[2] < 0.2)):
            return c[3]
        groups = snapshot(eng)
        self._snap = (eng, eng.time, now, groups)
        return groups

    def draw(self) -> None:
        app, ui, scr = self.app, self.app.ui, self.app.screen
        rect = app.right_rect
        scr.fill(T.PANEL, rect)
        pygame.draw.line(scr, T.PANEL_BORDER, rect.topleft, rect.bottomleft)
        if ui.hit(rect) and ui.wheel:
            self.scroll = max(0, min(max(0, self.content_h - rect.h + 20), self.scroll - ui.wheel * 40))
        old_clip = scr.get_clip()
        scr.set_clip(rect)
        ui.clip = rect
        x, w = rect.x + 16, rect.w - 32
        y0 = rect.y + 14 - self.scroll
        if app.mode == "edit":
            y = self._edit(x, y0, w)
        else:
            y = self._sim(x, y0, w)
        self.content_h = y - y0 + 20
        ui.clip = None
        scr.set_clip(old_clip)
        # Scrollbalken
        if self.content_h > rect.h:
            frac = rect.h / self.content_h
            bh = max(30, int(rect.h * frac))
            by = rect.y + int((rect.h - bh) * (self.scroll / max(1, self.content_h - rect.h + 20)))
            pygame.draw.rect(scr, (200, 206, 216), (rect.right - 6, by, 4, bh), border_radius=2)

    # ------------------------------------------------------------------ Kennzahl-Kacheln
    def _tiles(self, x: int, y: int, w: int, groups) -> int:
        """Wichtigste Kennzahlen als Kacheln. Werte kommen unverändert aus statistics.snapshot."""
        v = {(g, k): val for g, rows in groups for k, val in rows}

        def pct(s: str | None) -> float | None:
            try:
                return float(s.split()[0]) / 100.0 if s and s != "–" else None
            except (ValueError, IndexError):
                return None

        tiles = [
            ("Erzeugt", v.get(("Behälter", "Erzeugt")), None),
            ("Eingelagert", v.get(("Behälter", "Eingelagert")), None),
            ("Im System", v.get(("Behälter", "Im System")), None),
            ("Wartend", v.get(("Behälter", "Wartend")), None),
            ("Ø Durchlaufzeit", v.get(("Behälter", "Ø Durchlaufzeit")), None),
            ("Belegungsgrad", v.get(("Lager", "Belegungsgrad")), pct(v.get(("Lager", "Belegungsgrad")))),
            ("EPB Auslastung Ø", v.get(("EPB", "Auslastung Ø")), pct(v.get(("EPB", "Auslastung Ø")))),
            ("RBG Auslastung Ø", v.get(("RBG", "Auslastung Ø")), pct(v.get(("RBG", "Auslastung Ø")))),
        ]
        if ("Auslagerung", "Aufträge") in v:
            tiles += [("Ausgelagert (RBG)", v.get(("Auslagerung", "ausgelagert (RBG)")), None),
                      ("am Ausgang", v.get(("Auslagerung", "am Ausgang")), None)]
        if ("NIO", "NIO erzeugt") in v:
            tiles += [("NIO erzeugt", v.get(("NIO", "NIO erzeugt")), None),
                      ("am NIO-Ausgang", v.get(("NIO", "am NIO-Ausgang")), None)]
        rej = v.get(("Behälter", "Abgewiesen (kein Platz)"))
        if rej and rej != "0":
            tiles.append(("Abgewiesen", rej, None))
        scr, ui = self.app.screen, self.app.ui
        gap = 8
        tw = (w - gap) // 2
        th = 58
        for i, (label, val, frac) in enumerate(tiles):
            tx = x + (i % 2) * (tw + gap)
            ty = y + (i // 2) * (th + gap)
            r = pygame.Rect(tx, ty, tw, th)
            pygame.draw.rect(scr, T.TILE, r, border_radius=9)
            pygame.draw.rect(scr, T.TILE_BORDER, r, 1, border_radius=9)
            ui.text(label, (tx + 10, ty + 8), 11, T.TEXT_DIM, max_w=tw - 16)
            ui.text(val if val is not None else "–", (tx + 10, ty + 24), 18, T.TEXT, bold=True, max_w=tw - 16)
            if frac is not None:
                bar = pygame.Rect(tx + 10, ty + th - 10, tw - 20, 4)
                pygame.draw.rect(scr, T.BAR_BG, bar, border_radius=2)
                fw = round(bar.w * max(0.0, min(1.0, frac)))
                if fw > 0:
                    pygame.draw.rect(scr, T.ACCENT, (bar.x, bar.y, fw, bar.h), border_radius=2)
        rows = (len(tiles) + 1) // 2
        return y + rows * (th + gap) + 6

    # ------------------------------------------------------------------ Hilfen
    def _param_rows(self, x: int, y: int, w: int, fields, live: bool) -> int:
        app, ui = self.app, self.app.ui
        p = app.layout.params
        for name, label, unit, lo, hi in fields:
            ui.text(label, (x, y + 14), 13, anchor="midleft")
            val = getattr(p, name)
            s = f"{val:g}" if isinstance(val, float) else str(val)
            res = ui.input(f"p_{name}", pygame.Rect(x + w - 140, y, 90, 28), s)
            ui.text(unit, (x + w - 44, y + 14), 12, T.TEXT_DIM, anchor="midleft")
            if res is not None:
                v = parse_float(res)
                if v is None:
                    app.status(f"{label}: ungültiger Wert")
                else:
                    v = max(lo, min(hi, v))
                    if isinstance(val, int) and not isinstance(val, bool):
                        v = int(v)
                    if v != val:
                        app.set_param(name, v)
            y += 34
        return y

    def _strategy_rows(self, x: int, y: int, w: int) -> int:
        app, ui = self.app, self.app.ui
        p = app.layout.params
        for name, label, hint in STRATEGY_FIELDS:
            r = ui.checkbox(pygame.Rect(x, y, w, 24), label, bool(getattr(p, name)))
            if r is not None:
                app.set_param(name, r)
            y += 24
            for ln in wrap(hint, 11, w - 24):
                ui.text(ln, (x + 24, y), 11, T.TEXT_DIM)
                y += 15
            y += 6
        return y

    def _view_rows(self, x: int, y: int, w: int) -> int:
        app, ui = self.app, self.app.ui
        st = app.settings
        for name, label in VIEW_BOOL_FIELDS:
            r = ui.checkbox(pygame.Rect(x, y, w, 26), label, bool(getattr(st, name)))
            if r is not None:
                app.set_view(name, r)
            y += 30
        for name, label, unit, lo, hi in VIEW_NUMBER_FIELDS:
            ui.text(label, (x, y + 14), 13, anchor="midleft")
            val = getattr(st, name)
            res = ui.input(f"v_{name}", pygame.Rect(x + w - 140, y, 90, 28), str(val))
            ui.text(unit, (x + w - 44, y + 14), 12, T.TEXT_DIM, anchor="midleft")
            if res is not None:
                v = parse_float(res)
                if v is None:
                    app.status(f"{label}: ungültiger Wert")
                else:
                    app.set_view(name, int(max(lo, min(hi, v))))
            y += 34
        return y

    def _edit(self, x: int, y: int, w: int) -> int:
        app, ui = self.app, self.app.ui
        ed = app.editor
        sel = ed.selected()
        if sel:
            y = ui.section(y, x, w, "Auswahl")
            y = self._selection(x, y, w, sel) + 10
        # Prüfung
        y = ui.section(y, x, w, "Layoutprüfung")
        res = app.validation()
        errs, warns = res.errors, res.warnings
        if not errs and not warns:
            ui.text("✓  Anlage ist gültig", (x, y), 13, T.OK, bold=True)
            y += 24
        else:
            ui.text(f"{len(errs)} Fehler · {len(warns)} Hinweise", (x, y), 13,
                    T.DANGER if errs else T.WARN, bold=True)
            y += 22
            shown = 0
            for issue in errs + warns:
                if shown >= 12:
                    ui.text(f"… {len(errs) + len(warns) - shown} weitere", (x, y), 12, T.TEXT_DIM)
                    y += 18
                    break
                lines = wrap(issue.msg, 12, w - 18)
                r = pygame.Rect(x - 4, y - 2, w + 8, len(lines) * 16 + 6)
                if ui.hit(r):
                    pygame.draw.rect(app.screen, T.BTN_HOVER, r, border_radius=5)
                    if ui.down and issue.cells:
                        ui.consumed = True
                        app.focus_cells(issue.cells)
                pygame.draw.circle(app.screen, T.DANGER if issue.level == ERROR else T.WARN, (x + 4, y + 8), 4)
                for i, ln in enumerate(lines):
                    ui.text(ln, (x + 14, y + i * 16), 12)
                y += len(lines) * 16 + 8
                shown += 1
        y += 8
        if ui.button(pygame.Rect(x, y, w, 36), "Simulation starten  (F5)", color=T.OK, bold=True, size=14,
                     icon="play"):
            app.enter_sim(run=True)
        y += 48
        y = ui.section(y, x, w, "Globale Geschwindigkeiten")
        y = self._param_rows(x, y, w, SPEED_FIELDS, live=False) + 6
        y = ui.section(y, x, w, "Materialfluss")
        y = self._param_rows(x, y, w, FLOW_FIELDS, live=False)
        ui.text("Auslagerrate 0 = keine Auslagerung", (x, y), 11, T.TEXT_DIM)
        y += 18
        y = self._param_rows(x, y, w, SIM_FIELDS, live=False)
        ui.text("Dauer 0 = bis Lager voll (ohne Auslagerung) bzw. unbegrenzt", (x, y), 11, T.TEXT_DIM)
        y += 20
        r = ui.checkbox(pygame.Rect(x, y, w, 26), "Seed verwenden (reproduzierbar)", app.layout.params.use_seed)
        if r is not None:
            app.set_param("use_seed", r)
        y += 30
        ui.text("Anzahl Quellen (aus Layout)", (x, y + 10), 13, anchor="midleft")
        ui.text(str(app.layout.count(SOURCE)), (x + w, y + 10), 13, bold=True, anchor="midright")
        y += 30
        y = ui.section(y, x, w, "Strategien")
        y = self._strategy_rows(x, y, w) + 4
        y = ui.section(y, x, w, "Abstände")
        y = self._param_rows(x, y, w, DISTANCE_FIELDS, live=False)
        for ln in wrap("Ebenenabstand = Hubweg des RBG zwischen zwei Ebenen. Liegen RBG-Schienen übereinander, "
                       "bedient ein RBG alle diese Ebenen (Fahrt und Hub gleichzeitig).", 11, w):
            ui.text(ln, (x, y), 11, T.TEXT_DIM)
            y += 15
        y += 10
        y = ui.section(y, x, w, "Darstellung & Editor")
        y = self._view_rows(x, y, w) + 6
        y = ui.section(y, x, w, "Raster")
        lay = app.layout
        for key, label, val in (("w", "Breite (m)", lay.width), ("h", "Höhe (m)", lay.height),
                                ("l", "Ebenen", lay.levels)):
            ui.text(label, (x, y + 14), 13, anchor="midleft")
            res = ui.input(f"grid_{key}", pygame.Rect(x + w - 140, y, 90, 28), str(val))
            if res is not None:
                v = parse_float(res)
                if v is not None:
                    app.resize_grid(key, int(v))
            y += 34
        y += 6
        y = ui.section(y, x, w, "Anlage")
        for ctype in (SOURCE, CONVEYOR, CONVEYOR_SWITCH, LIFT, EPB_RAIL, EPB_CURVE, EPB_SWITCH, EPB, RBG_RAIL, RBG, STORAGE, SINK,
                      NIO):
            n = lay.count(ctype)
            ui.text(TYPES[ctype].name, (x, y), 13)
            ui.text(str(n), (x + w, y), 13, bold=True, anchor="topright")
            y += 20
        pre = sum(1 for c in lay.components(STORAGE) if c.prefilled)
        ui.text("davon vorbelegt", (x + 12, y), 12, T.TEXT_DIM)
        ui.text(str(pre), (x + w, y), 12, T.TEXT_DIM, anchor="topright")
        y += 22
        return y

    def _selection(self, x: int, y: int, w: int, sel) -> int:
        app, ui = self.app, self.app.ui
        ed = app.editor
        if len(sel) == 1:
            c = sel[0]
            ui.text(f"{c.spec.name}", (x, y), 15, bold=True)
            ui.text(c.id, (x + w, y + 2), 12, T.TEXT_DIM, anchor="topright")
            y += 26
            ui.text("Beschriftung", (x, y + 14), 13, anchor="midleft")
            res = ui.input(f"label_{c.id}", pygame.Rect(x + 96, y, w - 96, 28), c.label, numeric=False)
            if res is not None and res != c.label:
                ed.push_undo()
                c.label = res.strip()[:40]
                app.changed(push=False)
            y += 36
            ui.text(f"Position: x={c.x}  y={c.y}  Ebene E{c.level}", (x, y), 12, T.TEXT_DIM)
            y += 20
            txt = None
            if c.type == CONVEYOR_SWITCH:
                sides = ", ".join(DIR_NAMES[sd] for sd in c.branch_sides())
                txt = f"Gerade {DIR_NAMES[c.direction]} · Abzweig {BRANCH_NAMES[c.branch_mode]} ({sides})"
            elif c.type in (CONVEYOR, LIFT, SOURCE):
                txt = f"Förderrichtung: {DIR_NAMES[c.direction]}"
            elif c.type == EPB_RAIL:
                txt = f"Fahrtrichtung: {DIR_NAMES[c.direction]}"
            elif c.type == EPB_CURVE:
                en, ex = c.curve_sides()
                txt = f"Kurve: Eintritt {DIR_NAMES[en]} → Austritt {DIR_NAMES[ex]}"
            elif c.type == RBG_RAIL:
                txt = "Achse: " + ("Nord-Süd" if c.rbg_axis == 0 else "Ost-West")
            elif c.type == EPB_SWITCH:
                txt = (f"{'Zusammenführung' if c.switch_merge else 'Verzweigung'} · gerade {DIR_NAMES[c.direction]}"
                       f" · Abzweig {DIR_NAMES[c.switch_branch_side]}")
            if txt:
                ui.text(txt, (x, y), 12, T.TEXT_DIM)
                y += 20
            if c.type == EPB_SWITCH:
                bw2 = (w - 6) // 2
                other = "Zusammenführung" if not c.switch_merge else "Verzweigung"
                if ui.button(pygame.Rect(x, y, bw2, 28), other, tooltip="Weichentyp umschalten"):
                    ed.toggle_merge(c)
                if ui.button(pygame.Rect(x + bw2 + 6, y, bw2, 28), "Spiegeln (M)",
                             tooltip="Abzweig auf die andere Seite legen"):
                    ed.mirror()
                y += 36
            if c.type == CONVEYOR_SWITCH:
                if ui.button(pygame.Rect(x, y, w, 28), f"Abzweig: {BRANCH_NAMES[c.branch_mode]}  ·  wechseln (M)",
                             tooltip="rechts, links, beidseitig"):
                    ed.mirror()
                y += 36
            if c.type == LIFT:
                ui.text("Zielebene", (x, y + 14), 13, anchor="midleft")
                tl = c.target_level
                if ui.button(pygame.Rect(x + 96, y, 30, 28), "◀", enabled=tl > 0):
                    app.set_lift_target(c, tl - 1)
                ui.text(f"E{tl}", (x + 150, y + 14), 14, bold=True, anchor="center")
                if ui.button(pygame.Rect(x + 176, y, 30, 28), "▶", enabled=tl < app.layout.levels - 1):
                    app.set_lift_target(c, tl + 1)
                y += 36
            if c.type == STORAGE:
                r = ui.checkbox(pygame.Rect(x, y, w, 26), "Mit Behälter vorbelegt", c.prefilled)
                if r is not None:
                    ed.push_undo()
                    c.props["prefilled"] = r
                    app.changed(push=False)
                y += 32
        else:
            ui.text(f"{len(sel)} Elemente ausgewählt", (x, y), 14, bold=True)
            y += 26
        bw = (w - 12) // 3
        if ui.button(pygame.Rect(x, y, bw, 30), "Drehen", tooltip="90° im Uhrzeigersinn (R)"):
            ed.rotate(1)
        if ui.button(pygame.Rect(x + bw + 6, y, bw, 30), "Richtung", tooltip="Fahrt-/Förderrichtung umkehren (F)"):
            ed.flip()
        if ui.button(pygame.Rect(x + 2 * (bw + 6), y, bw, 30), "Löschen", tooltip="Entf"):
            ed.delete_selection()
        y += 36
        bw2 = (w - 6) // 2
        if ui.button(pygame.Rect(x, y, bw2, 28), "auf Ebene höher", enabled=app.level < app.layout.levels - 1):
            ed.move_selection(0, 0, 1)
        if ui.button(pygame.Rect(x + bw2 + 6, y, bw2, 28), "auf Ebene tiefer", enabled=app.level > 0):
            ed.move_selection(0, 0, -1)
        y += 34
        return y

    def _sim(self, x: int, y: int, w: int) -> int:
        app, ui = self.app, self.app.ui
        eng = app.engine
        y = ui.section(y, x, w, "Simulation")
        bw = (w - 6) // 2
        running = app.running and eng is not None and not eng.ended
        if ui.button(pygame.Rect(x, y, bw, 36), "Start", color=T.OK if not running else None, active=running,
                     enabled=eng is not None and not eng.ended, bold=True, tooltip="Leertaste", icon="play"):
            app.running = True
        if ui.button(pygame.Rect(x + bw + 6, y, bw, 36), "Pause", active=not running and eng is not None and not eng.ended,
                     enabled=eng is not None and not eng.ended, bold=True, tooltip="Leertaste", icon="pause"):
            app.running = False
        y += 42
        bw3 = (w - 12) // 3
        if ui.button(pygame.Rect(x, y, bw3, 30), "Neustart", tooltip="Zurücksetzen und sofort starten",
                     icon="restart"):
            app.sim_restart()
        if ui.button(pygame.Rect(x + bw3 + 6, y, bw3, 30), "Reset", tooltip="Ausgangszustand wiederherstellen",
                     icon="reset"):
            app.sim_reset()
        if ui.button(pygame.Rect(x + 2 * (bw3 + 6), y, bw3, 30), "Beenden", enabled=eng is not None and not eng.ended,
                     tooltip="Simulation beenden, Zustand bleibt sichtbar", icon="stop"):
            app.sim_stop()
        y += 36
        if ui.button(pygame.Rect(x, y, w, 30), "Zurück zur Konstruktion", icon="back"):
            app.back_to_edit()
        y += 42
        ui.text("Simulationsgeschwindigkeit", (x, y), 13, bold=True)
        y += 22
        per_row = 4
        sw = (w - (per_row - 1) * 5) // per_row
        for i, sp in enumerate(SPEEDS):
            r = pygame.Rect(x + (i % per_row) * (sw + 5), y + (i // per_row) * 32, sw, 28)
            if ui.button(r, f"{sp:g}×", active=abs(app.speed - sp) < 1e-9):
                app.speed = sp
        y += 2 * 32 + 10
        if eng is not None:
            state = "BEENDET" if eng.ended else ("LÄUFT" if running else "PAUSIERT")
            col = T.DANGER if eng.ended else (T.OK if running else T.WARN)
            # Statuszeile als Kachel: Zustand + Simulationszeit
            box = pygame.Rect(x, y, w, 40)
            pygame.draw.rect(app.screen, T.TILE, box, border_radius=9)
            pygame.draw.rect(app.screen, T.TILE_BORDER, box, 1, border_radius=9)
            pygame.draw.circle(app.screen, col, (x + 16, y + 20), 6)
            ui.text(state, (x + 30, y + 20), 14, col, bold=True, anchor="midleft")
            ui.text(fmt_time(eng.time), (x + w - 12, y + 20), 18, T.TEXT, bold=True, anchor="midright")
            y += 50
            if eng.ended:
                for ln in wrap(f"Grund: {eng.end_reason}", 12, w):
                    ui.text(ln, (x, y), 12, T.DANGER)
                    y += 17
            if eng.stalled:
                for ln in wrap("Hinweis: seit längerer Zeit keine Bewegung (Blockade im Layout?)", 12, w):
                    ui.text(ln, (x, y), 12, T.WARN)
                    y += 17
            groups = self.snapshot(eng, running)
            y = self._tiles(x, y, w, groups)
            ui.text(f"Seed: {eng.seed}", (x, y), 12, T.TEXT_DIM)
            y += 24
            label = ("Alle Kennzahlen ausblenden" if self.details else "Alle Kennzahlen anzeigen")
            if ui.button(pygame.Rect(x, y, w, 28), label, active=self.details, icon="next" if not self.details else "prev"):
                self.details = not self.details
            y += 38
            if self.details:
                for title, rows in groups:
                    y = ui.section(y, x, w, title)
                    for i, (k, v) in enumerate(rows):
                        if i % 2 == 0:
                            pygame.draw.rect(app.screen, T.TILE, (x - 4, y - 2, w + 8, 20), border_radius=4)
                        ui.text(k, (x, y), 13, max_w=w - 90)
                        ui.text(v, (x + w, y), 13, bold=True, anchor="topright")
                        y += 20
                    y += 8
        y = ui.section(y, x, w, "Globale Geschwindigkeiten (live)")
        y = self._param_rows(x, y, w, SPEED_FIELDS, live=True) + 6
        y = ui.section(y, x, w, "Materialfluss (ab Neustart)")
        y = self._param_rows(x, y, w, FLOW_FIELDS, live=False)
        y = self._param_rows(x, y, w, SIM_FIELDS, live=False) + 6
        y = ui.section(y, x, w, "Strategien (ab Neustart)")
        y = self._strategy_rows(x, y, w) + 4
        y = ui.section(y, x, w, "Darstellung")
        y = self._view_rows(x, y, w)
        return y


# ============================================================================ Status / Modal
def draw_status(app: "App") -> None:
    ui, scr = app.ui, app.screen
    r = app.status_rect
    scr.fill(T.STATUSBAR, r)
    pygame.draw.line(scr, T.PANEL_BORDER, r.topleft, r.topright)
    info = f"Zoom {app.cam.zoom / 36 * 100:.0f} %"
    if app.hover_cell is not None:
        hx, hy = app.hover_cell
        info = f"x={hx}  y={hy}  E{app.level}   ·   " + info
    ir = ui.text(info, (r.right - 12, r.centery), 12, T.TEXT_DIM, anchor="midright")
    x = ir.left - 110
    res = ui.checkbox(pygame.Rect(x, r.y, 90, r.h), "IDs zeigen", app.show_labels)
    if res is not None:
        app.show_labels = res
    x -= 140
    res = ui.checkbox(pygame.Rect(x, r.y, 130, r.h), "andere Ebenen", app.show_ghost)
    if res is not None:
        app.show_ghost = res
    ui.text(app.status_msg, (r.x + 12, r.centery), 12, T.TEXT, anchor="midleft", max_w=x - r.x - 30)


def draw_modal(app: "App") -> None:
    m = app.modal
    if m is None:
        return
    ui, scr = app.ui, app.screen
    sw, sh = scr.get_size()
    shade = pygame.Surface((sw, sh), pygame.SRCALPHA)
    shade.fill((15, 20, 30, 130))
    scr.blit(shade, (0, 0))
    w = 600
    lines = []
    for ln in m["lines"]:
        lines.extend(wrap(ln, 13, w - 48) if ln else [""])
    lines = lines[:26]
    h = 110 + len(lines) * 19 + 20
    box = pygame.Rect((sw - w) // 2, (sh - h) // 2, w, h)
    sh_s, pad = render.shadow_sprite(w, h, 12, 90)
    scr.blit(sh_s, (box.x - pad, box.y - pad + 6))
    pygame.draw.rect(scr, T.PANEL, box, border_radius=12)
    pygame.draw.rect(scr, T.PANEL_BORDER, box, 1, border_radius=12)
    ui.in_modal = True
    ui.text(m["title"], (box.x + 24, box.y + 20), 17, T.DANGER if m.get("danger") else T.TEXT, bold=True)
    y = box.y + 56
    for ln in lines:
        ui.text(ln, (box.x + 24, y), 13)
        y += 19
    bx = box.right - 24
    for label, fn, col in reversed(m["buttons"]):
        bw = max(100, T.font(13).size(label)[0] + 28)
        bx -= bw
        if ui.button(pygame.Rect(bx, box.bottom - 52, bw, 34), label, color=col, bold=col is not None):
            app.modal = None
            if fn:
                fn()
        bx -= 10
    ui.in_modal = False
