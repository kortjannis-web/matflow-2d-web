"""Browser-Version (pygbag/WebAssembly): Datei-Download und -Upload über JavaScript."""
from __future__ import annotations

import json
import sys

IS_WEB = sys.platform == "emscripten"

# kleinste Zeichenfläche; kleinere Fenster zeigen sie verkleinert an
MIN_W, MIN_H = 1000, 640
# größere Fenster zeigen die Fläche hochskaliert: jedes Pixel kostet im Browser Zeit
MAX_PIXELS = 1920 * 1080


def _js(code: str):
    import platform  # im Browser stellt pygbag hier das JS-Fenster bereit
    return platform.window.eval(code)


def ready() -> None:
    """Ladehinweise ausblenden und die Zeichenfläche das ganze Browserfenster füllen lassen."""
    _js("(function(){for(const id of ['status','infobox']){const e=document.getElementById(id);"
        "if(e)e.style.display='none';}"
        "config.user_canvas_managed=1;"  # pygbag skaliert die Fläche dann nicht mehr selbst
        "const st=document.createElement('style');"
        "st.textContent='html,body{margin:0;overflow:hidden;background:#eef2f7}"
        "#canvas{position:fixed!important;inset:0!important;width:100%!important;"
        "height:100%!important;margin:0!important}';"
        "document.head.appendChild(st);})()")


def canvas_size() -> tuple[int, int]:
    """Größe der Zeichenfläche passend zum Browserfenster, mindestens MIN_W x MIN_H."""
    w, h = json.loads(str(_js("JSON.stringify([window.innerWidth,window.innerHeight])")))
    w, h = max(1, int(w)), max(1, int(h))
    # Seitenverhältnis bleibt gleich, sonst verzerrt
    f = max(min(1.0, (MAX_PIXELS / (w * h)) ** 0.5), MIN_W / w, MIN_H / h)
    return round(w * f), round(h * f)


def download(filename: str, text: str) -> None:
    """Bietet text als Datei zum Herunterladen an (landet im Download-Ordner)."""
    _js("(function(){const b=new Blob([%s],{type:'application/json'});"
        "const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=%s;"
        "document.body.appendChild(a);a.click();"
        "setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},2000);})()"
        % (json.dumps(text), json.dumps(filename)))


def pick_file() -> None:
    """Öffnet die Dateiauswahl des Browsers; Ergebnis später mit poll_file() abholen."""
    _js("(function(){window.__mf_file='';const i=document.createElement('input');"
        "i.type='file';i.accept='.mfp,.json';"
        "i.onchange=()=>{const f=i.files[0];if(f){f.text().then(t=>{window.__mf_file=JSON.stringify([f.name,t]);});}};"
        "i.click();})()")


def poll_file() -> tuple[str, str] | None:
    """(Dateiname, Inhalt), sobald eine Datei gewählt und gelesen wurde."""
    raw = _js("window.__mf_file||''")
    if not raw:
        return None
    _js("window.__mf_file=''")
    name, text = json.loads(str(raw))
    return name, text
