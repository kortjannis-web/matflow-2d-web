"""Ansichts- und Editor-Einstellungen (pro Rechner, nicht pro Projekt). Gespeichert in einstellungen.json."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, fields
from pathlib import Path

ERASE_MAX = 5


@dataclass
class ViewSettings:
    show_grid: bool = True
    grid_strength: int = 35          # % Deckkraft der Rasterlinien
    show_border: bool = True         # Rand um die bebaubare Fläche
    erase_size: int = 1              # Radierer: Kantenlänge in Zellen (1..5)
    show_ghost: bool = True          # andere Ebenen blass anzeigen
    show_labels: bool = False        # IDs anzeigen

    def clamp(self) -> None:
        self.grid_strength = max(5, min(100, int(self.grid_strength)))
        self.erase_size = max(1, min(ERASE_MAX, int(self.erase_size)))

    @staticmethod
    def load(path: Path) -> "ViewSettings":
        s = ViewSettings()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return s
        for f in fields(ViewSettings):
            if f.name in data:
                try:
                    setattr(s, f.name, type(getattr(s, f.name))(data[f.name]))
                except (TypeError, ValueError):
                    pass
        s.clamp()
        return s

    def save(self, path: Path) -> None:
        try:
            path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        except OSError:
            pass


# Beschreibung für das Einstellungs-Panel: (Feld, Beschriftung, Einheit, min, max)
VIEW_NUMBER_FIELDS = [
    ("grid_strength", "Rasterstärke", "%", 5, 100),
    ("erase_size", "Radiergröße", "Zellen", 1, ERASE_MAX),
]
VIEW_BOOL_FIELDS = [
    ("show_grid", "Raster anzeigen"),
    ("show_border", "Rand der Baufläche anzeigen"),
]
