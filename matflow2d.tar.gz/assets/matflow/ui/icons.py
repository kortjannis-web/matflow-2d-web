"""Einheitliche Linien-Icons für Buttons (vektoriell gezeichnet, 4-fach überabgetastet, gecacht)."""
from __future__ import annotations

import pygame

_cache: dict[tuple, pygame.Surface] = {}
SS = 4          # Überabtastung für glatte Kanten


def get(name: str, size: int = 16, color=(255, 255, 255)) -> pygame.Surface:
    key = (name, size, color)
    s = _cache.get(key)
    if s is None:
        big = pygame.Surface((size * SS, size * SS), pygame.SRCALPHA)
        _draw(big, name, size * SS, color)
        s = pygame.transform.smoothscale(big, (size, size))
        _cache[key] = s
    return s


def _draw(s: pygame.Surface, name: str, n: int, c) -> None:
    w = max(2, round(n * 0.1))           # Strichstärke

    def P(x, y):
        return (x * n, y * n)

    def line(pts, closed=False):
        pygame.draw.lines(s, c, closed, [P(*p) for p in pts], w)
        for p in pts:                    # runde Enden/Ecken
            pygame.draw.circle(s, c, P(*p), w // 2)

    def poly(pts):
        pygame.draw.polygon(s, c, [P(*p) for p in pts])

    def rect(x, y, rw, rh, fill=False, rad=0.12):
        pygame.draw.rect(s, c, pygame.Rect(*P(x, y), rw * n, rh * n), 0 if fill else w,
                         border_radius=round(rad * n))

    if name == "new":
        line([(0.25, 0.1), (0.6, 0.1), (0.78, 0.28), (0.78, 0.9), (0.25, 0.9)], closed=True)
        line([(0.6, 0.1), (0.6, 0.28), (0.78, 0.28)])
    elif name == "open":
        line([(0.1, 0.25), (0.38, 0.25), (0.46, 0.35), (0.85, 0.35), (0.85, 0.82), (0.1, 0.82)], closed=True)
        line([(0.1, 0.48), (0.85, 0.48)])
    elif name in ("save", "save_as"):
        rect(0.14, 0.12, 0.72, 0.76)
        rect(0.3, 0.12, 0.38, 0.24)
        rect(0.28, 0.56, 0.44, 0.2, fill=True, rad=0.04)
        if name == "save_as":
            pygame.draw.circle(s, c, P(0.82, 0.82), round(n * 0.17))
            pygame.draw.circle(s, (0, 0, 0, 0), P(0.82, 0.82), round(n * 0.1))
            line([(0.82, 0.74), (0.82, 0.9)])
            line([(0.74, 0.82), (0.9, 0.82)])
    elif name in ("example", "example2"):
        # drei verbundene Blöcke (Anlage)
        rect(0.1, 0.18, 0.28, 0.28)
        rect(0.62, 0.18, 0.28, 0.28)
        rect(0.36, 0.6, 0.28, 0.28)
        line([(0.38, 0.32), (0.62, 0.32)])
        line([(0.5, 0.32), (0.5, 0.6)])
        if name == "example2":
            poly([(0.78, 0.6), (0.94, 0.74), (0.78, 0.88)])
    elif name == "undo":
        line([(0.3, 0.42), (0.68, 0.42)])
        pygame.draw.arc(s, c, pygame.Rect(*P(0.44, 0.42), 0.48 * n, 0.44 * n), -1.57, 1.57, w)
        line([(0.68, 0.86), (0.4, 0.86)])
        poly([(0.12, 0.42), (0.34, 0.24), (0.34, 0.6)])
    elif name == "redo":
        line([(0.7, 0.42), (0.32, 0.42)])
        pygame.draw.arc(s, c, pygame.Rect(*P(0.08, 0.42), 0.48 * n, 0.44 * n), 1.57, 4.71, w)
        line([(0.32, 0.86), (0.6, 0.86)])
        poly([(0.88, 0.42), (0.66, 0.24), (0.66, 0.6)])
    elif name == "prev":
        line([(0.62, 0.2), (0.34, 0.5), (0.62, 0.8)])
    elif name == "next":
        line([(0.38, 0.2), (0.66, 0.5), (0.38, 0.8)])
    elif name == "plus":
        line([(0.5, 0.18), (0.5, 0.82)])
        line([(0.18, 0.5), (0.82, 0.5)])
    elif name == "play":
        poly([(0.26, 0.14), (0.86, 0.5), (0.26, 0.86)])
    elif name == "pause":
        rect(0.22, 0.14, 0.2, 0.72, fill=True, rad=0.05)
        rect(0.58, 0.14, 0.2, 0.72, fill=True, rad=0.05)
    elif name == "stop":
        rect(0.2, 0.2, 0.6, 0.6, fill=True, rad=0.08)
    elif name in ("restart", "reset"):
        pygame.draw.arc(s, c, pygame.Rect(*P(0.14, 0.14), 0.72 * n, 0.72 * n), 0.6, 5.6, w)
        poly([(0.9, 0.18), (0.9, 0.5), (0.6, 0.38)] if name == "restart" else [(0.88, 0.2), (0.88, 0.48), (0.62, 0.36)])
        if name == "restart":
            poly([(0.42, 0.36), (0.66, 0.5), (0.42, 0.64)])
    elif name == "back":
        line([(0.85, 0.5), (0.2, 0.5)])
        line([(0.44, 0.24), (0.18, 0.5), (0.44, 0.76)])
    elif name == "edit":
        # Stift
        poly([(0.2, 0.8), (0.24, 0.62), (0.66, 0.2), (0.8, 0.34), (0.38, 0.76)])
        pygame.draw.line(s, (0, 0, 0, 0), P(0.58, 0.28), P(0.72, 0.42), max(1, w // 2))
    elif name == "sim":
        # Förderband mit Behälter
        rect(0.1, 0.62, 0.8, 0.16, rad=0.08)
        rect(0.32, 0.26, 0.36, 0.3, fill=True, rad=0.06)
    elif name == "layers":
        poly([(0.5, 0.12), (0.9, 0.32), (0.5, 0.52), (0.1, 0.32)])
        line([(0.1, 0.5), (0.5, 0.7), (0.9, 0.5)])
        line([(0.1, 0.68), (0.5, 0.88), (0.9, 0.68)])
