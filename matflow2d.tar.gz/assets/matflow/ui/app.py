"""Hauptanwendung: Fenster, Ereignisschleife, Moduswechsel Konstruktion ↔ Simulation, Dateibefehle."""
from __future__ import annotations

import asyncio
import os
import re
import sys
import time
import traceback
from pathlib import Path
from typing import Any

import pygame

from matflow.model.components import LIFT
from matflow.model.layout import Layout, LayoutError
from matflow.persistence.example import build_example
from matflow.persistence.project_io import load_project, parse_project, project_text, save_project
from matflow.sim.engine import Engine, SimulationError
from matflow.sim.validation import ValidationResult, validate
from matflow.ui import canvas, dialogs, panels, render, web
from matflow.ui import theme as T
from matflow.ui.camera import Camera
from matflow.ui.editor import ERASE_TOOL, Editor, TOOLS
from matflow.ui.settings import ViewSettings
from matflow.ui.widgets import UI

# Als .exe (PyInstaller) liegt der Projektordner neben der .exe, nicht im Temp-Entpackordner
if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parents[2]
PROJECT_DIR = APP_DIR / "projekte"
SETTINGS_PATH = APP_DIR / "einstellungen.json"


class App:
    def __init__(self, open_path: str | None = None):
        os.environ.setdefault("SDL_WINDOWS_DPI_AWARENESS", "permonitorv2")
        pygame.init()
        pygame.key.set_repeat(350, 40)
        info = pygame.display.Info()
        w = min(1720, max(1200, info.current_w - 80)) if info.current_w > 0 else 1600
        h = min(1000, max(760, info.current_h - 120)) if info.current_h > 0 else 940
        if web.IS_WEB:
            # Zeichenfläche füllt das Browserfenster, siehe _web_fit()
            web.ready()
            self.screen = pygame.display.set_mode(web.canvas_size())
        else:
            self.screen = pygame.display.set_mode((w, h), pygame.RESIZABLE)
        pygame.display.set_caption("MatFlow 2D")
        self.clock = pygame.time.Clock()
        self.ui = UI(self.screen)
        self.layout = Layout()
        self.level = 0
        self.settings = ViewSettings.load(SETTINGS_PATH)
        self.mode = "edit"
        self.engine: Engine | None = None
        self.running = False
        self.speed = 1.0
        self.file_path: Path | None = None
        self.dirty = False
        self.version = 0
        self._val: tuple[int, ValidationResult] | None = None
        self.status_msg = "Bereit. Komponenten links wählen und auf das Raster setzen, oder „Beispiel“ laden."
        self.modal: dict[str, Any] | None = None
        self.hover_cell: tuple[int, int] | None = None
        self.hover_entity = None
        self.pan_from: tuple[int, int] | None = None
        self.quit = False
        self._web_open = False
        self._web_frames = 0
        self.dt = 0.0
        # Vorberechnete statische Anlage (Raster + Komponenten); neu nur bei Änderung von Ansicht/Layout
        self._static_key: tuple | None = None
        self._static_surf: pygame.Surface | None = None
        self._anim_cells: dict = {}
        self.fx = canvas.SimFx()
        self._layout_rects()
        self.cam = Camera(self.canvas_rect)
        self.editor = Editor(self)
        self.right = panels.RightPanel(self)
        self.fit_view()
        if open_path:
            self._open_path(Path(open_path))

    # ------------------------------------------------------------------ Ansicht
    @property
    def show_ghost(self) -> bool:
        return self.settings.show_ghost

    @show_ghost.setter
    def show_ghost(self, v: bool) -> None:
        self.set_view("show_ghost", v)

    @property
    def show_labels(self) -> bool:
        return self.settings.show_labels

    @show_labels.setter
    def show_labels(self, v: bool) -> None:
        self.set_view("show_labels", v)

    def set_view(self, name: str, value) -> None:
        """Ansichts-/Editor-Einstellung ändern und sofort speichern."""
        setattr(self.settings, name, value)
        self.settings.clamp()
        self.settings.save(SETTINGS_PATH)

    def change_erase_size(self, delta: int) -> None:
        self.set_view("erase_size", self.settings.erase_size + delta)
        n = self.settings.erase_size
        self.status(f"Radiergröße {n}×{n}")

    # ------------------------------------------------------------------ Geometrie
    def _layout_rects(self) -> None:
        w, h = self.screen.get_size()
        self.left_rect = pygame.Rect(0, T.TOP_H, T.LEFT_W, h - T.TOP_H - T.STATUS_H)
        self.right_rect = pygame.Rect(w - T.RIGHT_W, T.TOP_H, T.RIGHT_W, h - T.TOP_H - T.STATUS_H)
        self.canvas_rect = pygame.Rect(T.LEFT_W, T.TOP_H, w - T.LEFT_W - T.RIGHT_W, h - T.TOP_H - T.STATUS_H)
        self.status_rect = pygame.Rect(0, h - T.STATUS_H, w, T.STATUS_H)
        if hasattr(self, "cam"):
            self.cam.rect = self.canvas_rect

    def fit_view(self) -> None:
        comps = list(self.layout.by_id.values())
        if comps:
            xs = [c.x for c in comps]
            ys = [c.y for c in comps]
            self.cam.fit(min(xs), min(ys), max(xs) + 1, max(ys) + 1)
        else:
            self.cam.fit(0, 0, min(self.layout.width, 30), min(self.layout.height, 20), margin=0.5)

    # ------------------------------------------------------------------ Zustand
    def status(self, msg: str) -> None:
        self.status_msg = msg

    def changed(self, push: bool = True) -> None:
        if push:
            self.editor.push_undo()
        self.dirty = True
        self.version += 1

    def validation(self) -> ValidationResult:
        if self._val is None or self._val[0] != self.version:
            self._val = (self.version, validate(self.layout))
        return self._val[1]

    def set_layout(self, lay: Layout, keep_view: bool = False, keep_history: bool = False) -> None:
        self.layout = lay
        self.level = min(self.level, lay.levels - 1)
        self.version += 1
        if not keep_history:
            self.editor.undo_stack.clear()
            self.editor.redo_stack.clear()
            self.editor.selection.clear()
        if not keep_view:
            self.level = 0
            self.fit_view()

    def set_level(self, lv: int) -> None:
        self.level = max(0, min(self.layout.levels - 1, lv))
        self.editor.selection = {i for i in self.editor.selection
                                 if i in self.layout.by_id and self.layout.by_id[i].level == self.level}
        self.status(f"Ebene E{self.level}")

    def add_level(self) -> None:
        self.editor.push_undo()
        self.layout.levels += 1
        self.changed(push=False)
        self.set_level(self.layout.levels - 1)

    def resize_grid(self, key: str, v: int) -> None:
        lay = self.layout
        w, h, l = lay.width, lay.height, lay.levels
        if key == "w":
            w = max(5, min(400, v))
        elif key == "h":
            h = max(5, min(400, v))
        else:
            l = max(1, min(20, v))
        self.editor.push_undo()
        ok, why = lay.resize(w, h, l)
        if not ok:
            self.editor.undo_stack.pop()
            self.status(f"Rastergröße nicht änderbar: {why}")
            return
        self.level = min(self.level, lay.levels - 1)
        self.changed(push=False)

    def set_param(self, name: str, value) -> None:
        self.editor.push_undo()
        setattr(self.layout.params, name, value)
        if self.engine is not None and name.endswith("_speed"):
            setattr(self.engine.params, name, value)
        self.changed(push=False)
        self.status(f"Parameter geändert: {name} = {value}")

    def set_lift_target(self, comp, target: int) -> None:
        self.editor.push_undo()
        ok, why = self.layout.set_lift_target(comp.id, target)
        if not ok:
            self.editor.undo_stack.pop()
            self.status(f"Zielebene nicht möglich: {why}")
            return
        self.changed(push=False)
        self.status(f"Heberkette → Zielebene E{target}")

    def focus_cells(self, cells) -> None:
        c = cells[0]
        self.set_level(c[2])
        self.cam.center_on(c[0] + 0.5, c[1] + 0.5)
        ids = set()
        for cell in cells:
            comp = self.layout.static.get(cell) or self.layout.vehicles.get(cell)
            if comp:
                ids.add(comp.id)
        if self.mode == "edit":
            self.editor.tool = "select"
            self.editor.selection = ids

    # ------------------------------------------------------------------ Simulation
    def enter_sim(self, run: bool = False) -> None:
        if self.mode == "sim":
            return
        self.ui.unfocus()
        res = self.validation()
        if not res.ok:
            lines = [f"• {i.msg}" for i in res.errors[:14]]
            if len(res.errors) > 14:
                lines.append(f"… und {len(res.errors) - 14} weitere")
            lines += ["", "Fehlerhafte Zellen sind rot markiert. Ein Klick auf einen Eintrag rechts zeigt die Stelle."]
            self.modal = {"title": "Simulation kann nicht starten", "danger": True, "lines": lines,
                          "buttons": [("Zur Konstruktion", None, T.ACCENT)]}
            return
        try:
            self.engine = Engine(self.layout)
        except SimulationError as e:
            self.modal = {"title": "Simulation kann nicht starten", "danger": True, "lines": str(e).split("\n"),
                          "buttons": [("OK", None, T.ACCENT)]}
            return
        self.mode = "sim"
        self.running = run
        self.editor.drag = None
        self.status("Simulationsmodus. Start mit ▶ oder Leertaste." if not run else "Simulation läuft")

    def sim_reset(self) -> None:
        if self.mode != "sim":
            return
        self.engine = Engine(self.layout)
        self.running = False
        self.status("Simulation zurückgesetzt (vorbelegte Lagerplätze bleiben belegt)")

    def sim_restart(self) -> None:
        self.sim_reset()
        self.running = True
        self.status("Simulation neu gestartet")

    def sim_stop(self) -> None:
        if self.engine is not None:
            self.engine.stop()
            self.running = False
            self.status("Simulation beendet. Zustand bleibt sichtbar.")

    def back_to_edit(self) -> None:
        if self.mode == "edit":
            return
        self.mode = "edit"
        self.engine = None
        self.running = False
        self.hover_entity = None
        self.status("Konstruktionsmodus")

    # ------------------------------------------------------------------ Dateien
    def _confirm_discard(self, then) -> None:
        if not self.dirty:
            then()
            return

        def save_then():
            if self.cmd_save():
                then()

        self.modal = {"title": "Ungespeicherte Änderungen", "lines": [
            "Die aktuelle Anlage wurde geändert. Sollen die Änderungen gespeichert werden?"],
            "buttons": [("Abbrechen", None, None), ("Verwerfen", then, T.DANGER), ("Speichern", save_then, T.ACCENT)]}

    def cmd_new(self) -> None:
        def do():
            self.back_to_edit()
            self.set_layout(Layout())
            self.file_path = None
            self.dirty = False
            self.status("Neue leere Anlage")
        self._confirm_discard(do)

    def cmd_example(self, demo: bool = False) -> None:
        def do():
            self.back_to_edit()
            self.set_layout(build_example(demo))
            self.file_path = None
            self.dirty = True
            if demo:
                self.status("Beispiel Ein-/Auslagerung geladen: Auslagerung 2/min, NIO 10 %, Dauer 60 min. F5 startet.")
            else:
                self.status("Beispielanlage geladen (Testfall, frei veränderbar). Ebene E0 und E1 beachten.")
        self._confirm_discard(do)

    def cmd_example_demo(self) -> None:
        self.cmd_example(demo=True)

    def cmd_open(self) -> None:
        def do():
            if web.IS_WEB:
                web.pick_file()
                self._web_open = True
                self.status("Projektdatei (.mfp) im Browser auswählen …")
                return
            PROJECT_DIR.mkdir(exist_ok=True)
            p = dialogs.ask_open(PROJECT_DIR)
            pygame.event.clear()
            self.ui.held = False
            if p:
                self._open_path(Path(p))
        self._confirm_discard(do)

    def _open_path(self, p: Path, text: str | None = None) -> None:
        try:
            lay = load_project(p) if text is None else parse_project(text)
        except (OSError, ValueError, LayoutError, KeyError) as e:
            self.modal = {"title": "Öffnen fehlgeschlagen", "danger": True, "lines": [str(p), str(e)],
                          "buttons": [("OK", None, T.ACCENT)]}
            return
        self.back_to_edit()
        self.set_layout(lay)
        self.file_path = p
        self.dirty = False
        self.status(f"Geöffnet: {p}")

    def cmd_save(self) -> bool:
        if self.file_path is None:
            return self.cmd_save_as()
        return self._save_to(self.file_path)

    def cmd_save_as(self) -> bool:
        name = (self.file_path.name if self.file_path
                else re.sub(r'[\\/:*?"<>|]+', "-", self.layout.name).replace(" ", "_") + ".mfp")
        if web.IS_WEB:
            return self._save_to(Path(name))
        PROJECT_DIR.mkdir(exist_ok=True)
        if dialogs.available():
            p = dialogs.ask_save(self.file_path.parent if self.file_path else PROJECT_DIR, name)
            pygame.event.clear()
            self.ui.held = False
            if not p:
                return False
            path = Path(p)
        else:
            path = PROJECT_DIR / name
        return self._save_to(path)

    def _save_to(self, path: Path) -> bool:
        try:
            if self.layout.name in ("Neue Anlage", ""):
                self.layout.name = path.stem
            if web.IS_WEB:
                path = path.with_suffix(".mfp")
                web.download(path.name, project_text(self.layout))
            else:
                path = save_project(self.layout, path)
        except OSError as e:
            self.modal = {"title": "Speichern fehlgeschlagen", "danger": True, "lines": [str(e)],
                          "buttons": [("OK", None, T.ACCENT)]}
            return False
        self.file_path = path
        self.dirty = False
        self.status(f"Heruntergeladen: {path.name} (Download-Ordner)" if web.IS_WEB else f"Gespeichert: {path}")
        return True

    def request_quit(self) -> None:
        if web.IS_WEB:
            self.status("Zum Beenden einfach den Browser-Tab schließen (vorher speichern)")
            return

        def do():
            self.quit = True
        self._confirm_discard(do)

    # ------------------------------------------------------------------ Eingaben
    def handle_keys(self, ev: pygame.event.Event) -> None:
        if self.ui.typing or self.modal is not None:
            if self.modal is not None and ev.key == pygame.K_ESCAPE:
                self.modal = None
            return
        ctrl = ev.mod & pygame.KMOD_CTRL
        shift = ev.mod & pygame.KMOD_SHIFT
        k = ev.key
        if ctrl and k == pygame.K_s:
            self.cmd_save_as() if shift else self.cmd_save()
            return
        if ctrl and k == pygame.K_o and self.mode == "edit":
            self.cmd_open()
            return
        if ctrl and k == pygame.K_n and self.mode == "edit":
            self.cmd_new()
            return
        if k == pygame.K_PAGEUP:
            self.set_level(self.level + 1)
            return
        if k == pygame.K_PAGEDOWN:
            self.set_level(self.level - 1)
            return
        if k == pygame.K_HOME:
            self.fit_view()
            return
        if self.mode == "sim":
            if k == pygame.K_SPACE and self.engine and not self.engine.ended:
                self.running = not self.running
            elif k == pygame.K_ESCAPE:
                self.back_to_edit()
            return
        ed = self.editor
        if ctrl and k == pygame.K_z:
            ed.redo() if shift else ed.undo()
        elif ctrl and k == pygame.K_y:
            ed.redo()
        elif ctrl and k == pygame.K_a:
            ed.set_tool("select")
            ed.select_all()
        elif ctrl and k == pygame.K_c:
            ed.copy()
        elif ctrl and k == pygame.K_v:
            hc = self.hover_cell
            ed.paste((hc[0], hc[1], self.level) if hc is not None else None)
        elif ctrl:
            return
        elif k == pygame.K_m:
            ed.mirror()
        elif k == pygame.K_F5:
            self.enter_sim(run=True)
        elif k == pygame.K_r:
            ed.rotate(-1 if shift else 1)
        elif k == pygame.K_f:
            ed.flip()
        elif k in (pygame.K_DELETE, pygame.K_BACKSPACE):
            ed.delete_selection()
        elif k == pygame.K_ESCAPE:
            ed.drag = None
            if ed.tool != "select":
                ed.set_tool("select")
            else:
                ed.selection.clear()
        elif k in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN) and ed.selection:
            dx = {pygame.K_LEFT: -1, pygame.K_RIGHT: 1}.get(k, 0)
            dy = {pygame.K_UP: -1, pygame.K_DOWN: 1}.get(k, 0)
            ed.move_selection(dx, dy)
        elif k == pygame.K_v:
            ed.set_tool("select")
        elif k == pygame.K_x:
            ed.set_tool("erase")
        elif ed.tool == ERASE_TOOL and ev.unicode in ("+", "-", "[", "]"):
            self.change_erase_size(1 if ev.unicode in ("+", "]") else -1)
        else:
            ch = ev.unicode.lower()
            for t in TOOLS:
                if t.enabled and ch and t.shortcut.lower() == ch:
                    ed.set_tool(t.key)
                    break

    def handle_canvas(self, ev: pygame.event.Event) -> None:
        cam = self.cam
        if ev.type == pygame.MOUSEWHEEL:
            if self.canvas_rect.collidepoint(pygame.mouse.get_pos()) and self.modal is None:
                mx, my = pygame.mouse.get_pos()
                cam.zoom_at(mx, my, 1.15 ** ev.y)
            return
        if self.modal is not None:
            return
        if ev.type == pygame.MOUSEBUTTONDOWN:
            if not self.canvas_rect.collidepoint(ev.pos):
                return
            if ev.button in (2, 3):
                self.pan_from = ev.pos
                return
            if ev.button == 1:
                if self.mode == "sim" or pygame.key.get_pressed()[pygame.K_SPACE]:
                    self.pan_from = ev.pos
                    return
                if self.mode == "edit":
                    cx, cy = cam.cell_at(*ev.pos)
                    self.editor.mouse_down((cx, cy, self.level), pygame.key.get_mods())
        elif ev.type == pygame.MOUSEMOTION:
            if self.pan_from is not None:
                cam.pan(ev.pos[0] - self.pan_from[0], ev.pos[1] - self.pan_from[1])
                self.pan_from = ev.pos
                return
            if self.canvas_rect.collidepoint(ev.pos):
                cx, cy = cam.cell_at(*ev.pos)
                self.hover_cell = (cx, cy)
                if self.mode == "edit":
                    self.editor.mouse_move((cx, cy, self.level))
            else:
                self.hover_cell = None
                if self.mode == "edit":
                    self.editor.hover = None
        elif ev.type == pygame.MOUSEBUTTONUP:
            if self.pan_from is not None and ev.button in (1, 2, 3):
                self.pan_from = None
                return
            if ev.button == 1 and self.mode == "edit":
                cx, cy = cam.cell_at(*ev.pos)
                self.editor.mouse_up((cx, cy, self.level))

    # ------------------------------------------------------------------ Zeichnen
    def _static_layer(self) -> None:
        """Raster und statische Komponenten aus dem Cache blitten (neu zeichnen nur bei Änderung)."""
        cam, st = self.cam, self.settings
        sim = self.mode == "sim"
        key = (id(self.layout), self.version, self.level, self.show_ghost, sim, sim and self.show_labels,
               st.show_grid, st.grid_strength, st.show_border, cam.zoom, cam.ox, cam.oy, cam.rect.size)
        if key != self._static_key or self._static_surf is None:
            r = cam.rect
            if self._static_surf is None or self._static_surf.get_size() != r.size:
                self._static_surf = pygame.Surface(r.size).convert()
            surf = self._static_surf
            lc = Camera(pygame.Rect(0, 0, r.w, r.h), cam.zoom)
            lc.ox, lc.oy = cam.ox, cam.oy
            render.draw_grid(surf, lc, self.layout, st.show_grid, st.grid_strength, st.show_border)
            canvas.draw_static(surf, lc, self.layout, self.level, self.show_ghost, show_prefill=not sim)
            if sim:
                canvas.draw_labels(surf, lc, self.layout, self.level, self.show_labels, vehicles=False)
                self._anim_cells = canvas.conveyor_cells(self.layout, self.level)
            self._static_key = key
        self.screen.blit(self._static_surf, cam.rect.topleft)

    def draw_canvas(self) -> None:
        scr, cam = self.screen, self.cam
        old = scr.get_clip()
        scr.set_clip(self.canvas_rect)
        self._static_layer()
        if self.mode == "edit":
            canvas.draw_edit_vehicles(scr, cam, self.layout, self.level, self.show_ghost)
            res = self.validation()
            canvas.draw_issue_cells(scr, cam, res.cells("error"), res.cells("warning"), self.level)
            canvas.draw_labels(scr, cam, self.layout, self.level, self.show_labels)
            self.editor.draw_overlay(scr, cam)
            if not self.layout.by_id:
                self._empty_hint()
        elif self.engine is not None:
            eng = self.engine
            self.fx.sync(eng, self.dt, self.speed, self.running and not eng.ended)
            canvas.draw_sim(scr, cam, eng, self.level, self.show_ghost, self.show_labels or cam.zoom >= 60,
                            self.hover_entity, self.fx, self._anim_cells)
            if self.hover_cell is not None and self.modal is None:
                wx, wy = cam.s2w(*pygame.mouse.get_pos())
                self.hover_entity = canvas.pick_entity(eng, self.level, wx, wy)
                if self.hover_entity is not None:
                    from matflow.ui.widgets import Tooltip
                    mx, my = pygame.mouse.get_pos()
                    self.ui.tooltip = Tooltip(canvas.describe_entity(eng, self.hover_entity), (mx + 16, my + 16))
            else:
                self.hover_entity = None
            self._sim_banner(eng)
        # Ebenen-Badge
        badge = f"Ebene E{self.level}"
        s = T.text_surface(badge, 13, (255, 255, 255), True)
        r = s.get_rect(topleft=(self.canvas_rect.x + 12, self.canvas_rect.y + 10)).inflate(18, 10)
        pygame.draw.rect(scr, T.BADGE, r, border_radius=8)
        scr.blit(s, s.get_rect(center=r.center))
        scr.set_clip(old)

    def _empty_hint(self) -> None:
        r = self.canvas_rect
        lines = ["Leere Anlage", "Komponente links wählen und auf das Raster klicken oder eine Linie ziehen.",
                 "Oben „Beispiel“ lädt eine Testanlage."]
        y = r.centery - 40
        for i, ln in enumerate(lines):
            self.ui.text(ln, (r.centerx, y), 18 if i == 0 else 14, T.TEXT_DIM, bold=i == 0, anchor="center")
            y += 30 if i == 0 else 24

    def _sim_banner(self, eng: Engine) -> None:
        scr = self.screen
        r = self.canvas_rect
        if eng.ended:
            full = "LAGER VOLL" in eng.end_reason
            text = "SIMULATION BEENDET: " + eng.end_reason
            s = T.text_surface(text, 20, (255, 255, 255), True)
            box = s.get_rect(midtop=(r.centerx, r.y + 14)).inflate(40, 20)
            pygame.draw.rect(scr, (185, 28, 28) if full else T.BADGE, box, border_radius=10)
            scr.blit(s, s.get_rect(center=box.center))
            sub = f"Simulationszeit {panels.fmt_time(eng.time)}  ·  Zustand bleibt sichtbar  ·  Reset, Neustart oder Konstruktion wählen"
            self.ui.text(sub, (r.centerx, box.bottom + 14), 13, T.TEXT, anchor="center")
        elif not self.running:
            s = T.text_surface("PAUSIERT  ·  Leertaste startet", 14, (255, 255, 255), True)
            box = s.get_rect(midtop=(r.centerx, r.y + 12)).inflate(28, 12)
            pygame.draw.rect(scr, T.WARN, box, border_radius=8)
            scr.blit(s, s.get_rect(center=box.center))

    # ------------------------------------------------------------------ Hauptschleife
    def frame(self, events: list[pygame.event.Event], dt: float) -> None:
        """Ein Frame: Eingaben verarbeiten, Simulation fortschreiben, alles zeichnen."""
        self.dt = min(dt, 0.1)
        if self._web_open:
            got = web.poll_file()
            if got is not None:
                self._web_open = False
                self._open_path(Path(got[0]), got[1])
        for ev in events:
            if ev.type == pygame.QUIT:
                self.request_quit()
            elif ev.type == pygame.VIDEORESIZE and not web.IS_WEB:
                self._set_screen((max(1000, ev.w), max(640, ev.h)), pygame.RESIZABLE)
        self.ui.begin(events)
        self.ui.modal_active = self.modal is not None
        if self.mode == "sim" and self.engine is not None and self.running and not self.engine.ended:
            self.engine.advance(min(dt, 0.1) * self.speed)
            if self.engine.ended:
                self.running = False
                self.status(f"Simulation beendet: {self.engine.end_reason}")
        self.screen.fill(T.BG)
        # Panels zuerst (verbrauchen Klicks/Eingaben), dann Zeichenfläche
        panels.draw_topbar(self)
        panels.draw_left(self)
        self.right.draw()
        for ev in events:
            if ev.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION, pygame.MOUSEWHEEL):
                if ev.type == pygame.MOUSEBUTTONDOWN and self.ui.consumed:
                    continue
                self.handle_canvas(ev)
            elif ev.type == pygame.KEYDOWN:
                self.handle_keys(ev)
        self.draw_canvas()
        panels.draw_status(self)
        panels.draw_modal(self)
        self.ui.end()

    def _set_screen(self, size: tuple[int, int], flags: int = 0) -> None:
        self.screen = pygame.display.set_mode(size, flags)
        self.ui.screen = self.screen
        self._layout_rects()

    def _web_fit(self) -> bool:
        """Browser: Zeichenfläche an geänderte Fenstergröße anpassen (alle 15 Durchläufe geprüft)."""
        self._web_frames += 1
        if self._web_frames % 15:
            return False
        size = web.canvas_size()
        if size == self.screen.get_size():
            return False
        self._set_screen(size)
        return True

    def _update_title(self) -> None:
        title = f"MatFlow 2D – {self.layout.name}{' *' if self.dirty else ''}"
        if pygame.display.get_caption()[0] != title:
            pygame.display.set_caption(title)

    def _tick(self) -> None:
        dt = self.clock.tick(60) / 1000.0
        self.frame(pygame.event.get(), dt)
        self._update_title()
        pygame.display.flip()

    def run(self) -> None:
        while not self.quit:
            self._tick()
        pygame.quit()

    async def run_async(self) -> None:
        """Browser-Version: gibt nach jedem Frame an den Browser ab."""
        # Python im Browser ist deutlich langsamer: max. 30 Bilder/s und nur neu
        # zeichnen, wenn sich etwas ändern kann (Eingaben, laufende Simulation)
        active_until = drawn_at = 0.0
        pending = 0.0
        while True:
            resized = self._web_fit()
            pending += self.clock.tick(30) / 1000.0
            events = pygame.event.get()
            now = time.monotonic()
            if events or resized or (self.mode == "sim" and self.running) or self._web_open:
                active_until = now + 0.4  # Hover- und Statuswechsel noch nachzeichnen
            if now < active_until or now - drawn_at > 0.5:
                self.frame(events, pending)
                self._update_title()
                pygame.display.flip()
                pending, drawn_at = 0.0, now
            await asyncio.sleep(0)


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    try:
        app = App(argv[0] if argv else None)
        app.run()
    except Exception:
        log = APP_DIR / "fehler.log"
        log.write_text(traceback.format_exc(), encoding="utf-8")
        traceback.print_exc()
        return 1
    return 0
