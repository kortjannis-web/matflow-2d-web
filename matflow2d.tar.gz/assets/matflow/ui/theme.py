"""Farben, Maße und Schriften."""
from __future__ import annotations

import os

import pygame

# Oberfläche (ruhiges Slate-Schema)
BG = (238, 242, 247)
PANEL = (255, 255, 255)
PANEL_BORDER = (224, 230, 238)
TOPBAR = (17, 24, 39)
TOPBAR_TEXT = (203, 213, 225)
TOPBAR_DIM = (148, 163, 184)
TEXT = (15, 23, 42)
TEXT_DIM = (84, 98, 118)
ACCENT = (37, 99, 235)
ACCENT_SOFT = (225, 234, 254)
BTN = (248, 250, 252)
BTN_HOVER = (236, 241, 247)
BTN_BORDER = (210, 218, 229)
BTN_DARK = (31, 41, 55)
BTN_DARK_HOVER = (55, 65, 81)
INPUT_BG = (255, 255, 255)
DANGER = (220, 38, 38)
WARN = (180, 83, 9)
OK = (21, 128, 61)
SECTION = (84, 98, 118)
TILE = (248, 250, 252)
TILE_BORDER = (226, 232, 240)
BAR_BG = (226, 232, 240)
STATUSBAR = (241, 245, 249)
BADGE = (30, 41, 59)

# Zeichenfläche
CANVAS_BG = (250, 251, 253)
GRID_OUT = (226, 231, 238)          # außerhalb der bebaubaren Fläche
GRID_OUT_HATCH = (215, 221, 230)
GRID_INK = (110, 124, 146)          # Rasterlinien (werden je nach Rasterstärke aufgehellt)
AREA_BORDER = (71, 85, 105)         # Rand der bebaubaren Fläche

# Komponenten
CONVEYOR = (176, 186, 200)          # Förderrahmen / Grundplatte
ROLLER = (226, 231, 238)            # Rolle (Oberseite)
ROLLER_DARK = (140, 151, 168)       # Rolle (Kante)
CONVEYOR_WALL = (51, 65, 85)
CONVEYOR_SWITCH = (190, 206, 230)
ARROW = (71, 85, 105)
LIFT = (180, 208, 240)
LIFT_STRIPE = (110, 150, 205)
SOURCE = (134, 204, 150)
SOURCE_DARK = (22, 110, 55)
RAIL_BG = (243, 242, 237)
RAIL = (71, 76, 88)
RAIL_TIE = (214, 208, 196)
RAIL_ARROW_OFF = (170, 178, 190)
RAIL_ARROW_ON = (37, 99, 235)
SWITCH_BG = (232, 240, 251)
SWITCH_RAIL = (37, 99, 235)
SINK = (167, 233, 190)
SINK_DARK = (21, 128, 61)
NIO = (254, 208, 208)
NIO_DARK = (185, 28, 28)
RBG_RAIL_BG = (244, 239, 231)
RBG_RAIL = (96, 76, 56)
STORAGE_FRAME = (150, 122, 92)
STORAGE_POST = (104, 84, 62)
STORAGE_FREE = (255, 255, 255)
STORAGE_RESERVED = (234, 179, 8)
CONTAINER = (214, 124, 52)
CONTAINER_BORDER = (120, 60, 18)
CONTAINER_NIO = (239, 68, 68)
CONTAINER_NIO_BORDER = (127, 29, 29)
CONTAINER_OUT = (20, 184, 166)
CONTAINER_OUT_BORDER = (17, 94, 89)
EPB = (250, 204, 21)
EPB_BORDER = (66, 54, 10)
EPB_DECK = (253, 230, 138)
RBG = (249, 115, 22)
RBG_BORDER = (100, 44, 8)
RBG_ARM = (100, 108, 120)
RBG_MAST = (51, 65, 85)
RBG_CARRIAGE = (203, 213, 225)
SHADOW = (15, 23, 42)
SELECT = (6, 182, 212)
ERROR_CELL = (220, 38, 38)
WARN_CELL = (217, 119, 6)
GHOST = (208, 212, 220)
GHOST_DARK = (170, 176, 188)
FLASH = (56, 189, 248)

# Status-LEDs der Fahrzeuge (immer zusammen mit Text in Legende/Tooltip)
LED_MOVE = (34, 197, 94)
LED_WAIT = (245, 158, 11)
LED_LOAD = (59, 130, 246)
LED_IDLE = (148, 163, 184)

TOP_H = 50
LEFT_W = 214
RIGHT_W = 350
STATUS_H = 26

_fonts: dict[tuple[int, bool, bool], pygame.font.Font] = {}
# Windows-Schriften, sonst die mitgelieferte DejaVu (Browser-Version, andere Systeme)
_FONT_DIRS = [os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
              os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")]
_REGULAR = ("segoeui.ttf", "arial.ttf", "DejaVuSans.ttf")
_BOLD = ("segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf")
_SYMBOL = ("seguisym.ttf", "DejaVuSans.ttf")
SYMBOL_CHARS = set("↶↷◀▶✓❚■●▲▼")


def _find(names) -> str | None:
    for d in _FONT_DIRS:
        for n in names:
            p = os.path.join(d, n)
            if os.path.exists(p):
                return p
    return None


def font(size: int = 14, bold: bool = False, symbol: bool = False) -> pygame.font.Font:
    key = (size, bold, symbol)
    f = _fonts.get(key)
    if f is None:
        path = _find(_SYMBOL if symbol else (_BOLD if bold else _REGULAR))
        if path:
            # DejaVu läuft breiter als Segoe UI: etwas kleiner, damit Beschriftungen passen
            f = pygame.font.Font(path, round(size * 0.9) if "DejaVu" in path else size)
            if symbol and bold:
                f.set_bold(True)
        else:
            f = pygame.font.SysFont("segoeui,arial,helvetica", size, bold=bold)
        _fonts[key] = f
    return f


def font_for(text: str, size: int = 14, bold: bool = False) -> pygame.font.Font:
    """Wählt die Symbolschrift, wenn der Text Sonderzeichen enthält."""
    if any(ch in SYMBOL_CHARS for ch in text):
        return font(size, bold, symbol=True)
    return font(size, bold)


_texts: dict[tuple, pygame.Surface] = {}


def text_surface(text: str, size: int = 14, color=TEXT, bold: bool = False) -> pygame.Surface:
    """Gerenderter Text aus dem Cache (Rendern ist teuer, die meisten Texte wiederholen sich jedes Frame)."""
    key = (text, size, bold, color)
    s = _texts.get(key)
    if s is None:
        if len(_texts) > 4000:
            _texts.clear()
        s = font_for(text, size, bold).render(text, True, color)
        _texts[key] = s
    return s
