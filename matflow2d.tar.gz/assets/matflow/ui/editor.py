"""Konstruktionseditor: Werkzeuge, Platzieren/Zeichnen, Auswahl, Verschieben, Drehen, Undo/Redo."""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import pygame

from matflow.core.geometry import Cell, dir_between
from matflow.model.components import (
    BRANCH_MODES, BRANCH_NAMES, CONVEYOR, CONVEYOR_SWITCH, EPB, EPB_CURVE, EPB_RAIL, EPB_SWITCH, LIFT, NIO, RBG,
    RBG_RAIL, SINK, SOURCE, STORAGE, STATIC, TYPES, VEHICLE, Component, curve_for_turn,
)
from matflow.model.layout import Layout, LayoutError
from matflow.ui import render
from matflow.ui import theme as T
from matflow.ui.camera import Camera

if TYPE_CHECKING:
    from matflow.ui.app import App

SELECT_TOOL = "select"
ERASE_TOOL = "erase"
CONTAINER_TOOL = "container"


@dataclass
class Tool:
    key: str
    name: str
    shortcut: str
    hint: str
    enabled: bool = True


TOOLS: list[Tool] = [
    Tool(SELECT_TOOL, "Auswählen", "V", "Klicken = wählen, Ziehen = verschieben / Rahmen"),
    Tool(CONVEYOR, "Fördertechnik", "1", "Klicken oder Linie ziehen (Richtung folgt der Maus)"),
    Tool(CONVEYOR_SWITCH, "FT-Weiche", "G", "Gabelung; Klick auf Fördertechnik ersetzt sie. R drehen, "
                                            "M Abzweig rechts/links/beidseitig"),
    Tool(LIFT, "Heber", "2", "Linie ziehen; Zielebene rechts einstellen"),
    Tool(SOURCE, "Quelle", "3", "Behälterursprung; Pfeil zeigt zum Förderer"),
    Tool(EPB_RAIL, "EPB-Schiene", "4", "Linie ziehen; Ecken werden automatisch Kurven"),
    Tool(EPB_CURVE, "EPB-Kurve", "5", "Einzelne 90°-Kurve; R drehen, F Richtung"),
    Tool(EPB_SWITCH, "EPB-Weiche", "W", "In Schienenstrang setzen; R drehen, F Verzweigung/Zusammenführung, "
                                        "M Abzweig spiegeln"),
    Tool(RBG_RAIL, "RBG-Schiene", "6", "Gerade Linie ziehen"),
    Tool(STORAGE, "Lagerplatz", "7", "Seitlich an RBG-Schiene setzen"),
    Tool(CONTAINER_TOOL, "Behälter", "8", "Lagerplatz manuell vorbelegen (Klick = an/aus)"),
    Tool(EPB, "EPB", "9", "Fahrzeug auf EPB-Schiene setzen"),
    Tool(RBG, "RBG", "0", "Regalbediengerät auf RBG-Schiene setzen"),
    Tool(SINK, "Ausgang", "A", "Ziel der Auslagerung; Fördertechnik muss hineinführen"),
    Tool(NIO, "NIO-Ausgang", "N", "Ziel fehlerhafter Behälter (NIO-Anteil rechts einstellen)"),
    Tool(ERASE_TOOL, "Radierer", "X", "Klicken/Ziehen löscht; Größe 1x1 bis 5x5 links oder mit [ und ]"),
]
TOOL_BY_KEY = {t.key: t for t in TOOLS}
PAINT_TYPES = (CONVEYOR, LIFT, EPB_RAIL, RBG_RAIL, STORAGE)


class Editor:
    def __init__(self, app: "App"):
        self.app = app
        self.tool = SELECT_TOOL
        self.tool_rot = 1
        self.tool_flip = False
        self.tool_mirror = False
        self.tool_branch = "right"
        self.clipboard: list[dict[str, Any]] = []
        self.selection: set[str] = set()
        self.drag: dict[str, Any] | None = None
        self.undo_stack: list[str] = []
        self.redo_stack: list[str] = []
        self.hover: Cell | None = None

    @property
    def layout(self) -> Layout:
        return self.app.layout

    @property
    def level(self) -> int:
        return self.app.level

    # ------------------------------------------------------------------ Undo
    def push_undo(self) -> None:
        self.undo_stack.append(json.dumps(self.layout.to_dict()))
        if len(self.undo_stack) > 200:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def _restore(self, snap: str) -> None:
        self.app.set_layout(Layout.from_dict(json.loads(snap)), keep_view=True, keep_history=True)
        self.selection = {i for i in self.selection if i in self.layout.by_id}

    def undo(self) -> None:
        if not self.undo_stack:
            self.app.status("Nichts rückgängig zu machen")
            return
        self.redo_stack.append(json.dumps(self.layout.to_dict()))
        self._restore(self.undo_stack.pop())
        self.app.changed(push=False)
        self.app.status("Rückgängig")

    def redo(self) -> None:
        if not self.redo_stack:
            return
        self.undo_stack.append(json.dumps(self.layout.to_dict()))
        self._restore(self.redo_stack.pop())
        self.app.changed(push=False)
        self.app.status("Wiederhergestellt")

    # ------------------------------------------------------------------ Werkzeug
    def set_tool(self, key: str) -> None:
        t = TOOL_BY_KEY.get(key)
        if t is None or not t.enabled:
            self.app.status(f"{t.name if t else key}: nicht verfügbar")
            return
        self.tool = key
        self.drag = None
        if key != SELECT_TOOL:
            self.selection.clear()
        self.app.status(f"Werkzeug: {t.name}  ·  {t.hint}")

    def selected(self) -> list[Component]:
        return [self.layout.by_id[i] for i in sorted(self.selection) if i in self.layout.by_id]

    # ------------------------------------------------------------------ Aktionen auf Auswahl
    def rotate(self, k: int = 1) -> None:
        if self.selection:
            self.push_undo()
            comps = self.selected()
            if len(comps) == 1 and comps[0].spec.layer == STATIC:
                c = comps[0]
                ids = {c.id}
                old = c.rot
                c.rot = (c.rot + k) % 4
                ok, why = self.layout.can_place(c.type, c.cell, ignore=ids, props=c.props)
                if not ok:
                    c.rot = old
                    self.undo_stack.pop()
                    self.app.status(f"Drehen nicht möglich: {why}")
                    return
            elif not self.layout.rotate_group(self.selection, k):
                self.undo_stack.pop()
                self.app.status("Drehen nicht möglich: Zielzellen belegt oder außerhalb")
                return
            self.app.changed(push=False)
            self.app.status(f"{len(comps)} Element(e) gedreht")
        else:
            self.tool_rot = (self.tool_rot + k) % 4
            self.app.status(f"Werkzeug-Richtung: {['Nord', 'Ost', 'Süd', 'West'][self.tool_rot]}")

    def flip(self) -> None:
        if self.selection:
            self.push_undo()
            for c in self.selected():
                c.flip()
            self.app.changed(push=False)
            self.app.status("Fahrtrichtung / Förderrichtung umgeschaltet")
        else:
            if self.tool == EPB_CURVE:
                self.tool_flip = not self.tool_flip
            elif self.tool == EPB_SWITCH:
                self.tool_rot = (self.tool_rot + 2) % 4
                self.tool_flip = not self.tool_flip
                self.tool_mirror = not self.tool_mirror
            else:
                self.tool_rot = (self.tool_rot + 2) % 4
            self.app.status("Werkzeug-Richtung umgekehrt")

    def mirror(self) -> None:
        """Weiche: Abzweig auf die andere Seite legen (FT-Weiche: rechts → links → beidseitig)."""
        ft = [c for c in self.selected() if c.type == CONVEYOR_SWITCH]
        if ft:
            self.push_undo()
            for c in ft:
                c.props["branch"] = BRANCH_MODES[(BRANCH_MODES.index(c.branch_mode) + 1) % len(BRANCH_MODES)]
            self.app.changed(push=False)
            self.app.status(f"FT-Weiche: Abzweig {BRANCH_NAMES[ft[0].branch_mode]}")
            return
        if not self.selection and self.tool == CONVEYOR_SWITCH:
            self.tool_branch = BRANCH_MODES[(BRANCH_MODES.index(self.tool_branch) + 1) % len(BRANCH_MODES)]
            self.app.status(f"FT-Weiche: Abzweig {BRANCH_NAMES[self.tool_branch]}")
            return
        sw = [c for c in self.selected() if c.type == EPB_SWITCH]
        if sw:
            self.push_undo()
            for c in sw:
                c.props["mirror"] = not c.props.get("mirror", False)
            self.app.changed(push=False)
            self.app.status(f"{len(sw)} Weiche(n) gespiegelt")
        elif self.tool == EPB_SWITCH:
            self.tool_mirror = not self.tool_mirror
            self.app.status("Weiche: Abzweig " + ("links" if self.tool_mirror else "rechts"))
        else:
            self.app.status("Spiegeln gilt nur für Weichen")

    def toggle_merge(self, c: Component) -> None:
        self.push_undo()
        c.props["merge"] = not c.props.get("merge", False)
        self.app.changed(push=False)

    # ------------------------------------------------------------------ Kopieren / Einfügen
    def copy(self) -> None:
        if not self.selection:
            self.app.status("Nichts ausgewählt")
            return
        self.clipboard = self.layout.copy_group(self.selection)
        self.app.status(f"{len(self.clipboard)} Element(e) kopiert. Strg+V fügt an der Mausposition ein")

    def paste(self, at: Cell | None) -> None:
        if not self.clipboard:
            self.app.status("Zwischenablage ist leer")
            return
        minx = min(d["x"] for d in self.clipboard)
        miny = min(d["y"] for d in self.clipboard)
        minl = min(d.get("level", 0) for d in self.clipboard)
        if at is None:
            dx, dy = 2, 2
            dl = 0
        else:
            dx, dy, dl = at[0] - minx, at[1] - miny, at[2] - minl
        self.push_undo()
        try:
            added = self.layout.paste_group(self.clipboard, dx, dy, dl)
        except LayoutError as e:
            self.undo_stack.pop()
            self.app.status(f"Einfügen nicht möglich: {e}")
            return
        self.tool = SELECT_TOOL
        self.selection = {c.id for c in added}
        self.app.changed(push=False)
        self.app.status(f"{len(added)} Element(e) eingefügt (neue IDs)")

    def delete_selection(self) -> None:
        if not self.selection:
            return
        self.push_undo()
        n = 0
        for cid in list(self.selection):
            n += len(self.layout.remove(cid))
        self.selection.clear()
        self.app.changed(push=False)
        self.app.status(f"{n} Element(e) gelöscht")

    def move_selection(self, dx: int, dy: int, dlevel: int = 0) -> None:
        if not self.selection:
            return
        self.push_undo()
        if self.layout.move_group(self.selection, dx, dy, dlevel):
            self.selection = self.layout.with_attached_vehicles(self.selection)
            if dlevel:
                self.app.level = max(0, min(self.layout.levels - 1, self.app.level + dlevel))
            self.app.changed(push=False)
        else:
            self.undo_stack.pop()
            self.app.status("Verschieben nicht möglich: Ziel belegt oder außerhalb des Rasters")

    def select_all(self) -> None:
        self.selection = {c.id for c in self.layout.by_id.values() if c.level == self.level}
        self.app.status(f"{len(self.selection)} Elemente ausgewählt")

    # ------------------------------------------------------------------ Platzieren
    def _default_props(self, ctype: str, cell: Cell) -> dict[str, Any]:
        if ctype == LIFT:
            return {"target_level": self.layout.default_lift_target(cell[2])}
        if ctype == EPB_CURVE:
            return {"reverse": self.tool_flip}
        if ctype == EPB_SWITCH:
            return {"merge": self.tool_flip, "mirror": self.tool_mirror}
        if ctype == CONVEYOR_SWITCH:
            return {"branch": self.tool_branch}
        return {}

    def place(self, ctype: str, cell: Cell, rot: int, quiet: bool = False) -> Component | None:
        props = self._default_props(ctype, cell)
        ok, why = self.layout.can_place(ctype, cell, props=props)
        if not ok:
            if not quiet:
                self.app.status(f"Nicht platzierbar: {why}")
            return None
        try:
            return self.layout.add(ctype, cell, rot=rot, props=props)
        except LayoutError as e:
            if not quiet:
                self.app.status(f"Nicht platzierbar: {e}")
            return None

    def _family(self, comp: Component | None) -> bool:
        if comp is None:
            return False
        if self.tool in (EPB_RAIL, EPB_CURVE):
            return comp.type in (EPB_RAIL, EPB_CURVE)
        return comp.type == self.tool

    def _orient(self, cell: Cell, din: int | None, dout: int) -> None:
        comp = self.layout.static.get(cell)
        if not self._family(comp):
            return
        if self.tool == EPB_RAIL:
            if din is None and comp.type == EPB_CURVE:
                return
            turn = curve_for_turn(din, dout) if din is not None and din != dout else None
            try:
                if turn is not None:
                    rot, rev = turn
                    if comp.type == EPB_CURVE:
                        comp.rot, comp.props["reverse"] = rot, rev
                    else:
                        self.layout.replace(comp.id, EPB_CURVE, rot, {"reverse": rev})
                else:
                    if comp.type == EPB_CURVE:
                        self.layout.replace(comp.id, EPB_RAIL, dout)
                    else:
                        comp.rot = dout
            except LayoutError:
                pass
        elif self.tool in (CONVEYOR, LIFT, RBG_RAIL):
            old = comp.rot
            comp.rot = dout
            ok, _ = self.layout.can_place(comp.type, comp.cell, ignore={comp.id}, props=comp.props)
            if not ok:
                comp.rot = old

    def _paint_to(self, cell: Cell) -> None:
        st = self.drag
        prev: Cell = st["last"]
        while prev != cell:
            dx = (cell[0] > prev[0]) - (cell[0] < prev[0])
            dy = (cell[1] > prev[1]) - (cell[1] < prev[1])
            if dx != 0 and (dy == 0 or abs(cell[0] - prev[0]) >= abs(cell[1] - prev[1])):
                nxt = (prev[0] + dx, prev[1], prev[2])
            else:
                nxt = (prev[0], prev[1] + dy, prev[2])
            d = dir_between(prev, nxt)
            if TYPES[self.tool].directional:
                self._orient(prev, st["din"], d)
            existing = self.layout.static.get(nxt)
            if existing is None:
                self.place(self.tool, nxt, d, quiet=True)
            if TYPES[self.tool].directional:
                if nxt == st["first"] and st["first_out"] is not None:
                    self._orient(nxt, d, st["first_out"])      # Ring geschlossen
                else:
                    self._orient(nxt, d, d)
            if st["first_out"] is None:
                st["first_out"] = d
            st["din"] = d
            prev = nxt
        st["last"] = cell

    # ------------------------------------------------------------------ Maus
    def hit(self, cell: Cell) -> Component | None:
        v = self.layout.vehicles.get(cell)
        s = self.layout.static.get(cell)
        if v is not None and not (self.selection == {v.id}):
            return v
        return s or v

    def mouse_down(self, cell: Cell, mods: int) -> None:
        lay = self.layout
        tool = self.tool
        if tool == SELECT_TOOL:
            comp = self.hit(cell)
            shift = mods & pygame.KMOD_SHIFT
            ctrl = mods & pygame.KMOD_CTRL
            if comp is not None:
                if shift or ctrl:
                    self.selection ^= {comp.id}
                elif comp.id not in self.selection:
                    self.selection = {comp.id}
                self.drag = {"mode": "move", "start": cell, "cur": cell}
            else:
                if not (shift or ctrl):
                    self.selection.clear()
                self.drag = {"mode": "box", "start": cell, "cur": cell}
            return
        if tool == ERASE_TOOL:
            self.push_undo()
            self.drag = {"mode": "erase", "n": 0}
            self._erase(cell)
            return
        if tool == CONVEYOR_SWITCH:
            old = lay.static.get(cell)
            if old is not None and old.type == CONVEYOR:
                # FT-Weiche in eine bestehende Förderstrecke setzen: Richtung bleibt erhalten
                self.push_undo()
                try:
                    lay.replace(old.id, CONVEYOR_SWITCH, old.direction, self._default_props(tool, cell))
                    self.app.changed(push=False)
                    self.app.status("Fördertechnik durch FT-Weiche ersetzt (R drehen, M Abzweig wechseln)")
                except LayoutError as e:
                    self.undo_stack.pop()
                    self.app.status(f"Nicht platzierbar: {e}")
                return
        if tool == CONTAINER_TOOL:
            comp = lay.static.get(cell)
            if comp is not None and comp.type == STORAGE:
                self.push_undo()
                comp.props["prefilled"] = not comp.prefilled
                self.app.changed(push=False)
                self.app.status(f"{comp.id}: {'vorbelegt (Behälter eingelagert)' if comp.prefilled else 'frei'}")
            else:
                self.app.status("Behälter können nur auf Lagerplätze gesetzt werden")
            return
        spec = TYPES[tool]
        self.push_undo()
        if tool == EPB_SWITCH:
            old = lay.static.get(cell)
            if old is not None and old.type in (EPB_RAIL, EPB_CURVE):
                # Weiche in einen bestehenden Strang setzen: ersetzt die Schiene, Fahrzeug bleibt
                rot = old.direction if old.type == EPB_RAIL else self.tool_rot
                try:
                    lay.replace(old.id, EPB_SWITCH, rot, self._default_props(tool, cell))
                    self.app.changed(push=False)
                    self.app.status("Schiene durch Weiche ersetzt (R drehen, F umkehren, M spiegeln)")
                except LayoutError as e:
                    self.undo_stack.pop()
                    self.app.status(f"Nicht platzierbar: {e}")
                return
        placed = self.place(tool, cell, self.tool_rot)
        if placed is None and not self._family(lay.at(cell, spec.layer)):
            self.undo_stack.pop()
            return
        if spec.paintable:
            self.drag = {"mode": "paint", "last": cell, "din": None, "first": cell, "first_out": None}
        self.app.changed(push=False)

    @property
    def erase_size(self) -> int:
        return self.app.settings.erase_size

    def erase_cells(self, cell: Cell) -> list[Cell]:
        """Zellen unter dem Radierer (Quadrat, Mauszelle in der Mitte)."""
        n = self.erase_size
        off = (n - 1) // 2
        return [(cell[0] - off + i, cell[1] - off + j, cell[2]) for j in range(n) for i in range(n)]

    def _erase(self, cell: Cell) -> None:
        lay = self.layout
        if self.erase_size == 1:
            comps = [lay.vehicles.get(cell) or lay.static.get(cell)]      # Fahrzeug zuerst
        else:
            comps = [c for cc in self.erase_cells(cell) for c in (lay.vehicles.get(cc), lay.static.get(cc))]
        n = 0
        for comp in comps:
            if comp is not None and comp.id in lay.by_id:
                for r in lay.remove(comp.id):
                    self.selection.discard(r.id)
                n += 1
        if n:
            self.drag["n"] += n
            self.app.changed(push=False)

    def mouse_move(self, cell: Cell) -> None:
        self.hover = cell
        d = self.drag
        if d is None:
            return
        if d["mode"] == "paint":
            if cell != d["last"] and self.layout.in_bounds(cell):
                self._paint_to(cell)
                self.app.changed(push=False)
        elif d["mode"] == "erase":
            self._erase(cell)
        elif d["mode"] in ("move", "box"):
            d["cur"] = cell

    def mouse_up(self, cell: Cell) -> None:
        d = self.drag
        self.drag = None
        if d is None:
            return
        if d["mode"] == "move":
            dx, dy = d["cur"][0] - d["start"][0], d["cur"][1] - d["start"][1]
            if (dx or dy) and self.selection:
                self.move_selection(dx, dy)
        elif d["mode"] == "box":
            x0, x1 = sorted((d["start"][0], d["cur"][0]))
            y0, y1 = sorted((d["start"][1], d["cur"][1]))
            for c in self.layout.by_id.values():
                if c.level == self.level and x0 <= c.x <= x1 and y0 <= c.y <= y1:
                    self.selection.add(c.id)
            if self.selection:
                self.app.status(f"{len(self.selection)} Element(e) ausgewählt")
        elif d["mode"] == "erase" and d["n"] == 0:
            if self.undo_stack:
                self.undo_stack.pop()

    # ------------------------------------------------------------------ Overlay
    def draw_overlay(self, surf: pygame.Surface, cam: Camera) -> None:
        lay = self.layout
        # Auswahl
        for c in self.selected():
            if c.level != self.level:
                continue
            r = cam.cell_rect(c.x, c.y)
            pygame.draw.rect(surf, T.SELECT, r.inflate(2, 2), 3 if c.spec.layer == STATIC else 2,
                             border_radius=3)
        d = self.drag
        if d and d["mode"] == "move":
            dx, dy = d["cur"][0] - d["start"][0], d["cur"][1] - d["start"][1]
            if dx or dy:
                ids = lay.with_attached_vehicles(self.selection)
                for cid in ids:
                    c = lay.by_id[cid]
                    tgt = (c.x + dx, c.y + dy, c.level)
                    ok, _ = lay.can_place(c.type, tgt, ignore=ids, props=c.props)
                    r = cam.cell_rect(tgt[0], tgt[1])
                    s = pygame.Surface(r.size, pygame.SRCALPHA)
                    s.fill((*(T.OK if ok else T.DANGER), 70))
                    surf.blit(s, r)
                    pygame.draw.rect(surf, T.OK if ok else T.DANGER, r, 2)
        if d and d["mode"] == "box":
            x0, x1 = sorted((d["start"][0], d["cur"][0]))
            y0, y1 = sorted((d["start"][1], d["cur"][1]))
            a = cam.w2s(x0, y0)
            b = cam.w2s(x1 + 1, y1 + 1)
            r = pygame.Rect(round(a[0]), round(a[1]), round(b[0] - a[0]), round(b[1] - a[1]))
            s = pygame.Surface(r.size, pygame.SRCALPHA)
            s.fill((*T.SELECT, 40))
            surf.blit(s, r)
            pygame.draw.rect(surf, T.SELECT, r, 1)
        # Vorschau des Werkzeugs
        if self.hover and self.tool not in (SELECT_TOOL, ERASE_TOOL, CONTAINER_TOOL) and not d:
            cell = self.hover
            if lay.in_bounds(cell):
                props = self._default_props(self.tool, cell)
                ok, _ = lay.can_place(self.tool, cell, props=props)
                occ = lay.static.get(cell)
                rot = self.tool_rot
                if self.tool == EPB_SWITCH and occ is not None and occ.type in (EPB_RAIL, EPB_CURVE):
                    ok = True
                if self.tool == CONVEYOR_SWITCH and occ is not None and occ.type == CONVEYOR:
                    ok, rot = True, occ.direction
                r = cam.cell_rect(cell[0], cell[1])
                s = pygame.Surface(r.size, pygame.SRCALPHA)
                pcam = Camera(pygame.Rect(0, 0, r.w, r.h), zoom=cam.zoom)
                pcam.ox, pcam.oy = cell[0], cell[1]
                comp = Component("PREVIEW", self.tool, cell[0], cell[1], cell[2], rot, "", props)
                render.draw_component(s, pcam, comp, lay if TYPES[self.tool].layer == VEHICLE else None,
                                      show_text=False)
                s.set_alpha(150)
                surf.blit(s, r)
                pygame.draw.rect(surf, T.OK if ok else T.DANGER, r, 2)
        elif self.hover and self.tool == ERASE_TOOL:
            cells = self.erase_cells((self.hover[0], self.hover[1], self.level))
            a = cam.cell_rect(cells[0][0], cells[0][1])
            b = cam.cell_rect(cells[-1][0], cells[-1][1])
            r = a.union(b)
            s = pygame.Surface(r.size, pygame.SRCALPHA)
            s.fill((*T.DANGER, 38))
            surf.blit(s, r)
            pygame.draw.rect(surf, T.DANGER, r, 2, border_radius=2)
