"""Datei-Dialoge (tkinter, falls verfügbar)."""
from __future__ import annotations

from pathlib import Path

FILETYPES = [("MatFlow-Projekt", "*.mfp"), ("JSON", "*.json"), ("Alle Dateien", "*.*")]


def _root():
    import tkinter as tk
    root = tk.Tk()
    root.withdraw()
    try:
        root.attributes("-topmost", True)
    except Exception:
        pass
    return root


def ask_open(initialdir: Path) -> str | None:
    try:
        from tkinter import filedialog
        root = _root()
        p = filedialog.askopenfilename(parent=root, title="Projekt öffnen", initialdir=str(initialdir),
                                       filetypes=FILETYPES)
        root.destroy()
        return p or None
    except Exception:
        return None


def ask_save(initialdir: Path, initialfile: str) -> str | None:
    try:
        from tkinter import filedialog
        root = _root()
        p = filedialog.asksaveasfilename(parent=root, title="Projekt speichern", initialdir=str(initialdir),
                                         initialfile=initialfile, defaultextension=".mfp", filetypes=FILETYPES)
        root.destroy()
        return p or None
    except Exception:
        return None


def available() -> bool:
    try:
        import tkinter  # noqa: F401
        return True
    except Exception:
        return False
