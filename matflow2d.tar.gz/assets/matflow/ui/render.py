"""Zeichnen von Raster, Komponenten, Fahrzeugen und Behältern.

Leistung: Häufig gezeichnete Objekte (Behälter, Schatten, LEDs, Blitze, laufende Förderzellen) werden einmal
je Zoomstufe als Sprite vorberechnet und danach nur noch geblittet. Die statische Anlage cacht die App.
"""
from __future__ import annotations

import math
from functools import lru_cache

import pygame

from matflow.core.geometry import DVEC, center, corner, edge_mid, neighbor, opposite
from matflow.model.components import (
    CONVEYOR, CONVEYOR_SWITCH, EPB, EPB_CURVE, EPB_RAIL, EPB_RAIL_TYPES, EPB_SWITCH, EXIT_TYPES, FLOW_TYPES, LIFT, NIO, RBG,
    RBG_RAIL, SINK, SOURCE, STORAGE, Component,
)
from matflow.model.layout import Layout
from matflow.ui import theme as T
from matflow.ui.camera import Camera

ROLLERS_PER_M = 4            # Rollenteilung 0,25 m
ROLLER_PHASES = 8            # vorberechnete Drehstellungen je Förderzelle
FLASH_T = 0.45               # Dauer eines Übergabe-Blitzes (s, Echtzeit)
FLASH_FRAMES = 10


@lru_cache(maxsize=4096)
def _mix(c, target=(255, 255, 255), f=0.6):
    return tuple(int(a + (b - a) * f) for a, b in zip(c, target))


# ---------------------------------------------------------------------- Sprite-Cache
# je Zoomstufe ein eigener Cache; nur die zuletzt benutzten Zoomstufen bleiben erhalten (Speicher)
_sprites: dict[object, dict[tuple, object]] = {}
_MAX_ZOOMS = 3
_MAX_PER_ZOOM = 2500


def _cached(zoom, key: tuple, make):
    bucket = _sprites.get(zoom)
    if bucket is None:
        zooms = [k for k in _sprites if k is not None]      # Bucket None = zoomunabhängig
        if zoom is not None and len(zooms) >= _MAX_ZOOMS:
            for old in zooms[:len(zooms) - _MAX_ZOOMS + 1]:
                del _sprites[old]
        bucket = _sprites[zoom] = {}
    else:
        # zuletzt benutzt ans Ende
        _sprites[zoom] = _sprites.pop(zoom)
    s = bucket.get(key)
    if s is None:
        if len(bucket) > _MAX_PER_ZOOM:
            bucket.clear()
        s = make()
        bucket[key] = s
    return s


def _alpha(s: pygame.Surface) -> pygame.Surface:
    return s.convert_alpha() if pygame.display.get_surface() else s


def _blur(surf: pygame.Surface, radius: int) -> pygame.Surface:
    if radius <= 0:
        return surf
    try:
        return pygame.transform.gaussian_blur(surf, radius)
    except (AttributeError, ValueError, pygame.error):
        w, h = surf.get_size()
        k = max(1, radius)
        small = pygame.transform.smoothscale(surf, (max(1, w // k), max(1, h // k)))
        return pygame.transform.smoothscale(small, (w, h))


def shadow_sprite(w: int, h: int, radius: int, alpha: int = 70) -> tuple[pygame.Surface, int]:
    """Weicher Schlagschatten für ein Rechteck w×h px; liefert (Sprite, Rand)."""
    def make():
        pad = radius * 2 + 2
        s = pygame.Surface((w + 2 * pad, h + 2 * pad), pygame.SRCALPHA)
        pygame.draw.rect(s, (*T.SHADOW, alpha), (pad, pad, w, h), border_radius=max(1, min(w, h) // 5))
        return _blur(s, radius), pad
    return _cached(None, ("shadow", w, h, radius, alpha), make)


def glow_sprite(radius: int, color) -> pygame.Surface:
    def make():
        size = radius * 6
        s = pygame.Surface((size, size), pygame.SRCALPHA)
        pygame.draw.circle(s, (*color, 110), (size // 2, size // 2), radius * 2)
        return _blur(s, max(1, radius))
    return _cached(None, ("glow", radius, color), make)


# ---------------------------------------------------------------------- Grundformen
def arrow(surf, cam: Camera, x: float, y: float, ang: float, size: float, color, width: int = 0) -> None:
    """Pfeilspitze (Dreieck) in Weltkoordinaten, ang = Fahrtwinkel, size in m."""
    ca, sa = math.cos(ang), math.sin(ang)
    tip = (x + ca * size * 0.6, y + sa * size * 0.6)
    bl = (x - ca * size * 0.4 - sa * size * 0.5, y - sa * size * 0.4 + ca * size * 0.5)
    br = (x - ca * size * 0.4 + sa * size * 0.5, y - sa * size * 0.4 - ca * size * 0.5)
    pts = [cam.w2s(*tip), cam.w2s(*bl), cam.w2s(*br)]
    pygame.draw.polygon(surf, color, pts, width)


def chevron(surf, cam: Camera, x: float, y: float, ang: float, size: float, color, w: float) -> None:
    ca, sa = math.cos(ang), math.sin(ang)
    tip = (x + ca * size * 0.35, y + sa * size * 0.35)
    l = (x - ca * size * 0.25 - sa * size * 0.4, y - sa * size * 0.25 + ca * size * 0.4)
    r = (x - ca * size * 0.25 + sa * size * 0.4, y - sa * size * 0.25 - ca * size * 0.4)
    pygame.draw.lines(surf, color, False, [cam.w2s(*l), cam.w2s(*tip), cam.w2s(*r)], max(2, int(w)))


def dir_angle(d: int) -> float:
    dx, dy = DVEC[d]
    return math.atan2(dy, dx)


def rot_rect_pts(cam: Camera, x: float, y: float, w: float, h: float, ang: float):
    ca, sa = math.cos(ang), math.sin(ang)
    pts = []
    for px, py in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)):
        pts.append(cam.w2s(x + px * ca - py * sa, y + px * sa + py * ca))
    return pts


def _local(ang: float, x: float, y: float, fx: float, fy: float) -> tuple[float, float]:
    """Punkt im Fahrzeugsystem (fx vorwärts, fy seitlich) → Welt."""
    ca, sa = math.cos(ang), math.sin(ang)
    return x + fx * ca - fy * sa, y + fx * sa + fy * ca


def _hatch(w: int, h: int) -> pygame.Surface:
    def make():
        s = pygame.Surface((w, h))
        s.fill(T.GRID_OUT)
        for k in range(-h, w + h, 14):
            pygame.draw.line(s, T.GRID_OUT_HATCH, (k, h), (k + h, 0))
        return s.convert() if pygame.display.get_surface() else s
    return _cached(None, ("hatch", w, h), make)


def draw_grid(surf, cam: Camera, lay: Layout, show_grid: bool = True, strength: int = 35,
              show_border: bool = True) -> None:
    """Hintergrund, dünnes Raster (1 m, jede 5. Linie kräftiger) und Rand der bebaubaren Fläche."""
    r = cam.rect
    surf.fill(T.GRID_OUT, r)
    x0, y0 = cam.w2s(0, 0)
    x1, y1 = cam.w2s(lay.width, lay.height)
    full = pygame.Rect(round(x0), round(y0), round(x1) - round(x0), round(y1) - round(y0))
    # Außenbereich schraffieren (nicht bebaubar), Schraffur einmal je Fenstergröße vorberechnet
    surf.blit(_hatch(r.w, r.h), r.topleft)
    area = full.clip(r)
    if show_border:
        # einfacher Kantenschatten (kein Weichzeichner: die Fläche kann bei hohem Zoom sehr groß sein)
        for k, f in ((5, 0.06), (3, 0.1), (1, 0.14)):
            pygame.draw.rect(surf, _mix(T.GRID_OUT, T.SHADOW, f), full.move(0, k).inflate(2 * k, 0).clip(r))
    surf.fill(T.CANVAS_BG, area)
    if show_grid and area.w > 0 and area.h > 0:
        f = max(0.05, min(1.0, strength / 100.0))
        minor = _mix(T.GRID_INK, T.CANVAS_BG, 1.0 - 0.45 * f)
        major = _mix(T.GRID_INK, T.CANVAS_BG, 1.0 - min(1.0, 0.8 * f + 0.1))
        cx0, cy0, cx1, cy1 = cam.visible_cells()
        cx0, cy0 = max(0, cx0), max(0, cy0)
        cx1, cy1 = min(lay.width, cx1), min(lay.height, cy1)
        fine = cam.zoom >= 7          # bei sehr kleinem Zoom nur jede 5. Linie
        for x in range(cx0, cx1 + 1):
            if not fine and x % 5:
                continue
            sx = round(cam.w2s(x, 0)[0])
            pygame.draw.line(surf, major if x % 5 == 0 else minor, (sx, area.top), (sx, area.bottom - 1))
        for y in range(cy0, cy1 + 1):
            if not fine and y % 5:
                continue
            sy = round(cam.w2s(0, y)[1])
            pygame.draw.line(surf, major if y % 5 == 0 else minor, (area.left, sy), (area.right - 1, sy))
    if show_border:
        pygame.draw.rect(surf, _mix(T.AREA_BORDER, T.GRID_OUT, 0.55), full.inflate(6, 6), 2, border_radius=3)
        pygame.draw.rect(surf, T.AREA_BORDER, full.inflate(2, 2), 2)


def open_sides(comp: Component, lay: Layout) -> set[int]:
    """Seiten einer Förderzelle ohne Wand (Ausgang, Zuführungen, Übergaben)."""
    d = comp.direction
    sides = set(comp.flow_outputs())
    for s in range(4):
        n = lay.static.get(neighbor(comp.cell, s))
        if n is None:
            continue
        if n.type in FLOW_TYPES and opposite(s) in n.flow_outputs():
            sides.add(s)
        elif n.type in (EPB_RAIL, RBG_RAIL) and s == opposite(d):
            sides.add(s)
        elif n.type == RBG_RAIL and comp.type in (CONVEYOR, CONVEYOR_SWITCH):
            sides.add(s)                     # seitliche RBG-Abgabe
        elif n.type == LIFT and n.direction == opposite(s):
            sides.add(s)
    if comp.type == LIFT:
        back = lay.static.get(neighbor(comp.cell, opposite(d)))
        if back is not None and back.type == LIFT:
            sides.add(opposite(d))
    return sides


_open_sides = open_sides


def _rollers(surf, cam: Camera, comp: Component, lo, hi, phase: float = 0.0) -> None:
    """Rollen quer zur Förderrichtung. phase 0..1 verschiebt um eine Teilung (Drehung)."""
    z = cam.zoom
    if z < 14:
        return
    cx, cy = center(comp.cell)
    dx, dy = DVEC[comp.direction]
    px, py = -dy, dx
    pitch = 1.0 / ROLLERS_PER_M
    w_lo = max(2, round(z * 0.12))
    w_hi = max(1, round(z * 0.05))
    half = 0.4
    for i in range(-1, ROLLERS_PER_M):
        k = -0.5 + (i + 0.5 + phase) * pitch
        if k < -0.56 or k > 0.56:
            continue
        a = (cx + dx * k - px * half, cy + dy * k - py * half)
        b = (cx + dx * k + px * half, cy + dy * k + py * half)
        sa, sb = cam.w2s(*a), cam.w2s(*b)
        pygame.draw.line(surf, lo, sa, sb, w_lo)
        pygame.draw.line(surf, hi, sa, sb, w_hi)


def draw_component(surf, cam: Camera, comp: Component, lay: Layout | None, ghost: bool = False,
                   show_prefill: bool = True, show_text: bool = True, phase: float = 0.0,
                   opens: set[int] | None = None) -> None:
    z = cam.zoom
    rect = cam.cell_rect(comp.x, comp.y)
    cx, cy = center(comp.cell)
    t = comp.type

    def col(c):
        return _mix(c, T.CANVAS_BG, 0.72) if ghost else c

    if t in (CONVEYOR, CONVEYOR_SWITCH, LIFT, SOURCE):
        base = {CONVEYOR: T.CONVEYOR, CONVEYOR_SWITCH: T.CONVEYOR_SWITCH, LIFT: T.LIFT, SOURCE: T.SOURCE}[t]
        inner = rect.inflate(-max(2, int(z * 0.08)), -max(2, int(z * 0.08)))
        pygame.draw.rect(surf, col(base), inner, border_radius=max(0, int(z * 0.06)) if t == SOURCE else 0)
        ang = dir_angle(comp.direction)
        if t == CONVEYOR:
            _rollers(surf, cam, comp, col(T.ROLLER_DARK), col(T.ROLLER), phase)
        elif t == LIFT:
            _rollers(surf, cam, comp, col(T.LIFT_STRIPE), col(_mix(T.LIFT, (255, 255, 255), 0.5)), phase)
        elif t == SOURCE:
            _rollers(surf, cam, comp, col(_mix(T.SOURCE_DARK, T.SOURCE, 0.45)), col(_mix(T.SOURCE, (255, 255, 255), 0.45)))
        if not ghost and (lay is not None or opens is not None) and t != SOURCE:
            op = open_sides(comp, lay) if opens is None else opens
            for s in range(4):
                if s in op:
                    continue
                a = corner(comp.cell, s, (s + 1) % 4)
                b = corner(comp.cell, s, (s + 3) % 4)
                pygame.draw.line(surf, T.CONVEYOR_WALL, cam.w2s(*a), cam.w2s(*b), max(2, int(z * 0.09)))
        if t == CONVEYOR_SWITCH:
            dx, dy = DVEC[comp.direction]
            chevron(surf, cam, cx + dx * 0.16, cy + dy * 0.16, ang, 0.42, col(T.ARROW), z * 0.07)
            for side in comp.branch_sides():
                bx, by = DVEC[side]
                chevron(surf, cam, cx + bx * 0.2, cy + by * 0.2, dir_angle(side), 0.36, col(T.ACCENT), z * 0.07)
            pygame.draw.circle(surf, col(T.ARROW), cam.w2s(cx - dx * 0.2, cy - dy * 0.2), max(2, int(z * 0.06)))
        elif t == SOURCE:
            chevron(surf, cam, cx, cy, ang, 0.55, col(T.SOURCE_DARK), z * 0.08)
        else:
            chevron(surf, cam, cx, cy, ang, 0.5, col(T.ARROW), z * 0.07)
        if t == SOURCE and z >= 18 and show_text:
            s = T.text_surface("Q", max(9, int(z * 0.3)), col((255, 255, 255)), True)
            surf.blit(s, s.get_rect(center=cam.w2s(cx - DVEC[comp.direction][0] * 0.28,
                                                    cy - DVEC[comp.direction][1] * 0.28)))
        if t == LIFT and z >= 26 and show_text:
            s = T.text_surface(f"E{comp.level}→E{comp.target_level}", max(9, int(z * 0.24)), col((30, 60, 110)), True)
            surf.blit(s, s.get_rect(midbottom=(rect.centerx, rect.bottom - 1)))
    elif t == EPB_RAIL:
        pygame.draw.rect(surf, col(T.RAIL_BG), rect.inflate(-1, -1))
        d = comp.direction
        dx, dy = DVEC[d]
        px, py = -dy, dx
        if z >= 20 and not ghost:
            # Schwellen
            for k in (-0.375, -0.125, 0.125, 0.375):
                a = (cx + dx * k - px * 0.34, cy + dy * k - py * 0.34)
                b = (cx + dx * k + px * 0.34, cy + dy * k + py * 0.34)
                pygame.draw.line(surf, T.RAIL_TIE, cam.w2s(*a), cam.w2s(*b), max(2, int(z * 0.08)))
        for off in (-0.22, 0.22):
            a = (cx - dx * 0.5 + px * off, cy - dy * 0.5 + py * off)
            b = (cx + dx * 0.5 + px * off, cy + dy * 0.5 + py * off)
            pygame.draw.line(surf, col(T.RAIL), cam.w2s(*a), cam.w2s(*b), max(2, int(z * 0.09)))
        if not ghost:
            ang = dir_angle(d)
            arrow(surf, cam, cx + dx * 0.2, cy + dy * 0.2, ang, 0.3, T.RAIL_ARROW_ON)
            arrow(surf, cam, cx - dx * 0.25, cy - dy * 0.25, ang + math.pi, 0.16, T.RAIL_ARROW_OFF)
    elif t == EPB_CURVE:
        pygame.draw.rect(surf, col(T.RAIL_BG), rect.inflate(-1, -1))
        entry, ex = comp.curve_sides()
        a0, da, c = _curve_rails(surf, cam, comp.cell, entry, ex, col(T.RAIL), z, ties=not ghost)
        if not ghost:
            amid = a0 + da * 0.5
            mx, my = c[0] + 0.5 * math.cos(amid), c[1] + 0.5 * math.sin(amid)
            heading = amid + (math.pi / 2 if da > 0 else -math.pi / 2)
            arrow(surf, cam, mx, my, heading, 0.3, T.RAIL_ARROW_ON)
            a2 = a0 + da * 0.2
            back = a2 + (math.pi / 2 if da > 0 else -math.pi / 2) + math.pi
            arrow(surf, cam, c[0] + 0.5 * math.cos(a2), c[1] + 0.5 * math.sin(a2), back, 0.15, T.RAIL_ARROW_OFF)
    elif t == EPB_SWITCH:
        pygame.draw.rect(surf, col(T.SWITCH_BG), rect.inflate(-1, -1))
        d = comp.direction
        dx, dy = DVEC[d]
        px, py = -dy, dx
        for off in (-0.22, 0.22):
            a = (cx - dx * 0.5 + px * off, cy - dy * 0.5 + py * off)
            b = (cx + dx * 0.5 + px * off, cy + dy * 0.5 + py * off)
            pygame.draw.line(surf, col(T.RAIL), cam.w2s(*a), cam.w2s(*b), max(2, int(z * 0.09)))
        en, ex = comp.switch_links()[1]
        a0, da, c = _curve_rails(surf, cam, comp.cell, en, ex, col(T.SWITCH_RAIL), z)
        if not ghost:
            ang = dir_angle(d)
            arrow(surf, cam, cx + dx * 0.28, cy + dy * 0.28, ang, 0.24, T.RAIL_ARROW_ON)
            amid = a0 + da * 0.5
            heading = amid + (math.pi / 2 if da > 0 else -math.pi / 2)
            arrow(surf, cam, c[0] + 0.5 * math.cos(amid), c[1] + 0.5 * math.sin(amid), heading, 0.24,
                  T.RAIL_ARROW_ON)
            if z >= 30 and show_text:
                s = T.text_surface("Z" if comp.switch_merge else "V", max(9, int(z * 0.2)), T.SWITCH_RAIL, True)
                surf.blit(s, s.get_rect(center=cam.w2s(cx - dx * 0.28 - px * 0.3, cy - dy * 0.28 - py * 0.3)))
    elif t == RBG_RAIL:
        pygame.draw.rect(surf, col(T.RBG_RAIL_BG), rect.inflate(-1, -1))
        if comp.rbg_axis == 0:
            a, b = (cx, cy - 0.5), (cx, cy + 0.5)
            offs = ((0.3, 0.0), (-0.3, 0.0))
        else:
            a, b = (cx - 0.5, cy), (cx + 0.5, cy)
            offs = ((0.0, 0.3), (0.0, -0.3))
        if z >= 20 and not ghost:
            # Führungsschienen oben (dünn) beidseitig
            for ox, oy in offs:
                pygame.draw.line(surf, _mix(T.RBG_RAIL, T.RBG_RAIL_BG, 0.6), cam.w2s(a[0] + ox, a[1] + oy),
                                 cam.w2s(b[0] + ox, b[1] + oy), 1)
        pygame.draw.line(surf, col(T.RBG_RAIL), cam.w2s(*a), cam.w2s(*b), max(2, int(z * 0.1)))
    elif t == STORAGE:
        inner = rect.inflate(-max(2, int(z * 0.1)), -max(2, int(z * 0.1)))
        pygame.draw.rect(surf, col(T.STORAGE_FREE), inner)
        pygame.draw.rect(surf, col(T.STORAGE_FRAME), inner, max(1, int(z * 0.06)))
        if z >= 20:
            # Regalstützen in den Ecken
            p = max(2, int(z * 0.1))
            for qx, qy in (inner.topleft, (inner.right - p, inner.y), (inner.x, inner.bottom - p),
                           (inner.right - p, inner.bottom - p)):
                pygame.draw.rect(surf, col(T.STORAGE_POST), (qx, qy, p, p))
        if show_prefill and comp.prefilled:
            draw_container(surf, cam, cx, cy, prefilled=True, ghost=ghost)
    elif t in EXIT_TYPES:
        base, dark = (T.SINK, T.SINK_DARK) if t == SINK else (T.NIO, T.NIO_DARK)
        inner = rect.inflate(-max(2, int(z * 0.1)), -max(2, int(z * 0.1)))
        pygame.draw.rect(surf, col(base), inner, border_radius=max(0, int(z * 0.12)))
        pygame.draw.rect(surf, col(dark), inner, max(1, int(z * 0.06)), border_radius=max(0, int(z * 0.12)))
        w = max(2, int(z * 0.08))
        if t == NIO:
            k = 0.22
            pygame.draw.line(surf, col(dark), cam.w2s(cx - k, cy - k), cam.w2s(cx + k, cy + k), w)
            pygame.draw.line(surf, col(dark), cam.w2s(cx + k, cy - k), cam.w2s(cx - k, cy + k), w)
        else:
            # Symbol "Ausgang": Rahmen mit Pfeil nach außen
            a, b = cam.w2s(cx - 0.3, cy - 0.22), cam.w2s(cx - 0.02, cy + 0.22)
            frame = pygame.Rect(round(a[0]), round(a[1]), max(2, round(b[0] - a[0])), max(2, round(b[1] - a[1])))
            pygame.draw.rect(surf, col(dark), frame, max(1, int(z * 0.05)))
            arrow(surf, cam, cx + 0.12, cy, 0.0, 0.34, col(dark))
    elif t == EPB:
        draw_epb(surf, cam, cx, cy, _vehicle_heading(comp, lay), ghost=ghost)
    elif t == RBG:
        axis = 1
        if lay is not None:
            base = lay.static.get(comp.cell)
            if base is not None and base.type == RBG_RAIL:
                axis = base.rbg_axis
        draw_rbg(surf, cam, cx, cy, axis, 0.0, 0, ghost=ghost)


_WALLED = (CONVEYOR, CONVEYOR_SWITCH, LIFT)


def draw_component_cached(surf, cam: Camera, comp: Component, lay: Layout | None, ghost: bool = False,
                          show_prefill: bool = True, show_text: bool = True) -> None:
    """Statische Komponente als vorberechnetes Zellbild blitten (gleiches Aussehen wie draw_component)."""
    z = cam.zoom
    r = cam.cell_rect(comp.x, comp.y)
    t = comp.type
    opens = frozenset(open_sides(comp, lay)) if (t in _WALLED and lay is not None and not ghost) else None
    pad = max(1, math.ceil(z * 0.06))
    key = ("comp", r.w, r.h, t, comp.rot, repr(sorted(comp.props.items())), opens, ghost,
           show_prefill and t == STORAGE, show_text, comp.level if t == LIFT else 0)

    def make():
        s = pygame.Surface((r.w + 2 * pad, r.h + 2 * pad), pygame.SRCALPHA)
        lc = Camera(pygame.Rect(0, 0, s.get_width(), s.get_height()), zoom=z)
        lc.ox, lc.oy = comp.x - pad / z, comp.y - pad / z
        draw_component(s, lc, comp, None, ghost=ghost, show_prefill=show_prefill, show_text=show_text,
                       opens=opens)
        return _alpha(s)
    surf.blit(_cached(z, key, make), (r.x - pad, r.y - pad))


def conveyor_tile(cam: Camera, comp: Component, opens: frozenset, phase_idx: int) -> pygame.Surface:
    """Förderzelle mit gedrehten Rollen als fertiges Bild (für laufende Zellen in der Simulation)."""
    r = cam.cell_rect(comp.x, comp.y)

    def make():
        s = pygame.Surface(r.size, pygame.SRCALPHA)
        lc = Camera(pygame.Rect(0, 0, r.w, r.h), zoom=cam.zoom)
        lc.ox, lc.oy = comp.x, comp.y
        draw_component(s, lc, comp, None, phase=phase_idx / ROLLER_PHASES, opens=opens)
        return _alpha(s)
    return _cached(cam.zoom, ("conv", r.w, r.h, comp.type, comp.direction, opens, phase_idx), make)


def _curve_rails(surf, cam: Camera, cell, entry: int, ex: int, color, z: float, ties: bool = False):
    """Zeichnet die zwei Schienen eines 90°-Bogens; liefert (Startwinkel, Winkelspanne, Bogenmitte)."""
    c = corner(cell, entry, ex)
    a0 = math.atan2(edge_mid(cell, entry)[1] - c[1], edge_mid(cell, entry)[0] - c[0])
    a1 = math.atan2(edge_mid(cell, ex)[1] - c[1], edge_mid(cell, ex)[0] - c[0])
    da = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi
    if ties and z >= 20:
        for f in (0.15, 0.38, 0.62, 0.85):
            a = a0 + da * f
            ca, sa = math.cos(a), math.sin(a)
            pygame.draw.line(surf, T.RAIL_TIE, cam.w2s(c[0] + 0.16 * ca, c[1] + 0.16 * sa),
                             cam.w2s(c[0] + 0.84 * ca, c[1] + 0.84 * sa), max(2, int(z * 0.08)))
    for rad in (0.28, 0.72):
        pts = []
        for i in range(13):
            a = a0 + da * i / 12
            pts.append(cam.w2s(c[0] + rad * math.cos(a), c[1] + rad * math.sin(a)))
        pygame.draw.lines(surf, color, False, pts, max(2, int(z * 0.09)))
    return a0, da, c


def _vehicle_heading(comp: Component, lay: Layout | None) -> float:
    if lay is None:
        return 0.0
    base = lay.static.get(comp.cell)
    if base is None or base.type not in EPB_RAIL_TYPES:
        return 0.0
    if base.type in (EPB_RAIL, EPB_SWITCH):
        return dir_angle(base.direction)
    from matflow.sim.tracks import CURVE_LEN, RailCell
    entry, ex = base.curve_sides()
    return RailCell(base, entry, ex, CURVE_LEN).local_pos(CURVE_LEN / 2)[2]


# ---------------------------------------------------------------------- Behälter
_KIND_COLORS = {
    "NIO": (T.CONTAINER_NIO, T.CONTAINER_NIO_BORDER),
    "OUT": (T.CONTAINER_OUT, T.CONTAINER_OUT_BORDER),
}


def _container_sprite(z: float, size: int, kind: str, ghost: bool, shadow: bool) -> tuple[pygame.Surface, int]:
    def make():
        fill, border = _KIND_COLORS.get(kind, (T.CONTAINER, T.CONTAINER_BORDER))
        if ghost:
            fill, border = _mix(fill, T.CANVAS_BG, 0.65), _mix(border, T.CANVAS_BG, 0.65)
        pad = max(2, round(z * 0.1)) if shadow else 0
        s = pygame.Surface((size + 2 * pad, size + 2 * pad), pygame.SRCALPHA)
        if shadow:
            sh, sp = shadow_sprite(size, size, max(1, round(z * 0.04)), 80)
            off = max(1, round(z * 0.04))
            s.blit(sh, (pad - sp + off, pad - sp + off))
        rect = pygame.Rect(pad, pad, size, size)
        rad = max(0, int(size * 0.14))
        pygame.draw.rect(s, fill, rect, border_radius=rad)
        if z >= 16 and not ghost:
            # Innenraum des Kleinladungsträgers (etwas dunkler) + Lichtkante
            rim = max(1, round(size * 0.14))
            pygame.draw.rect(s, _mix(fill, border, 0.22), rect.inflate(-2 * rim, -2 * rim),
                             border_radius=max(0, rad - rim // 2))
            pygame.draw.line(s, _mix(fill, (255, 255, 255), 0.35), (rect.x + rad, rect.y + 1),
                             (rect.right - rad - 1, rect.y + 1), 1)
        pygame.draw.rect(s, border, rect, max(1, int(z * 0.04)), border_radius=rad)
        if z >= 30 and not ghost:
            # Griffmulden an den Stirnseiten
            gw = max(2, round(size * 0.3))
            gh = max(1, round(size * 0.06))
            pygame.draw.rect(s, border, (rect.centerx - gw // 2, rect.y + max(2, round(size * 0.05)), gw, gh))
            pygame.draw.rect(s, border, (rect.centerx - gw // 2, rect.bottom - max(2, round(size * 0.05)) - gh, gw, gh))
            if kind == "NIO":
                pygame.draw.line(s, border, rect.topleft, (rect.right - 1, rect.bottom - 1), 2)
        return (s.convert_alpha() if pygame.display.get_surface() else s), pad
    return _cached(z, ("box", size, kind, ghost, shadow), make)


def draw_container(surf, cam: Camera, x: float, y: float, prefilled: bool = False, ghost: bool = False,
                   scale: float = 1.0, highlight: bool = False, kind: str = "IO", shadow: bool = True) -> None:
    # vorbelegte Behälter sehen aus wie alle anderen (prefilled bleibt nur als Information erhalten)
    z = cam.zoom
    scale = round(scale * 20) / 20            # Stufen für den Sprite-Cache (Heber)
    size = max(3, round(z * 0.5 * scale))
    sx, sy = cam.w2s(x, y)
    rx, ry = round(sx) - size // 2, round(sy) - size // 2
    spr, pad = _container_sprite(z, size, kind, ghost, shadow and not ghost and z >= 10)
    surf.blit(spr, (rx - pad, ry - pad))
    if highlight:
        pygame.draw.rect(surf, T.SELECT, (rx - 3, ry - 3, size + 6, size + 6), 2, border_radius=3)


# ---------------------------------------------------------------------- Fahrzeuge
def _vehicle_shadow(surf, cam: Camera, x: float, y: float, w: float, h: float) -> None:
    z = cam.zoom
    if z < 10:
        return
    pw, ph = max(3, round(z * w)), max(3, round(z * h))
    sh, pad = shadow_sprite(pw, ph, max(2, round(z * 0.07)), 75)
    sx, sy = cam.w2s(x, y)
    off = max(1, round(z * 0.06))
    surf.blit(sh, (round(sx) - pw // 2 - pad + off, round(sy) - ph // 2 - pad + off))


def draw_led(surf, cam: Camera, x: float, y: float, color) -> None:
    z = cam.zoom
    r = max(2, round(z * 0.065))
    sx, sy = (round(v) for v in cam.w2s(x, y))
    if z >= 20:
        g = glow_sprite(r, color)
        surf.blit(g, (sx - g.get_width() // 2, sy - g.get_height() // 2))
    pygame.draw.circle(surf, (30, 30, 30), (sx, sy), r + 1)
    pygame.draw.circle(surf, color, (sx, sy), r)
    if r >= 3:
        pygame.draw.circle(surf, _mix(color, (255, 255, 255), 0.6), (sx - r // 3, sy - r // 3), max(1, r // 3))


def draw_epb(surf, cam: Camera, x: float, y: float, heading: float, ghost: bool = False,
             highlight: bool = False, led=None) -> None:
    fill = _mix(T.EPB, T.CANVAS_BG, 0.65) if ghost else T.EPB
    border = _mix(T.EPB_BORDER, T.CANVAS_BG, 0.65) if ghost else T.EPB_BORDER
    if not ghost:
        _vehicle_shadow(surf, cam, x, y, 0.8, 0.8)
    pts = rot_rect_pts(cam, x, y, 0.8, 0.8, heading)
    pygame.draw.polygon(surf, fill, pts)
    if cam.zoom >= 16 and not ghost:
        # Ladedeck (Aufnahmefläche) und Stoßfänger vorne
        pygame.draw.polygon(surf, T.EPB_DECK, rot_rect_pts(cam, x, y, 0.6, 0.62, heading))
        bx, by = _local(heading, x, y, 0.35, 0.0)
        pygame.draw.polygon(surf, border, rot_rect_pts(cam, bx, by, 0.06, 0.74, heading))
    pygame.draw.polygon(surf, border, pts, max(1, int(cam.zoom * 0.05)))
    if cam.zoom < 16 or ghost:
        # Fahrtrichtungsmarke vorne
        a = cam.w2s(*_local(heading, x, y, 0.28, 0.22))
        b = cam.w2s(*_local(heading, x, y, 0.28, -0.22))
        pygame.draw.line(surf, border, a, b, max(1, int(cam.zoom * 0.06)))
    if led is not None and not ghost:
        draw_led(surf, cam, *_local(heading, x, y, -0.355, 0.0), led)
    if highlight:
        pygame.draw.polygon(surf, T.SELECT, rot_rect_pts(cam, x, y, 0.98, 0.98, heading), 2)


def draw_rbg(surf, cam: Camera, x: float, y: float, axis: int, arm: float, arm_side: int,
             ghost: bool = False, highlight: bool = False, led=None, height: float | None = None) -> None:
    """RBG von oben: Fahrwerk entlang der Schiene, Mast an einem Ende, Hubwagen mit Gabel in der Mitte.

    height: relative Hubwagenhöhe 0..1 (Anzeige am Mast), None = keine Anzeige.
    """
    z = cam.zoom
    fill = _mix(T.RBG, T.CANVAS_BG, 0.65) if ghost else T.RBG
    border = _mix(T.RBG_BORDER, T.CANVAS_BG, 0.65) if ghost else T.RBG_BORDER

    def rect_world(cx, cy, la, lc):
        """Achsparalleles Rechteck: la entlang der Schiene, lc quer dazu → Bildschirm-Rect."""
        w, h = (lc, la) if axis == 0 else (la, lc)
        p0 = cam.w2s(cx - w / 2, cy - h / 2)
        p1 = cam.w2s(cx + w / 2, cy + h / 2)
        return pygame.Rect(round(p0[0]), round(p0[1]), max(2, round(p1[0] - p0[0])), max(2, round(p1[1] - p0[1])))

    if not ghost:
        w, h = (0.72, 0.96) if axis == 0 else (0.96, 0.72)
        _vehicle_shadow(surf, cam, x, y, w, h)
    # Gabel (Teleskop) seitlich ausgefahren
    if arm > 0.01:
        dx, dy = DVEC[arm_side]
        for off in (-0.13, 0.13):
            # Zinken parallel zur Ausfahrrichtung, seitlich versetzt entlang der Schiene
            if axis == 0:
                zx, zy = x + dx * arm / 2, y + off
                p0, p1 = cam.w2s(zx - arm / 2, zy - 0.035), cam.w2s(zx + arm / 2, zy + 0.035)
            else:
                zx, zy = x + off, y + dy * arm / 2
                p0, p1 = cam.w2s(zx - 0.035, zy - arm / 2), cam.w2s(zx + 0.035, zy + arm / 2)
            r = pygame.Rect(round(p0[0]), round(p0[1]), max(2, round(p1[0] - p0[0])), max(2, round(p1[1] - p0[1])))
            pygame.draw.rect(surf, T.RBG_ARM, r)
    body = rect_world(x, y, 0.96, 0.72)
    rad = max(0, int(z * 0.08))
    pygame.draw.rect(surf, fill, body, border_radius=rad)
    if z >= 16:
        # Fahrwerksträger an beiden Enden
        for e in (-0.41, 0.41):
            ex, ey = (x, y + e) if axis == 0 else (x + e, y)
            pygame.draw.rect(surf, _mix(fill, border, 0.45), rect_world(ex, ey, 0.12, 0.72))
    pygame.draw.rect(surf, border, body, max(1, int(z * 0.05)), border_radius=rad)
    # Hubwagen (Plattform) in der Mitte
    carriage = rect_world(x, y, 0.56, 0.56)
    pygame.draw.rect(surf, _mix(T.RBG_CARRIAGE, T.CANVAS_BG, 0.6) if ghost else T.RBG_CARRIAGE, carriage,
                     border_radius=max(0, int(z * 0.04)))
    pygame.draw.rect(surf, border, carriage, max(1, int(z * 0.03)), border_radius=max(0, int(z * 0.04)))
    if arm <= 0.01 and z >= 16:
        # eingezogene Gabelzinken quer zur Fahrachse
        for off in (-0.13, 0.13):
            if axis == 0:
                a, b = cam.w2s(x - 0.22, y + off), cam.w2s(x + 0.22, y + off)
            else:
                a, b = cam.w2s(x + off, y - 0.22), cam.w2s(x + off, y + 0.22)
            pygame.draw.line(surf, T.RBG_ARM if not ghost else _mix(T.RBG_ARM, T.CANVAS_BG, 0.6), a, b,
                             max(1, int(z * 0.05)))
    # Mast am vorderen Ende
    mx, my = (x, y - 0.36) if axis == 0 else (x - 0.36, y)
    mast = rect_world(mx, my, 0.14, 0.5)
    pygame.draw.rect(surf, T.RBG_MAST, mast, border_radius=max(0, int(z * 0.02)))
    if height is not None and z >= 24:
        # Höhenanzeige des Hubwagens am Mast
        h = max(0.0, min(1.0, height))
        if axis == 0:
            px = mast.x + 1 + round((mast.w - 3) * h)
            pygame.draw.line(surf, (255, 255, 255), (px, mast.y + 1), (px, mast.bottom - 2), 2)
        else:
            py = mast.bottom - 2 - round((mast.h - 3) * h)
            pygame.draw.line(surf, (255, 255, 255), (mast.x + 1, py), (mast.right - 2, py), 2)
    if led is not None and not ghost:
        lx, ly = (x + 0.26, y + 0.36) if axis == 0 else (x + 0.36, y + 0.26)
        draw_led(surf, cam, lx, ly, led)
    if highlight:
        pygame.draw.rect(surf, T.SELECT, body.inflate(6, 6), 2, border_radius=4)


def draw_rbg_mast(surf, cam: Camera, x: float, y: float, axis: int, carriage_level: int, view_level: int) -> None:
    """RBG auf einer Ebene, auf der sich der Hubwagen gerade NICHT befindet: nur Mast kräftig."""
    draw_rbg(surf, cam, x, y, axis, 0.0, 0, ghost=True)
    mx, my = (x, y - 0.36) if axis == 0 else (x - 0.36, y)
    w, h = (0.5, 0.14) if axis == 0 else (0.14, 0.5)
    p0, p1 = cam.w2s(mx - w / 2, my - h / 2), cam.w2s(mx + w / 2, my + h / 2)
    pygame.draw.rect(surf, T.RBG_MAST, (round(p0[0]), round(p0[1]), max(2, round(p1[0] - p0[0])),
                                        max(2, round(p1[1] - p0[1]))))
    if cam.zoom >= 18:
        up = carriage_level > view_level
        txt = f"{'▲' if up else '▼'}E{carriage_level}"
        t = T.text_surface(txt, max(9, int(cam.zoom * 0.24)), (255, 255, 255), True)
        sx, sy = cam.w2s(x, y)
        box = t.get_rect(center=(round(sx), round(sy))).inflate(8, 2)
        pygame.draw.rect(surf, T.RBG_BORDER, box, border_radius=4)
        surf.blit(t, t.get_rect(center=box.center))


def draw_lift_shadow(surf, cam: Camera, comp: Component) -> None:
    rect = cam.cell_rect(comp.x, comp.y).inflate(-4, -4)
    pygame.draw.rect(surf, _mix(T.LIFT, T.CANVAS_BG, 0.55), rect)
    pygame.draw.rect(surf, T.LIFT_STRIPE, rect, 1)
    if cam.zoom >= 26:
        s = T.text_surface(f"Heber E{comp.level}", max(9, int(cam.zoom * 0.22)), (60, 90, 140))
        surf.blit(s, s.get_rect(center=rect.center))


# ---------------------------------------------------------------------- Effekte
def _flash_frames(z: float) -> list[pygame.Surface]:
    def make():
        frames = []
        r_max = z * 0.62
        size = int(2 * r_max + 8)
        c = size // 2
        for k in range(FLASH_FRAMES):
            t = k / (FLASH_FRAMES - 1)
            s = pygame.Surface((size, size), pygame.SRCALPHA)
            rad = z * 0.22 + (r_max - z * 0.22) * t
            a = int(210 * (1 - t) ** 1.3)
            if t < 0.45:
                pygame.draw.circle(s, (*T.FLASH, int(90 * (1 - t / 0.45))), (c, c), int(z * 0.3))
            pygame.draw.circle(s, (*T.FLASH, a), (c, c), int(rad), max(2, int(z * 0.06)))
            frames.append(s.convert_alpha() if pygame.display.get_surface() else s)
        return frames
    return _cached(z, ("flash",), make)


def draw_flash(surf, cam: Camera, x: float, y: float, age: float) -> None:
    """Kurzes Aufleuchten an einem Übergabepunkt, age in s (Echtzeit)."""
    frames = _flash_frames(cam.zoom)
    k = min(FLASH_FRAMES - 1, int(age / FLASH_T * FLASH_FRAMES))
    s = frames[k]
    sx, sy = cam.w2s(x, y)
    surf.blit(s, (round(sx) - s.get_width() // 2, round(sy) - s.get_height() // 2))


# ---------------------------------------------------------------------- Paletten-Symbole
def icon(ctype: str, size: int = 34, rot: int = 1) -> pygame.Surface:
    """Paletten-Symbol, mit derselben Zeichenroutine wie im Editor."""
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    cam = Camera(pygame.Rect(0, 0, size, size), zoom=size / 1.0)
    cam.ox, cam.oy = 0.0, 0.0
    if ctype == EPB:
        pygame.draw.rect(surf, T.RAIL_BG, (0, 0, size, size), border_radius=4)
        draw_epb(surf, cam, 0.5, 0.5, 0.0)
        return surf
    if ctype == RBG:
        draw_rbg(surf, cam, 0.5, 0.5, 1, 0.0, 0)
        return surf
    if ctype == "container":
        pygame.draw.rect(surf, T.STORAGE_FREE, (2, 2, size - 4, size - 4))
        pygame.draw.rect(surf, T.STORAGE_FRAME, (2, 2, size - 4, size - 4), 2)
        draw_container(surf, cam, 0.5, 0.5, prefilled=True, shadow=False)
        return surf
    if ctype in ("box", "box_nio", "box_out"):
        draw_container(surf, cam, 0.5, 0.5, kind={"box": "IO", "box_nio": "NIO", "box_out": "OUT"}[ctype],
                       scale=0.9, shadow=False)
        return surf
    props = {"target_level": 1} if ctype == LIFT else {}
    comp = Component("ICON", ctype, 0, 0, 0, rot if ctype != EPB_CURVE else 3, "", props)
    draw_component(surf, cam, comp, None, show_text=False)
    if ctype in (CONVEYOR, CONVEYOR_SWITCH, LIFT):
        open_ = set(comp.flow_outputs()) | {opposite(comp.direction)}
        for s in range(4):
            if s in open_:
                continue
            a = corner(comp.cell, s, (s + 1) % 4)
            b = corner(comp.cell, s, (s + 3) % 4)
            pygame.draw.line(surf, T.CONVEYOR_WALL, cam.w2s(*a), cam.w2s(*b), 2)
    return surf
