"""Kamera: Umrechnung Welt (m) ↔ Bildschirm (px), Zoom und Verschieben."""
from __future__ import annotations

import math

import pygame


class Camera:
    MIN_Z, MAX_Z = 8.0, 160.0

    def __init__(self, rect: pygame.Rect, zoom: float = 36.0):
        self.rect = rect
        self.zoom = zoom
        self.ox = 1.0     # Weltkoordinate am linken Rand
        self.oy = 1.0

    def w2s(self, x: float, y: float) -> tuple[float, float]:
        return (self.rect.x + (x - self.ox) * self.zoom, self.rect.y + (y - self.oy) * self.zoom)

    def s2w(self, sx: float, sy: float) -> tuple[float, float]:
        return ((sx - self.rect.x) / self.zoom + self.ox, (sy - self.rect.y) / self.zoom + self.oy)

    def cell_at(self, sx: float, sy: float) -> tuple[int, int]:
        x, y = self.s2w(sx, sy)
        return math.floor(x), math.floor(y)

    def cell_rect(self, x: int, y: int) -> pygame.Rect:
        sx, sy = self.w2s(x, y)
        x2, y2 = self.w2s(x + 1, y + 1)
        return pygame.Rect(round(sx), round(sy), round(x2) - round(sx), round(y2) - round(sy))

    def zoom_at(self, sx: float, sy: float, factor: float) -> None:
        wx, wy = self.s2w(sx, sy)
        self.zoom = max(self.MIN_Z, min(self.MAX_Z, self.zoom * factor))
        self.ox = wx - (sx - self.rect.x) / self.zoom
        self.oy = wy - (sy - self.rect.y) / self.zoom

    def pan(self, dx: float, dy: float) -> None:
        self.ox -= dx / self.zoom
        self.oy -= dy / self.zoom

    def fit(self, x0: float, y0: float, x1: float, y1: float, margin: float = 1.5) -> None:
        w = max(1.0, x1 - x0 + 2 * margin)
        h = max(1.0, y1 - y0 + 2 * margin)
        self.zoom = max(self.MIN_Z, min(self.MAX_Z, min(self.rect.w / w, self.rect.h / h)))
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        self.ox = cx - self.rect.w / (2 * self.zoom)
        self.oy = cy - self.rect.h / (2 * self.zoom)

    def center_on(self, x: float, y: float) -> None:
        self.ox = x - self.rect.w / (2 * self.zoom)
        self.oy = y - self.rect.h / (2 * self.zoom)

    def visible_cells(self) -> tuple[int, int, int, int]:
        x0, y0 = self.s2w(self.rect.x, self.rect.y)
        x1, y1 = self.s2w(self.rect.right, self.rect.bottom)
        return math.floor(x0), math.floor(y0), math.ceil(x1), math.ceil(y1)
