"""Komponententypen und das statische Komponenten-Datenmodell."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from matflow.core.geometry import opposite, rotate_dir

CONVEYOR = "conveyor"
CONVEYOR_SWITCH = "conveyor_switch"
LIFT = "lift"
SOURCE = "source"
EPB_RAIL = "epb_rail"
EPB_CURVE = "epb_curve"
EPB_SWITCH = "epb_switch"
RBG_RAIL = "rbg_rail"
STORAGE = "storage"
EPB = "epb"
RBG = "rbg"
NIO = "nio"
SINK = "sink"

# Layer: "static" = Anlagengeometrie, "vehicle" = Fahrzeug auf einer Schiene
STATIC, VEHICLE = "static", "vehicle"


@dataclass(frozen=True)
class TypeSpec:
    key: str
    name: str
    id_prefix: str
    id_digits: int
    layer: str
    directional: bool          # hat eine Richtung / Orientierung
    paintable: bool            # per Ziehen mehrere Zellen zeichnen
    enabled: bool = True
    requires: str | None = None  # Fahrzeuge: benötigte Schienentypen (Kommaliste)
    hint: str = ""


TYPES: dict[str, TypeSpec] = {
    CONVEYOR: TypeSpec(CONVEYOR, "Fördertechnik", "FT", 3, STATIC, True, True,
                       hint="Gerichtete 1x1-Förderzelle"),
    CONVEYOR_SWITCH: TypeSpec(CONVEYOR_SWITCH, "FT-Weiche", "FT_WEICHE", 3, STATIC, True, False,
                              hint="Gabelung: gerader Ausgang + Abzweig (rechts, links oder beidseitig)"),
    LIFT: TypeSpec(LIFT, "Heber", "HEBER", 3, STATIC, True, True,
                   hint="Gerichtet, wechselt zur Zielebene"),
    SOURCE: TypeSpec(SOURCE, "Quelle", "QUELLE", 2, STATIC, True, False,
                     hint="Behälterursprung, Pfeil = Ausgang"),
    EPB_RAIL: TypeSpec(EPB_RAIL, "EPB-Schiene", "EPB_RAIL", 3, STATIC, True, True,
                       hint="Gerade Schiene, Fahrtrichtung A/B"),
    EPB_CURVE: TypeSpec(EPB_CURVE, "EPB-Kurve", "EPB_CURVE", 3, STATIC, True, False,
                        hint="90°-Bogen, Fahrtrichtung A/B"),
    EPB_SWITCH: TypeSpec(EPB_SWITCH, "EPB-Weiche", "WEICHE", 3, STATIC, True, False,
                         hint="Verzweigung oder Zusammenführung mit 90°-Abzweig"),
    RBG_RAIL: TypeSpec(RBG_RAIL, "RBG-Schiene", "RBG_RAIL", 3, STATIC, True, True,
                       hint="Einspurige RBG-Fahrbahn"),
    STORAGE: TypeSpec(STORAGE, "Lagerplatz", "LAGER", 3, STATIC, False, True,
                      hint="Seitlich an RBG-Schiene"),
    EPB: TypeSpec(EPB, "EPB", "EPB", 2, VEHICLE, False, False, requires=f"{EPB_RAIL},{EPB_CURVE},{EPB_SWITCH}",
                  hint="Fahrzeug auf EPB-Schiene"),
    RBG: TypeSpec(RBG, "RBG", "RBG", 2, VEHICLE, False, False, requires=RBG_RAIL,
                  hint="Regalbediengerät auf RBG-Schiene"),
    SINK: TypeSpec(SINK, "Ausgang", "AUSGANG", 2, STATIC, False, False,
                   hint="Behälter verlassen hier die Anlage (Auslagerung)"),
    NIO: TypeSpec(NIO, "NIO-Ausgang", "NIO", 2, STATIC, False, False,
                  hint="Fehlerhafte (NIO) Behälter verlassen hier die Anlage"),
}

FLOW_TYPES = (CONVEYOR, CONVEYOR_SWITCH, LIFT, SOURCE)
BRANCH_MODES = ("right", "left", "both")
BRANCH_NAMES = {"right": "rechts", "left": "links", "both": "beidseitig"}
EXIT_TYPES = (SINK, NIO)
EPB_RAIL_TYPES = (EPB_RAIL, EPB_CURVE, EPB_SWITCH)


@dataclass
class Component:
    id: str
    type: str
    x: int
    y: int
    level: int = 0
    rot: int = 0                     # Bedeutung je Typ, siehe Methoden unten
    label: str = ""
    props: dict[str, Any] = field(default_factory=dict)

    # ---- Grundlagen -------------------------------------------------------
    @property
    def cell(self) -> tuple[int, int, int]:
        return (self.x, self.y, self.level)

    @property
    def spec(self) -> TypeSpec:
        return TYPES[self.type]

    @property
    def display_name(self) -> str:
        return self.label or self.id

    def copy(self) -> "Component":
        return Component(self.id, self.type, self.x, self.y, self.level, self.rot, self.label,
                         dict(self.props))

    # ---- Orientierung -----------------------------------------------------
    @property
    def direction(self) -> int:
        """Transport-/Fahrtrichtung für Fördertechnik, Heber, Quelle, gerade Schiene."""
        return self.rot % 4

    def rotate(self, k: int = 1) -> None:
        self.rot = rotate_dir(self.rot, k)

    def flip(self) -> None:
        """Fahrtrichtung A/B umschalten bzw. Förderrichtung umkehren."""
        if self.type == EPB_CURVE:
            self.props["reverse"] = not self.props.get("reverse", False)
        elif self.type == EPB_SWITCH:
            # Umkehren der Fahrtrichtung: Verzweigung ↔ Zusammenführung, Abzweigseite bleibt absolut gleich
            self.rot = opposite(self.rot)
            self.props["merge"] = not self.props.get("merge", False)
            self.props["mirror"] = not self.props.get("mirror", False)
        elif self.type == RBG_RAIL:
            pass
        elif self.spec.directional:
            self.rot = opposite(self.rot)

    # Kurve: rot k verbindet die Seiten k und k+1
    def curve_sides(self) -> tuple[int, int]:
        """(Eintrittsseite, Austrittsseite) einer Kurve."""
        a, b = self.rot % 4, (self.rot + 1) % 4
        return (b, a) if self.props.get("reverse", False) else (a, b)

    # Weiche: rot = Richtung des geraden Strangs, Abzweig rechts (Uhrzeigersinn) oder gespiegelt links
    @property
    def switch_merge(self) -> bool:
        return bool(self.props.get("merge", False))

    @property
    def switch_branch_side(self) -> int:
        return rotate_dir(self.direction, 3 if self.props.get("mirror", False) else 1)

    def switch_links(self) -> list[tuple[int, int]]:
        """Fahrwege (Eintritt, Austritt) einer Weiche; Index 0 ist immer der gerade Strang."""
        d, b = self.direction, self.switch_branch_side
        if self.switch_merge:
            return [(opposite(d), d), (b, d)]
        return [(opposite(d), d), (opposite(d), b)]

    def rail_links(self) -> list[tuple[int, int]]:
        if self.type == EPB_SWITCH:
            return self.switch_links()
        return [self.rail_entry_exit()]

    def rail_entry_exit(self) -> tuple[int, int]:
        """(Eintrittsseite, Austrittsseite) für gerade Schiene oder Kurve."""
        if self.type == EPB_CURVE:
            return self.curve_sides()
        d = self.direction
        return (opposite(d), d)

    @property
    def rbg_axis(self) -> int:
        """0 = Nord-Süd-Linie, 1 = Ost-West-Linie."""
        return self.rot % 2

    # FT-Weiche: gerader Ausgang in Pfeilrichtung, Abzweig rechts, links oder beidseitig
    @property
    def branch_mode(self) -> str:
        m = self.props.get("branch", "right")
        return m if m in BRANCH_MODES else "right"

    def branch_sides(self) -> list[int]:
        d = self.direction
        m = self.branch_mode
        if m == "both":
            return [rotate_dir(d, 1), rotate_dir(d, 3)]
        return [rotate_dir(d, 3 if m == "left" else 1)]

    def flow_outputs(self) -> list[int]:
        """Ausgangsseiten einer Förderzelle; Index 0 ist die Pfeilrichtung."""
        if self.type == CONVEYOR_SWITCH:
            return [self.direction] + self.branch_sides()
        return [self.direction]

    # Heber
    @property
    def target_level(self) -> int:
        return int(self.props.get("target_level", self.level))

    # Lager
    @property
    def prefilled(self) -> bool:
        return bool(self.props.get("prefilled", False))

    # ---- Serialisierung ---------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "type": self.type, "x": self.x, "y": self.y, "level": self.level,
                "rot": self.rot, "label": self.label, "props": dict(self.props)}

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "Component":
        return Component(d["id"], d["type"], int(d["x"]), int(d["y"]), int(d.get("level", 0)),
                         int(d.get("rot", 0)) % 4, d.get("label", ""), dict(d.get("props", {})))


def curve_for_turn(move_in: int, move_out: int) -> tuple[int, bool] | None:
    """Kurvenparameter (rot, reverse) für eine Fahrt, die mit Richtung move_in eintritt
    und mit move_out austritt. None, wenn keine 90°-Kurve."""
    entry = opposite(move_in)
    exit_ = move_out
    if (entry + 1) % 4 == exit_:
        return entry, False
    if (exit_ + 1) % 4 == entry:
        return exit_, True
    return None
