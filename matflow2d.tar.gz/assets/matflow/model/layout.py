"""Layout: die vom Benutzer konstruierte Anlage (reines Datenmodell, keine Simulation)."""
from __future__ import annotations

import math
import re
from typing import Any, Iterable

from matflow.core.geometry import Cell
from matflow.model.components import (
    LIFT, STATIC, TYPES, VEHICLE, Component,
)
from matflow.model.params import SimParams

FORMAT_VERSION = 1


class LayoutError(Exception):
    pass


class Layout:
    def __init__(self, width: int = 48, height: int = 32, levels: int = 2, name: str = "Neue Anlage"):
        self.width = width
        self.height = height
        self.levels = levels
        self.name = name
        self.params = SimParams()
        self.static: dict[Cell, Component] = {}
        self.vehicles: dict[Cell, Component] = {}
        self.by_id: dict[str, Component] = {}
        self.counters: dict[str, int] = {}

    # ------------------------------------------------------------------ Abfragen
    def in_bounds(self, cell: Cell) -> bool:
        x, y, lv = cell
        return 0 <= x < self.width and 0 <= y < self.height and 0 <= lv < self.levels

    def at(self, cell: Cell, layer: str = STATIC) -> Component | None:
        return (self.static if layer == STATIC else self.vehicles).get(cell)

    def get(self, cid: str) -> Component | None:
        return self.by_id.get(cid)

    def components(self, ctype: str | None = None) -> list[Component]:
        comps = list(self.by_id.values())
        if ctype is not None:
            comps = [c for c in comps if c.type == ctype]
        return sorted(comps, key=lambda c: c.id)

    def count(self, ctype: str) -> int:
        return sum(1 for c in self.by_id.values() if c.type == ctype)

    def lift_shadow(self, cell: Cell, ignore: set[str] | None = None) -> Component | None:
        """Heber, der die Zelle auf seiner Zielebene belegt (Höhenraum des Hebers)."""
        x, y, lv = cell
        for l0 in range(self.levels):
            c = self.static.get((x, y, l0))
            if c and c.type == LIFT and (ignore is None or c.id not in ignore):
                lo, hi = sorted((c.level, c.target_level))
                if lo < lv <= hi or lo <= lv < hi:
                    if lv != c.level:
                        return c
        return None

    def can_place(self, ctype: str, cell: Cell, ignore: set[str] | None = None,
                  props: dict[str, Any] | None = None) -> tuple[bool, str]:
        spec = TYPES[ctype]
        ignore = ignore or set()
        if not spec.enabled:
            return False, f"{spec.name} ist in Version 1 noch nicht verfügbar"
        if not self.in_bounds(cell):
            return False, "Außerhalb des Rasters"
        if spec.layer == STATIC:
            occ = self.static.get(cell)
            if occ and occ.id not in ignore:
                return False, f"Zelle belegt durch {occ.id}"
            sh = self.lift_shadow(cell, ignore)
            if sh:
                return False, f"Höhenraum von Heber {sh.id}"
            if ctype == LIFT and props:
                tl = int(props.get("target_level", cell[2]))
                if not 0 <= tl < self.levels:
                    return False, "Zielebene existiert nicht"
                lo, hi = sorted((cell[2], tl))
                for lv in range(lo, hi + 1):
                    if lv == cell[2]:
                        continue
                    o = self.static.get((cell[0], cell[1], lv))
                    if o and o.id not in ignore:
                        return False, f"Höhenraum belegt durch {o.id}"
            return True, ""
        # Fahrzeug
        base = self.static.get(cell)
        allowed = (spec.requires or "").split(",")
        if base is None or base.type not in allowed:
            return False, f"{spec.name} nur auf passender Schiene platzierbar"
        occ = self.vehicles.get(cell)
        if occ and occ.id not in ignore:
            return False, f"Zelle belegt durch {occ.id}"
        return True, ""

    # ------------------------------------------------------------------ IDs
    def new_id(self, ctype: str) -> str:
        spec = TYPES[ctype]
        n = self.counters.get(ctype, 0) + 1
        while True:
            cid = f"{spec.id_prefix}_{n:0{spec.id_digits}d}"
            if cid not in self.by_id:
                break
            n += 1
        self.counters[ctype] = n
        return cid

    # ------------------------------------------------------------------ Ändern
    def add(self, ctype: str, cell: Cell, rot: int = 0, props: dict[str, Any] | None = None,
            label: str = "", cid: str | None = None) -> Component:
        props = dict(props or {})
        if ctype == LIFT and "target_level" not in props:
            props["target_level"] = self.default_lift_target(cell[2])
        ok, why = self.can_place(ctype, cell, props=props)
        if not ok:
            raise LayoutError(why)
        comp = Component(cid or self.new_id(ctype), ctype, cell[0], cell[1], cell[2], rot % 4, label, props)
        self._insert(comp)
        return comp

    def _insert(self, comp: Component) -> None:
        layer = self.static if comp.spec.layer == STATIC else self.vehicles
        layer[comp.cell] = comp
        self.by_id[comp.id] = comp
        m = re.match(r".*_(\d+)$", comp.id)
        if m:
            self.counters[comp.type] = max(self.counters.get(comp.type, 0), int(m.group(1)))

    def _detach(self, comp: Component) -> None:
        layer = self.static if comp.spec.layer == STATIC else self.vehicles
        if layer.get(comp.cell) is comp:
            del layer[comp.cell]
        self.by_id.pop(comp.id, None)

    def remove(self, cid: str) -> list[Component]:
        """Entfernt Komponente; Fahrzeuge auf entfernten Schienen werden mit entfernt."""
        comp = self.by_id.get(cid)
        if comp is None:
            return []
        removed = [comp]
        self._detach(comp)
        if comp.spec.layer == STATIC:
            veh = self.vehicles.get(comp.cell)
            if veh:
                self._detach(veh)
                removed.append(veh)
        return removed

    def replace(self, cid: str, ctype: str, rot: int, props: dict[str, Any] | None = None) -> Component:
        """Ersetzt eine statische Komponente an gleicher Stelle durch einen anderen Typ
        (Fahrzeuge bleiben stehen, Label bleibt erhalten)."""
        old = self.by_id[cid]
        self._detach(old)
        ok, why = self.can_place(ctype, old.cell, props=props)
        if not ok:
            self._insert(old)
            raise LayoutError(why)
        comp = Component(self.new_id(ctype), ctype, old.x, old.y, old.level, rot % 4, old.label, dict(props or {}))
        self._insert(comp)
        return comp

    def with_attached_vehicles(self, ids: Iterable[str]) -> set[str]:
        ids = set(ids)
        for cid in list(ids):
            c = self.by_id.get(cid)
            if c and c.spec.layer == STATIC:
                v = self.vehicles.get(c.cell)
                if v:
                    ids.add(v.id)
        return ids

    def _relocate(self, ids: set[str], new_cells: dict[str, Cell], new_rot: dict[str, int] | None = None) -> bool:
        comps = [self.by_id[i] for i in ids if i in self.by_id]
        backup = {c.id: (c.x, c.y, c.level, c.rot) for c in comps}
        for c in comps:
            self._detach(c)
        for c in comps:
            c.x, c.y, c.level = new_cells[c.id]
            if new_rot:
                c.rot = new_rot[c.id]
        # erst statische, dann Fahrzeuge prüfen und einfügen
        comps.sort(key=lambda c: 0 if c.spec.layer == STATIC else 1)
        ok = True
        inserted: list[Component] = []
        for c in comps:
            good, _ = self.can_place(c.type, c.cell, props=c.props)
            if not good:
                ok = False
                break
            self._insert(c)
            inserted.append(c)
        if not ok:
            for c in inserted:
                self._detach(c)
            for c in comps:
                c.x, c.y, c.level, c.rot = backup[c.id]
                self._insert(c)
        return ok

    def move_group(self, ids: Iterable[str], dx: int, dy: int, dlevel: int = 0) -> bool:
        ids = self.with_attached_vehicles(ids)
        cells = {i: (self.by_id[i].x + dx, self.by_id[i].y + dy, self.by_id[i].level + dlevel)
                 for i in ids if i in self.by_id}
        return self._relocate(ids, cells)

    def rotate_group(self, ids: Iterable[str], k: int = 1) -> bool:
        """Dreht eine Gruppe um k*90° im Uhrzeigersinn um die Mitte ihrer Bounding-Box."""
        ids = self.with_attached_vehicles(ids)
        comps = [self.by_id[i] for i in ids if i in self.by_id]
        if not comps:
            return False
        minx = min(c.x for c in comps); maxx = max(c.x for c in comps)
        miny = min(c.y for c in comps); maxy = max(c.y for c in comps)
        px, py = (minx + maxx) / 2, (miny + maxy) / 2
        cells: dict[str, Cell] = {}
        rots: dict[str, int] = {}
        for c in comps:
            x, y = float(c.x), float(c.y)
            for _ in range(k % 4):
                x, y = px - (y - py), py + (x - px)
            cells[c.id] = (math.floor(x + 0.5), math.floor(y + 0.5), c.level)
            rots[c.id] = (c.rot + k) % 4
        return self._relocate(ids, cells, rots)

    def copy_group(self, ids: Iterable[str]) -> list[dict[str, Any]]:
        """Serialisierte Kopie einer Auswahl (mit Fahrzeugen auf mitkopierten Schienen)."""
        ids = self.with_attached_vehicles(ids)
        return [self.by_id[i].to_dict() for i in sorted(ids) if i in self.by_id]

    def paste_group(self, data: list[dict[str, Any]], dx: int, dy: int, dlevel: int = 0) -> list[Component]:
        """Fügt eine Kopie versetzt ein (neue IDs). Alles oder nichts: bei Konflikt LayoutError."""
        comps = [Component.from_dict(d) for d in data]
        comps.sort(key=lambda c: 0 if c.spec.layer == STATIC else 1)
        added: list[Component] = []
        try:
            for c in comps:
                cell = (c.x + dx, c.y + dy, c.level + dlevel)
                added.append(self.add(c.type, cell, rot=c.rot, props=c.props, label=c.label))
        except LayoutError:
            for c in reversed(added):
                self._detach(c)
            raise
        return added

    def set_lift_target(self, cid: str, target: int) -> tuple[bool, str]:
        """Setzt die Zielebene für die gesamte zusammenhängende Heberkette."""
        comp = self.by_id.get(cid)
        if comp is None or comp.type != LIFT:
            return False, "Kein Heber"
        chain = self.lift_chain(comp)
        old = {c.id: c.props.get("target_level") for c in chain}
        ids = {c.id for c in chain}
        for c in chain:
            c.props["target_level"] = target
        for c in chain:
            ok, why = self.can_place(LIFT, c.cell, ignore=ids, props=c.props)
            if not ok:
                for cc in chain:
                    cc.props["target_level"] = old[cc.id]
                return False, why
        return True, ""

    def default_lift_target(self, level: int) -> int:
        """Eine Ebene nach oben; auf der obersten Ebene eine nach unten."""
        return level + 1 if level + 1 < self.levels else max(0, level - 1)

    def lift_chain(self, comp: Component) -> list[Component]:
        """Zusammenhängende Heberzellen gleicher Richtung auf gleicher Ebene (geordnet)."""
        from matflow.core.geometry import neighbor, opposite
        d = comp.direction
        start = comp
        seen = {comp.id}
        while True:
            prev = self.static.get(neighbor(start.cell, opposite(d)))
            if prev and prev.type == LIFT and prev.direction == d and prev.id not in seen:
                start = prev
                seen.add(prev.id)
            else:
                break
        chain = [start]
        cur = start
        while True:
            nxt = self.static.get(neighbor(cur.cell, d))
            if nxt and nxt.type == LIFT and nxt.direction == d and nxt not in chain:
                chain.append(nxt)
                cur = nxt
            else:
                break
        return chain

    def resize(self, width: int, height: int, levels: int) -> tuple[bool, str]:
        for c in self.by_id.values():
            if not (c.x < width and c.y < height and c.level < levels):
                return False, f"{c.id} liegt außerhalb der neuen Größe"
            if c.type == LIFT and c.target_level >= levels:
                return False, f"Zielebene von {c.id} liegt außerhalb"
        self.width, self.height, self.levels = width, height, levels
        return True, ""

    def clear(self) -> None:
        self.static.clear(); self.vehicles.clear(); self.by_id.clear(); self.counters.clear()

    # ------------------------------------------------------------------ Serialisierung
    def to_dict(self, connections: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        d: dict[str, Any] = {
            "format": "matflow-project",
            "version": FORMAT_VERSION,
            "name": self.name,
            "grid": {"width": self.width, "height": self.height, "levels": self.levels, "cell_size_m": 1.0},
            "params": self.params.to_dict(),
            "components": [c.to_dict() for c in self.components()],
        }
        if connections is not None:
            d["connections"] = connections   # nur informativ, wird beim Laden neu berechnet
        return d

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "Layout":
        if d.get("format") != "matflow-project":
            raise LayoutError("Keine MatFlow-Projektdatei")
        g = d.get("grid", {})
        lay = Layout(int(g.get("width", 48)), int(g.get("height", 32)), int(g.get("levels", 2)),
                     d.get("name", "Anlage"))
        lay.params = SimParams.from_dict(d.get("params", {}))
        comps = [Component.from_dict(c) for c in d.get("components", [])]
        comps.sort(key=lambda c: 0 if c.spec.layer == STATIC else 1)
        for c in comps:
            if c.id in lay.by_id:
                raise LayoutError(f"Doppelte ID {c.id}")
            ok, why = lay.can_place(c.type, c.cell, props=c.props)
            if not ok:
                raise LayoutError(f"{c.id}: {why}")
            lay._insert(c)
        return lay

    def clone(self) -> "Layout":
        return Layout.from_dict(self.to_dict())
