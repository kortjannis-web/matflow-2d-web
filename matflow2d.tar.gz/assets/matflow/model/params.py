"""Globale Parameter (pro Komponententyp, nicht pro Zelle)."""
from __future__ import annotations

from dataclasses import asdict, dataclass, fields
from typing import Any


@dataclass
class SimParams:
    # Geschwindigkeiten in m/s
    conveyor_speed: float = 1.0
    lift_speed: float = 0.8
    epb_straight_speed: float = 1.5
    epb_curve_speed: float = 0.8
    epb_transfer_speed: float = 0.4
    rbg_travel_speed: float = 1.2
    rbg_store_speed: float = 0.3
    rbg_retrieve_speed: float = 0.3
    # Materialfluss
    container_rate: float = 6.0          # Behälter pro Minute (Mittelwert)
    retrieval_rate: float = 0.0          # Auslageraufträge pro Minute (0 = keine Auslagerung)
    nio_rate: float = 0.0                # Anteil NIO-Behälter in %
    sim_duration: float = 0.0            # min, 0 = bis Lager voll bzw. unbegrenzt
    random_seed: int = 1234
    use_seed: bool = True
    # Abstände in m
    epb_min_distance: float = 1.0        # Mitte-Mitte entlang der Strecke (= 1 Rasterzelle)
    container_min_gap: float = 0.75      # Mitte-Mitte zwischen Behältern auf Fördertechnik
    level_height: float = 2.0            # Höhenabstand zwischen zwei Ebenen (RBG-Hubweg)
    # Strategien
    random_rbg: bool = True              # Einlagerung: Ziel-RBG zufällig (gewichtet nach freien Plätzen)
    random_sink: bool = True             # Auslagerung: Ausgang zufällig unter den erreichbaren
    epb_prepos: bool = True              # freie EPBs fahren vorausschauend zum nächsten Aufnahmepunkt

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "SimParams":
        p = SimParams()
        for f in fields(SimParams):
            if f.name in d:
                val = d[f.name]
                if f.type in ("float", float):
                    val = float(val)
                elif f.type in ("int", int):
                    val = int(val)
                elif f.type in ("bool", bool):
                    val = bool(val)
                setattr(p, f.name, val)
        return p

    def copy(self) -> "SimParams":
        return SimParams.from_dict(self.to_dict())


# Beschreibung für das Einstellungs-Panel: (Feld, Beschriftung, Einheit, min, max)
SPEED_FIELDS = [
    ("conveyor_speed", "Fördertechnik", "m/s", 0.05, 10.0),
    ("lift_speed", "Heber", "m/s", 0.05, 10.0),
    ("epb_straight_speed", "EPB gerade", "m/s", 0.05, 10.0),
    ("epb_curve_speed", "EPB Kurve", "m/s", 0.05, 10.0),
    ("epb_transfer_speed", "EPB Übergabe", "m/s", 0.05, 10.0),
    ("rbg_travel_speed", "RBG Fahrt", "m/s", 0.05, 10.0),
    ("rbg_store_speed", "RBG Einlagerung", "m/s", 0.05, 10.0),
    ("rbg_retrieve_speed", "RBG Auslagerung", "m/s", 0.05, 10.0),
]
FLOW_FIELDS = [
    ("container_rate", "Behälterrate", "/min", 0.0, 600.0),
    ("retrieval_rate", "Auslagerrate", "/min", 0.0, 600.0),
    ("nio_rate", "NIO-Anteil", "%", 0.0, 100.0),
    ("random_seed", "Random Seed", "", 0, 2**31 - 1),
]
SIM_FIELDS = [
    ("sim_duration", "Simulationsdauer", "min", 0.0, 100000.0),
]
DISTANCE_FIELDS = [
    ("epb_min_distance", "EPB-Mindestabstand", "m", 0.8, 20.0),
    ("container_min_gap", "Behälterabstand", "m", 0.5, 5.0),
    ("level_height", "Ebenenabstand", "m", 0.5, 20.0),
]
# Schalter (Feld, Beschriftung, Hinweis)
STRATEGY_FIELDS = [
    ("random_rbg", "RBGs zufällig beliefern", "Ziel-RBG je Behälter zufällig, gewichtet nach freien Plätzen"),
    ("random_sink", "Ausgang zufällig wählen", "Auslagerung zu einem zufälligen erreichbaren Ausgang"),
    ("epb_prepos", "Freie EPBs vorpositionieren", "Leere EPBs warten am nächsten Aufnahmepunkt (Quellen zuerst)"),
]
