"""Beispielanlage zur Validierung. Wird ausschließlich über die normale Layout-API aufgebaut und ist
NICHT Teil der Simulationslogik. Sie kann im Editor beliebig verändert werden."""
from __future__ import annotations

from matflow.core.geometry import E, N, S, W
from matflow.model.components import (
    CONVEYOR, EPB, EPB_CURVE, EPB_RAIL, EPB_SWITCH, LIFT, NIO, RBG, RBG_RAIL, SINK, SOURCE, STORAGE,
    curve_for_turn,
)
from matflow.model.layout import Layout


def build_rail_ring(lay: Layout, x0: int, y0: int, x1: int, y1: int, level: int, clockwise: bool = True) -> None:
    """Rechteckiger EPB-Ring mit Kurven an den Ecken (Hilfsfunktion, nutzt nur die Layout-API)."""
    path = []
    for x in range(x0, x1):
        path.append((x, y0))
    for y in range(y0, y1):
        path.append((x1, y))
    for x in range(x1, x0, -1):
        path.append((x, y1))
    for y in range(y1, y0, -1):
        path.append((x0, y))
    if not clockwise:
        path.reverse()
    n = len(path)
    for i, (x, y) in enumerate(path):
        px, py = path[i - 1]
        nx, ny = path[(i + 1) % n]
        din = _d(px, py, x, y)
        dout = _d(x, y, nx, ny)
        if din == dout:
            lay.add(EPB_RAIL, (x, y, level), rot=dout)
        else:
            rot, rev = curve_for_turn(din, dout)
            lay.add(EPB_CURVE, (x, y, level), rot=rot, props={"reverse": rev})


def _d(ax: int, ay: int, bx: int, by: int) -> int:
    return {(0, -1): N, (1, 0): E, (0, 1): S, (-1, 0): W}[(bx - ax, by - ay)]


def build_example(demo: bool = False) -> Layout:
    """Referenzanlage. demo=True stellt zusätzlich Auslagerung und NIO-Anteil ein (Dauerbetrieb)."""
    lay = Layout(40, 26, 2, "Beispielanlage" if not demo else "Beispielanlage Ein-/Auslagerung")
    # Ebene 0: Quelle A → Fördertechnik → 3-m-Heber (E0 → E1)
    lay.add(SOURCE, (3, 10, 0), rot=E, label="Quelle A")
    lay.add(CONVEYOR, (4, 10, 0), rot=E)
    lay.add(CONVEYOR, (5, 10, 0), rot=E)
    for x in (6, 7, 8):
        lay.add(LIFT, (x, 10, 0), rot=E, props={"target_level": 1})
    # Ebene 1: Fördertechnik zum EPB-Aufnahmepunkt
    lay.add(CONVEYOR, (9, 10, 1), rot=E)
    lay.add(CONVEYOR, (10, 10, 1), rot=E)
    lay.add(CONVEYOR, (11, 10, 1), rot=S)
    lay.add(CONVEYOR, (11, 11, 1), rot=S)
    # Quelle B direkt auf Ebene 1 (zweiter Transportweg)
    lay.add(SOURCE, (6, 14, 1), rot=E, label="Quelle B")
    lay.add(CONVEYOR, (7, 14, 1), rot=E)
    lay.add(CONVEYOR, (8, 14, 1), rot=E)
    # EPB-Ring im Uhrzeigersinn
    build_rail_ring(lay, 9, 12, 21, 16, 1, clockwise=True)
    # Abkürzung quer durch den Ring: Verzweigung unten, Zusammenführung oben
    _set_switch(lay, (13, 16, 1), rot=W, merge=False)
    for y in (15, 14, 13):
        lay.add(EPB_RAIL, (13, y, 1), rot=N)
    _set_switch(lay, (13, 12, 1), rot=E, merge=True)
    lay.add(EPB, (15, 12, 1), label="EPB_01")
    lay.add(EPB, (21, 14, 1), label="EPB_02")
    lay.add(EPB, (11, 16, 1), label="EPB_03")
    # EPB-Abgabe → Fördertechnik → RBG
    for y in (17, 18, 19):
        lay.add(CONVEYOR, (17, y, 1), rot=S)
    for x in range(16, 27):
        lay.add(RBG_RAIL, (x, 20, 1), rot=E)
    lay.add(RBG, (21, 20, 1), label="RBG_01")
    for x in range(18, 27):
        lay.add(STORAGE, (x, 19, 1))
    for x in range(16, 27):
        lay.add(STORAGE, (x, 21, 1))
    lay.static[(20, 19, 1)].props["prefilled"] = True
    lay.static[(24, 21, 1)].props["prefilled"] = True
    # Auslagerung: RBG-Abgabe am Schienenende → Fördertechnik → EPB-Aufnahme rechts am Ring
    lay.add(CONVEYOR, (27, 20, 1), rot=E)
    for y in range(20, 14, -1):
        lay.add(CONVEYOR, (28, y, 1), rot=N)
    for x in range(28, 21, -1):
        lay.add(CONVEYOR, (x, 14, 1), rot=W)
    # EPB-Abgabe oben am Ring → Ausgang
    lay.add(CONVEYOR, (14, 11, 1), rot=N)
    lay.add(SINK, (14, 10, 1), label="Ausgang")
    # EPB-Abgabe unten am Ring → NIO-Ausgang
    lay.add(CONVEYOR, (11, 17, 1), rot=S)
    lay.add(NIO, (11, 18, 1), label="NIO")
    if demo:
        lay.params.retrieval_rate = 1.0
        lay.params.nio_rate = 10.0
        lay.params.sim_duration = 60.0
    return lay


def _set_switch(lay: Layout, cell, rot: int, merge: bool) -> None:
    """Ersetzt die Ringzelle durch eine Weiche (Abzweig im Uhrzeigersinn zur Fahrtrichtung)."""
    old = lay.static[cell]
    lay.remove(old.id)
    lay.add(EPB_SWITCH, cell, rot=rot, props={"merge": merge, "mirror": False})
