"""Projektdateien (.mfp, JSON)."""
from __future__ import annotations

import json
from pathlib import Path

from matflow.model.layout import Layout
from matflow.sim.topology import build_topology

EXT = ".mfp"


def save_project(layout: Layout, path: str | Path) -> Path:
    path = Path(path)
    if path.suffix.lower() != EXT:
        path = path.with_suffix(EXT)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(project_text(layout), encoding="utf-8")
    tmp.replace(path)
    return path


def load_project(path: str | Path) -> Layout:
    return parse_project(Path(path).read_text(encoding="utf-8"))


def project_text(layout: Layout) -> str:
    """Projektdatei als Text (JSON)."""
    try:
        conns = build_topology(layout).connections()
    except Exception:  # Verbindungen sind nur informativ
        conns = []
    return json.dumps(layout.to_dict(connections=conns), indent=2, ensure_ascii=False)


def parse_project(text: str) -> Layout:
    return Layout.from_dict(json.loads(text))
