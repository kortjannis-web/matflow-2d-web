"""Richtungen und Rastergeometrie.

Konvention: x nach rechts (Ost), y nach unten (Süd). 1 Rasterzelle = 1 m.
Richtungen als int 0..3 im Uhrzeigersinn: 0=Nord, 1=Ost, 2=Süd, 3=West.
Keine Logik darf fest auf eine Himmelsrichtung codiert sein, alles läuft über diese Funktionen.
"""
from __future__ import annotations

import math

N, E, S, W = 0, 1, 2, 3
DIRS = (N, E, S, W)
DVEC = {N: (0, -1), E: (1, 0), S: (0, 1), W: (-1, 0)}
DIR_NAMES = {N: "Nord", E: "Ost", S: "Süd", W: "West"}
DIR_SHORT = {N: "N", E: "O", S: "S", W: "W"}

Cell = tuple[int, int, int]  # (x, y, ebene)


def rotate_dir(d: int, k: int = 1) -> int:
    """Dreht Richtung d um k*90° im Uhrzeigersinn."""
    return (d + k) % 4


def opposite(d: int) -> int:
    return (d + 2) % 4


def is_perpendicular(a: int, b: int) -> bool:
    return (a - b) % 2 == 1


def neighbor(cell: Cell, d: int) -> Cell:
    dx, dy = DVEC[d]
    return (cell[0] + dx, cell[1] + dy, cell[2])


def dir_between(a: Cell, b: Cell) -> int | None:
    """Richtung von Zelle a zur (4er-)Nachbarzelle b (Ebene wird ignoriert)."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    for d, v in DVEC.items():
        if v == (dx, dy):
            return d
    return None


def center(cell: Cell) -> tuple[float, float]:
    return (cell[0] + 0.5, cell[1] + 0.5)


def edge_mid(cell: Cell, side: int) -> tuple[float, float]:
    cx, cy = center(cell)
    dx, dy = DVEC[side]
    return (cx + 0.5 * dx, cy + 0.5 * dy)


def corner(cell: Cell, side_a: int, side_b: int) -> tuple[float, float]:
    """Gemeinsame Ecke zweier benachbarter Seiten."""
    cx, cy = center(cell)
    ax, ay = DVEC[side_a]
    bx, by = DVEC[side_b]
    return (cx + 0.5 * (ax + bx), cy + 0.5 * (ay + by))


def heading_angle(d: int) -> float:
    """Winkel (rad, math. Konvention im Bildschirm-System: atan2(dy, dx))."""
    dx, dy = DVEC[d]
    return math.atan2(dy, dx)


def rotate_point_cw(x: int, y: int, px: float, py: float) -> tuple[float, float]:
    """Dreht Punkt (x, y) um 90° im Uhrzeigersinn um Pivot (px, py) (y nach unten)."""
    rx, ry = x - px, y - py
    return (px - ry, py + rx)


def dist(a: tuple[float, float], b: tuple[float, float]) -> float:
    return math.hypot(a[0] - b[0], a[1] - b[1])


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t
