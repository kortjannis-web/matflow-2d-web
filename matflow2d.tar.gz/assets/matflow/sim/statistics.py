"""Kennzahlen (KPIs) der Simulation."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from matflow.sim.entities import CState, WAITING_STATES

if TYPE_CHECKING:
    from matflow.sim.engine import Engine


@dataclass
class Stats:
    created: int = 0
    stored: int = 0
    rejected: int = 0        # Ankünfte ohne freie Kapazität
    time_full: float | None = None
    nio_created: int = 0
    nio_out: int = 0
    retrieve_orders: int = 0
    retrieve_rejected: int = 0   # Auslageraufträge ohne belegten Platz
    retrieved: int = 0           # vom RBG aus dem Lager geholt
    out_done: int = 0            # am Ausgang angekommen
    out_lead: list[float] = field(default_factory=list)


def fmt_time(t: float | None) -> str:
    if t is None:
        return "–"
    t = int(round(t))
    h, rem = divmod(t, 3600)
    m, s = divmod(rem, 60)
    return f"{h:d}:{m:02d}:{s:02d}"


def snapshot(eng: "Engine") -> list[tuple[str, list[tuple[str, str]]]]:
    """Gruppierte Kennzahlen für die Anzeige."""
    t = max(eng.time, 1e-9)
    conts = [c for c in eng.containers if not c.prefilled]
    waiting = sum(1 for c in eng.containers if c.state in WAITING_STATES)
    in_system = sum(1 for c in eng.containers if c.state != CState.STORED)
    total = len(eng.storages)
    occ = sum(1 for s in eng.storages.values() if s.occupied)
    pre = sum(1 for s in eng.storages.values() if s.prefilled)
    lead = [c.stored_t - c.created_t for c in conts if c.stored_t is not None]
    st = eng.stats

    def util(vs) -> str:
        if not vs:
            return "–"
        return f"{100 * sum(v.stats.busy for v in vs) / (t * len(vs)):.1f} %"

    epbs, rbgs = eng.epbs, eng.rbgs
    groups = [
        ("Behälter", [
            ("Erzeugt", str(eng.stats.created)),
            ("Eingelagert", str(eng.stats.stored)),
            ("Wartend", str(waiting)),
            ("Im System", str(in_system)),
            ("Ø Durchlaufzeit", f"{sum(lead) / len(lead):.1f} s" if lead else "–"),
            ("Abgewiesen (kein Platz)", str(eng.stats.rejected)),
        ]),
    ]
    if eng.params.nio_rate > 0 or st.nio_created:
        groups.append(("NIO", [
            ("NIO erzeugt", str(st.nio_created)),
            ("am NIO-Ausgang", str(st.nio_out)),
        ]))
    if eng.params.retrieval_rate > 0 or st.retrieve_orders:
        out_lead = st.out_lead
        groups.append(("Auslagerung", [
            ("Aufträge", str(st.retrieve_orders)),
            ("offen", str(eng.rbg.open_retrievals())),
            ("ausgelagert (RBG)", str(st.retrieved)),
            ("am Ausgang", str(st.out_done)),
            ("Ø Lager → Ausgang", f"{sum(out_lead) / len(out_lead):.1f} s" if out_lead else "–"),
            ("ohne Bestand abgewiesen", str(st.retrieve_rejected)),
        ]))
        if not eng.retrieval_active:
            groups[-1][1].append(("Hinweis", "kein Weg zu einem Ausgang"))
    groups += [
        ("Lager", [
            ("Lagerplätze gesamt", str(total)),
            ("Belegt", f"{occ}  (vorbelegt {pre})"),
            ("Frei", str(total - occ)),
            ("Belegungsgrad", f"{100 * occ / total:.1f} %" if total else "–"),
        ]),
        ("EPB", [
            ("Anzahl", str(len(epbs))),
            ("Fahrzeit Σ", f"{sum(e.stats.t_moving for e in epbs):.0f} s"),
            ("Wartezeit Σ", f"{sum(e.stats.t_waiting for e in epbs):.0f} s"),
            ("Auslastung Ø", util(epbs)),
            ("Transporte", str(sum(e.stats.jobs for e in epbs))),
        ]),
        ("RBG", [
            ("Anzahl", str(len(rbgs))),
            ("Fahrzeit Σ", f"{sum(r.stats.t_moving for r in rbgs):.0f} s"),
            ("Wartezeit Σ", f"{sum(r.stats.t_waiting for r in rbgs):.0f} s"),
            ("Einlagerungszeit Σ", f"{sum(r.stats.t_storing for r in rbgs):.0f} s"),
            ("Auslagerungszeit Σ", f"{sum(r.stats.t_retrieving for r in rbgs):.0f} s"),
            ("Auslastung Ø", util(rbgs)),
            ("Einlagerungen", str(sum(r.stats.jobs for r in rbgs))),
            ("Auslagerungen", str(sum(r.stats.retrievals for r in rbgs))),
        ]),
        ("Simulation", [
            ("Simulationszeit", fmt_time(eng.time)),
            ("Zeit bis Lager voll", fmt_time(eng.stats.time_full)),
            ("Quellen", str(len(eng.sources))),
        ]),
    ]
    return groups


def vehicle_rows(eng: "Engine") -> list[tuple[str, str, str]]:
    """(Name, Zustand, Auslastung) je Fahrzeug."""
    t = max(eng.time, 1e-9)
    rows = []
    for e in eng.epbs:
        rows.append((e.label, e.state.value, f"{100 * e.stats.busy / t:.0f} %"))
    for r in eng.rbgs:
        rows.append((r.label, r.state.value, f"{100 * r.stats.busy / t:.0f} %"))
    return rows
