"""Zentrale Auftragsverwaltung für EPBs.

- Bei Erzeugung eines Behälters wird der zukünftige EPB-Aufnahmepunkt bekannt (Route).
- Es wird die freie EPB mit der kürzesten GERICHTETEN Fahrstrecke bis zum Aufnahmepunkt gewählt
  (nicht Luftlinie, nicht Manhattan).
- Die EPB fährt vorausschauend zum Aufnahmepunkt und wartet dort.
- Wird später eine EPB frei, die den Punkt schneller erreicht, übernimmt sie den Auftrag,
  solange die bisher zugewiesene EPB noch unterwegs ist.
"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING

from matflow.sim.entities import Container, Epb, EpbRequest, EpbState
from matflow.sim.routing import EpbLeg

if TYPE_CHECKING:
    from matflow.sim.engine import Engine


class Dispatcher:
    def __init__(self, eng: "Engine"):
        self.eng = eng
        self.pending: list[EpbRequest] = []
        self.active: list[EpbRequest] = []
        self.by_container: dict[str, EpbRequest] = {}

    def epbs_on(self, net_id: int) -> list[Epb]:
        return self.eng.epbs_by_net.get(net_id, [])

    # ------------------------------------------------------------------ Aufträge
    def request(self, c: Container, leg: EpbLeg) -> EpbRequest:
        topo = self.eng.topo
        req = EpbRequest(c, leg, topo.rail_point(leg.pick_rail), topo.rail_point(leg.drop_rail), self.eng.time)
        self.pending.append(req)
        self.by_container[c.id] = req
        return req

    def _assign(self, req: EpbRequest, e: Epb) -> None:
        if req in self.pending:
            self.pending.remove(req)
        if req not in self.active:
            self.active.append(req)
        req.epb = e
        e.request = req
        e.state = EpbState.MOVING_TO_PICKUP

    def _unassign(self, req: EpbRequest) -> None:
        e = req.epb
        if e is not None:
            e.request = None
            e.state = EpbState.IDLE
        req.epb = None
        if req in self.active:
            self.active.remove(req)
        self.pending.append(req)
        self.pending.sort(key=lambda r: (r.created_t, r.container.id))

    def finish(self, req: EpbRequest) -> None:
        if req in self.active:
            self.active.remove(req)
        self.by_container.pop(req.container.id, None)

    def distance(self, e: Epb, req: EpbRequest) -> float:
        """Gerichtete Fahrstrecke im Schienennetz (nicht Luftlinie, nicht Manhattan)."""
        return self.eng.topo.network.path_dist(e.track.id, e.s, req.pick[0], req.pick[1])

    def best_idle(self, req: EpbRequest) -> tuple[Epb | None, float]:
        best, best_d = None, math.inf
        for e in self.epbs_on(req.leg.net_id):
            if e.state != EpbState.IDLE:
                continue
            d = self.distance(e, req)
            if d < best_d - 1e-9 or (abs(d - best_d) <= 1e-9 and best is not None and e.id < best.id):
                best, best_d = e, d
        return best, best_d

    def swap_for_container(self, e: Epb, c: Container) -> None:
        """EPB e wartet am Aufnahmepunkt, dort steht aber zuerst Behälter c (anderer Auftrag).
        Die Aufträge werden getauscht, damit kein Stau/Deadlock entsteht."""
        mine = e.request
        other = self.by_container.get(c.id)
        if other is None or other is mine:
            return
        other_epb = other.epb
        if other_epb is None:
            # anderer Auftrag war noch ohne EPB → e übernimmt ihn, eigener Auftrag wird wieder offen
            if mine is not None:
                mine.epb = None
                if mine in self.active:
                    self.active.remove(mine)
                self.pending.append(mine)
                self.pending.sort(key=lambda r: (r.created_t, r.container.id))
            if other in self.pending:
                self.pending.remove(other)
            self.active.append(other)
            other.epb = e
            e.request = other
            return
        # beide haben EPBs → EPBs tauschen
        other.epb, mine.epb = e, other_epb
        e.request, other_epb.request = other, mine
        other_epb.state = EpbState.MOVING_TO_PICKUP if other_epb.state != EpbState.WAITING_FOR_CONTAINER \
            else EpbState.WAITING_FOR_CONTAINER

    # ------------------------------------------------------------------ Takt
    def update(self) -> None:
        for req in list(self.pending):
            e, d = self.best_idle(req)
            if e is not None and d < math.inf:
                self._assign(req, e)
        # bessere freie EPB übernimmt noch nicht angekommene Zuweisungen
        for req in list(self.active):
            cur = req.epb
            if cur is None or cur.state != EpbState.MOVING_TO_PICKUP:
                continue
            e, d = self.best_idle(req)
            if e is not None and d < self.distance(cur, req) - 1e-6:
                cur.request = None
                cur.state = EpbState.IDLE
                req.epb = None
                self._assign(req, e)
