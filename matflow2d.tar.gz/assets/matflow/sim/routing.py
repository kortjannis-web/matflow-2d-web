"""Routing: gerichteter Graph aus der Topologie und Kürzeste-Wege-Suche (Dijkstra, Zeitkosten).

Knoten:
  ("F", cell)                 Förderknoten (Mittelpunkt)
  ("EP", net, cell)           EPB-Aufnahme an Schienenzelle
  ("ED", net, rail, flow)     EPB-Abgabe an Förderzelle
  ("R", system)               RBG-System (Ziel Einlagerung)
  ("X", cell)                 Ausgang bzw. NIO-Ausgang (Ziel)
Das Ergebnis ist eine Transportkette aus Abschnitten (Legs), die vollständig aus dem Layout stammt.
"""
from __future__ import annotations

import heapq
import itertools
from dataclasses import dataclass, field
from typing import Callable, Union

from matflow.core.geometry import Cell
from matflow.model.components import LIFT, TYPES
from matflow.model.params import SimParams
from matflow.sim.topology import Topology

INF = float("inf")


@dataclass
class ConveyorLeg:
    nodes: list[Cell]


@dataclass
class EpbLeg:
    net_id: int
    pick_rail: Cell
    drop_rail: Cell
    from_cell: Cell
    to_cell: Cell


@dataclass
class RbgLeg:
    system_id: int
    rail_cell: Cell
    from_cell: Cell


@dataclass
class ExitLeg:
    cell: Cell
    kind: str                        # Komponententyp: sink | nio


Leg = Union[ConveyorLeg, EpbLeg, RbgLeg, ExitLeg]
Goal = Callable[[tuple], bool]


@dataclass
class Route:
    legs: list[Leg] = field(default_factory=list)
    cost: float = 0.0

    @property
    def system_id(self) -> int:
        for leg in reversed(self.legs):
            if isinstance(leg, RbgLeg):
                return leg.system_id
        return -1

    @property
    def exit(self) -> ExitLeg | None:
        last = self.legs[-1] if self.legs else None
        return last if isinstance(last, ExitLeg) else None

    def copy(self) -> "Route":
        return Route(list(self.legs), self.cost)

    def describe(self, topo: Topology) -> list[str]:
        st = topo.layout.static
        out = []
        for leg in self.legs:
            if isinstance(leg, ConveyorLeg):
                names = []
                for n in leg.nodes:
                    t = st[n].spec.name
                    if not names or names[-1] != t:
                        names.append(t)
                if self.exit is not None and names and names[-1] == TYPES[self.exit.kind].name:
                    names.pop()
                out.extend(names)
            elif isinstance(leg, EpbLeg):
                out.append(f"EPB ({st[leg.pick_rail].id} → {st[leg.drop_rail].id})")
            elif isinstance(leg, RbgLeg):
                out.append(f"RBG ({topo.rbg_systems[leg.system_id].label})")
            else:
                out.append(st[leg.cell].display_name)
        if not isinstance(self.legs[-1], ExitLeg):
            out.append("Lagerplatz")
        return out


def segment_speed(topo: Topology, params: SimParams, a: Cell, b: Cell) -> float:
    """Geschwindigkeit zwischen zwei Mittelpunkten. Heber nur, wenn beide Zellen Heberzellen sind
    (Übernahme am Mittelpunkt der ersten und Übergabe am Mittelpunkt der letzten Heberzelle)."""
    fa, fb = topo.flow.get(a), topo.flow.get(b)
    if fa is not None and fb is not None and fa.type == LIFT and fb.type == LIFT:
        return params.lift_speed
    return params.conveyor_speed


def storage_goal(target_ok: Callable[[int], bool] | None = None) -> Goal:
    return lambda n: n[0] == "R" and (target_ok is None or target_ok(n[1]))


def exit_goal(topo: Topology, kind: str) -> Goal:
    return lambda n: n[0] == "X" and topo.exits[n[1]].type == kind


class Router:
    def __init__(self, topo: Topology, params: SimParams):
        self.topo = topo
        self.params = params
        self.adj: dict[tuple, list[tuple[tuple, float]]] = {}
        self._build()

    def _edge(self, a: tuple, b: tuple, cost: float) -> None:
        self.adj.setdefault(a, []).append((b, cost))

    def _build(self) -> None:
        t, p = self.topo, self.params
        for c, fn in t.flow.items():
            for b in fn.branches:                       # FT-Weiche: Abzweige
                self._edge(("F", c), ("F", b), t.seg_len(c, b) / segment_speed(t, p, c, b))
            if fn.out_kind == "flow" and fn.out in t.flow:
                seg = t.seg_len(c, fn.out)
                self._edge(("F", c), ("F", fn.out), seg / segment_speed(t, p, c, fn.out))
            elif fn.out_kind == "epb" and c in t.epb_picks:
                h = t.epb_picks[c]
                if h.net_id >= 0:
                    self._edge(("F", c), ("EP", h.net_id, h.rail_cell), 1.0 / p.epb_transfer_speed)
            elif fn.out_kind == "rbg" and c in t.rbg_picks:
                self._edge(("F", c), ("R", t.rbg_picks[c].system_id), 0.0)
            elif fn.out_kind == "exit":
                self._edge(("F", c), ("X", c), 0.0)
        picks_by_net: dict[int, set[Cell]] = {}
        for h in t.epb_picks.values():
            if h.net_id >= 0:
                picks_by_net.setdefault(h.net_id, set()).add(h.rail_cell)
        net = t.network
        for d in t.epb_drops:
            if d.net_id < 0:
                continue
            dt_, ds = t.rail_point(d.rail_cell)
            for pr in sorted(picks_by_net.get(d.net_id, set())):
                pt, ps = t.rail_point(pr)
                dist = net.path_dist(pt, ps, dt_, ds)
                if dist == INF:
                    continue
                self._edge(("EP", d.net_id, pr), ("ED", d.net_id, d.rail_cell, d.flow_cell),
                           dist / p.epb_straight_speed)
            self._edge(("ED", d.net_id, d.rail_cell, d.flow_cell), ("F", d.flow_cell), 1.0 / p.epb_transfer_speed)

    def search(self, start: Cell, goal: Goal) -> Route | None:
        """Kürzester Weg von einer Förderzelle zu einem Zielknoten, der goal erfüllt."""
        src = ("F", start)
        cnt = itertools.count()
        dist = {src: 0.0}
        prev: dict[tuple, tuple] = {}
        heap = [(0.0, next(cnt), src)]
        found = None
        while heap:
            d, _, u = heapq.heappop(heap)
            if d > dist.get(u, INF):
                continue
            if u[0] in ("R", "X") and goal(u):
                found = u
                break
            for v, w in self.adj.get(u, []):
                nd = d + w
                if nd < dist.get(v, INF) - 1e-12:
                    dist[v] = nd
                    prev[v] = u
                    heapq.heappush(heap, (nd, next(cnt), v))
        if found is None:
            return None
        path = [found]
        while path[-1] != src:
            path.append(prev[path[-1]])
        path.reverse()
        return self._to_route(path, dist[found])

    def find(self, start: Cell, target_ok: Callable[[int], bool] | None = None) -> Route | None:
        """Kürzester Weg von einer Förderzelle zu einem RBG-System, das target_ok erfüllt."""
        return self.search(start, storage_goal(target_ok))

    def find_exit(self, start: Cell, kind: str) -> Route | None:
        return self.search(start, exit_goal(self.topo, kind))

    def find_exit_cell(self, start: Cell, cell: Cell) -> Route | None:
        """Kürzester Weg zu genau diesem Ausgang."""
        return self.search(start, lambda n: n[0] == "X" and n[1] == cell)

    def reachable_exits(self, start: Cell, kind: str) -> list[Cell]:
        return sorted(n[1] for n in self.reachable(start) if n[0] == "X" and self.topo.exits[n[1]].type == kind)

    def reachable(self, start: Cell) -> set[tuple]:
        seen = {("F", start)}
        stack = [("F", start)]
        while stack:
            u = stack.pop()
            for v, _ in self.adj.get(u, []):
                if v not in seen:
                    seen.add(v)
                    stack.append(v)
        return seen

    def reachable_systems(self, start: Cell) -> set[int]:
        return {n[1] for n in self.reachable(start) if n[0] == "R"}

    def _to_route(self, path: list[tuple], cost: float) -> Route:
        legs: list[Leg] = []
        cur: list[Cell] = []
        i = 0
        while i < len(path):
            node = path[i]
            if node[0] == "F":
                cur.append(node[1])
            elif node[0] == "EP":
                drop = path[i + 1]
                legs.append(ConveyorLeg(cur))
                legs.append(EpbLeg(node[1], node[2], drop[2], cur[-1], drop[3]))
                cur = []
                i += 1          # ED-Knoten überspringen, nächster F-Knoten startet neuen Abschnitt
            elif node[0] == "R":
                legs.append(ConveyorLeg(cur))
                legs.append(RbgLeg(node[1], self.topo.rbg_picks[cur[-1]].rail_cell, cur[-1]))
                cur = []
            elif node[0] == "X":
                legs.append(ConveyorLeg(cur))
                legs.append(ExitLeg(node[1], self.topo.exits[node[1]].type))
                cur = []
            i += 1
        return Route(legs, cost)
