"""Behälterbewegung auf Fördertechnik/Heber und seitliche Übergaben.

Regeln:
- Bewegung kontinuierlich von Mittelpunkt zu Mittelpunkt.
- Vor dem Verlassen eines Mittelpunkts wird der nächste Knoten reserviert (Stau statt Überlappung).
- Der verlassene Knoten wird freigegeben, sobald der Behälter ihn verlassen hat.
- Zusätzlich darf sich kein Behälter einem anderen auf weniger als `container_min_gap` nähern.
"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING

from matflow.core.geometry import Cell, center
from matflow.model.components import LIFT
from matflow.sim.entities import OUT, CState, Container, Transfer
from matflow.sim.routing import ConveyorLeg, EpbLeg, ExitLeg, RbgLeg, segment_speed

if TYPE_CHECKING:
    from matflow.sim.engine import Engine

EPS = 1e-9


class MaterialFlow:
    def __init__(self, eng: "Engine"):
        self.eng = eng
        self.res: dict[Cell, str] = {}
        self.waiting_at_pick: dict[Cell, list[Container]] = {}   # EPB-Schienenzelle → wartende Behälter
        # Heber: je Kette höchstens ein Behälter; nach dem Verlassen fährt der Heber leer zurück
        self.lift_cells: dict[int, list[Cell]] = {}
        for cell, fn in eng.topo.flow.items():
            if fn.lift_chain >= 0:
                self.lift_cells.setdefault(fn.lift_chain, []).append(cell)
        self.lift_holder: dict[int, Container] = {}
        self.lift_free_at: dict[int, float] = {}

    # ------------------------------------------------------------------ Heber
    def lift_return_time(self, chain: int) -> float:
        """Leerfahrt zurück = Fahrzeit eines Behälters durch die Heberkette."""
        n = len(self.lift_cells.get(chain, ()))
        return max(1, n - 1) / max(1e-6, self.eng.params.lift_speed)

    def lift_free(self, chain: int, c: Container | None = None) -> bool:
        holder = self.lift_holder.get(chain)
        if holder is not None:
            return holder is c
        return self.eng.time >= self.lift_free_at.get(chain, 0.0) - 1e-9

    def _update_lifts(self) -> None:
        """Gibt Heber frei, sobald ihr Behälter keine Heberzelle mehr belegt; dann läuft die Rückfahrt."""
        if not self.lift_holder:
            return
        for chain, c in list(self.lift_holder.items()):
            cid = c.id
            if not any(self.res.get(cell) == cid for cell in self.lift_cells[chain]):
                del self.lift_holder[chain]
                self.lift_free_at[chain] = self.eng.time + self.lift_return_time(chain)

    # ------------------------------------------------------------------ Reservierung
    def reserve(self, c: Container, cell: Cell) -> bool:
        holder = self.res.get(cell)
        if holder is None or holder == c.id:
            self.res[cell] = c.id
            c.holds.add(cell)
            return True
        return False

    def release(self, c: Container, cell: Cell) -> None:
        if self.res.get(cell) == c.id:
            del self.res[cell]
        c.holds.discard(cell)

    def release_all(self, c: Container) -> None:
        for cell in list(c.holds):
            self.release(c, cell)

    # ------------------------------------------------------------------ Hilfen
    def node_pos(self, cell: Cell) -> tuple[float, float, float]:
        x, y = center(cell)
        fn = self.eng.topo.flow.get(cell)
        return x, y, (fn.z if fn else float(cell[2]))

    def floor_containers(self) -> list[Container]:
        return [c for c in self.eng.containers if c.active_on_floor]

    def clear_at(self, p: tuple[float, float], z: float, ignore: Container | None = None) -> bool:
        gap = self.eng.params.container_min_gap
        for o in self.floor_containers():
            if o is ignore or abs(o.z - z) > 0.5:
                continue
            if math.hypot(o.pos[0] - p[0], o.pos[1] - p[1]) < gap - 1e-6:
                return False
        return True

    def _limit(self, c: Container, others: list[Container], p0: tuple[float, float], p1: tuple[float, float],
               z: float) -> float:
        """Größter Anteil f in [0, 1] der Bewegung p0→p1, der den Mindestabstand einhält."""
        gap = self.eng.params.container_min_gap
        near = []
        for o in others:
            if o is c or o.pos is None or abs(o.z - z) > 0.5:
                continue
            if abs(o.pos[0] - p0[0]) > 2.5 or abs(o.pos[1] - p0[1]) > 2.5:
                continue
            near.append((o.pos, math.hypot(o.pos[0] - p0[0], o.pos[1] - p0[1])))
        if not near:
            return 1.0

        def ok(f: float) -> bool:
            x = p0[0] + (p1[0] - p0[0]) * f
            y = p0[1] + (p1[1] - p0[1]) * f
            for op, d0 in near:
                d = math.hypot(op[0] - x, op[1] - y)
                if d < gap - 1e-9 and d < d0 - 1e-9:
                    return False
            return True

        if ok(1.0):
            return 1.0
        lo, hi = 0.0, 1.0
        for _ in range(8):
            mid = (lo + hi) / 2
            if ok(mid):
                lo = mid
            else:
                hi = mid
        return lo

    # ------------------------------------------------------------------ Abschnitte
    def current_leg(self, c: Container):
        return c.route.legs[c.leg_idx] if c.route and c.leg_idx < len(c.route.legs) else None

    def next_leg(self, c: Container):
        if c.route and c.leg_idx + 1 < len(c.route.legs):
            return c.route.legs[c.leg_idx + 1]
        return None

    def start_conveyor_leg(self, c: Container, leg_idx: int) -> None:
        """Behälter befindet sich auf dem ersten Knoten des Abschnitts (reserviert)."""
        c.leg_idx = leg_idx
        leg = c.route.legs[leg_idx]
        assert isinstance(leg, ConveyorLeg)
        c.nodes = leg.nodes
        c.seg, c.t = 0, 0.0
        x, y, z = self.node_pos(c.nodes[0])
        c.pos, c.z = (x, y), z
        c.carrier = None
        c.set_state(CState.ON_CONVEYOR, self.eng.time)
        nxt = self.next_leg(c)
        if isinstance(nxt, EpbLeg) and (leg_idx > 0 or c.kind == OUT):
            self.eng.dispatcher.request(c, nxt)

    def _leg_end(self, c: Container) -> None:
        nxt = self.next_leg(c)
        if isinstance(nxt, EpbLeg):
            if c.state != CState.WAITING_FOR_EPB:
                c.set_state(CState.WAITING_FOR_EPB, self.eng.time)
                self.waiting_at_pick.setdefault(nxt.pick_rail, []).append(c)
        elif isinstance(nxt, RbgLeg):
            if c.state != CState.WAITING_FOR_RBG:
                c.set_state(CState.WAITING_FOR_RBG, self.eng.time)
                self.eng.rbg.enqueue(c, nxt)
        elif isinstance(nxt, ExitLeg):
            self.eng.on_exit(c, nxt)
        elif c.state != CState.BLOCKED:
            c.set_state(CState.BLOCKED, self.eng.time)

    # ------------------------------------------------------------------ Update
    def update(self, dt: float) -> None:
        eng = self.eng
        others = self.floor_containers()
        moving = [c for c in eng.containers if c.state in (CState.ON_CONVEYOR, CState.ON_LIFT)]
        for c in moving:
            self._move_conveyor(c, dt, others)
        for c in [c for c in eng.containers if c.transfer is not None]:
            self._move_transfer(c, dt, others)
        self._update_lifts()

    def _move_conveyor(self, c: Container, dt: float, others: list[Container]) -> None:
        eng = self.eng
        topo, params = eng.topo, eng.params
        remaining = dt
        guard = 0
        while remaining > EPS and guard < 8:
            guard += 1
            if c.seg >= len(c.nodes) - 1:
                self._leg_end(c)
                return
            a, b = c.nodes[c.seg], c.nodes[c.seg + 1]
            fa, fb = topo.flow.get(a), topo.flow.get(b)
            if c.t <= EPS:
                chain = fb.lift_chain if fb is not None else -1
                entering = chain >= 0 and (fa is None or fa.lift_chain != chain)
                if entering and not self.lift_free(chain, c):
                    return                              # Heber belegt oder fährt noch zurück
                if not self.reserve(c, b):
                    return                              # Stau: nächster Knoten belegt
                if entering:
                    self.lift_holder[chain] = c
            seglen = topo.seg_len(a, b)
            v = segment_speed(topo, params, a, b)
            on_lift = fa is not None and fb is not None and fa.type == LIFT and fb.type == LIFT
            c.set_state(CState.ON_LIFT if on_lift else CState.ON_CONVEYOR, eng.time)
            step = min(v * remaining, seglen - c.t)
            ax, ay, az = self.node_pos(a)
            bx, by, bz = self.node_pos(b)
            p0 = c.pos
            f1 = (c.t + step) / seglen
            p1 = (ax + (bx - ax) * f1, ay + (by - ay) * f1)
            frac = self._limit(c, others, p0, p1, c.z)
            step *= frac
            if step <= EPS:
                return
            c.t += step
            remaining -= step / v
            f = c.t / seglen
            c.pos = (ax + (bx - ax) * f, ay + (by - ay) * f)
            c.z = az + (bz - az) * f
            if a in c.holds:
                self.release(c, a)
            if c.t >= seglen - 1e-7:
                c.seg += 1
                c.t = 0.0
                c.pos = (bx, by)
                c.z = bz
            if frac < 1.0:
                return
        if c.seg >= len(c.nodes) - 1:
            self._leg_end(c)

    # ------------------------------------------------------------------ Übergaben
    def start_transfer(self, c: Container, kind: str, p1: tuple[float, float], z1: float, speed_attr: str,
                       collide: bool = True) -> None:
        p0 = c.pos
        length = max(1e-6, math.hypot(p1[0] - p0[0], p1[1] - p0[1]))
        c.transfer = Transfer(kind, p0, p1, c.z, z1, speed_attr, length, 0.0, collide)
        c.carrier = None

    def _move_transfer(self, c: Container, dt: float, others: list[Container]) -> None:
        tr = c.transfer
        v = max(1e-6, getattr(self.eng.params, tr.speed_attr))
        step = min(v * dt, tr.length - tr.progress)
        if tr.collide and step > 0:
            f_new = (tr.progress + step) / tr.length
            p1 = (tr.p0[0] + (tr.p1[0] - tr.p0[0]) * f_new, tr.p0[1] + (tr.p1[1] - tr.p0[1]) * f_new)
            step *= self._limit(c, others, c.pos, p1, c.z)
        tr.progress += step
        if tr.progress > 0:
            for cell in list(c.holds):
                if tr.kind in ("to_epb", "to_rbg"):
                    self.release(c, cell)
        f = tr.progress / tr.length
        c.pos = (tr.p0[0] + (tr.p1[0] - tr.p0[0]) * f, tr.p0[1] + (tr.p1[1] - tr.p0[1]) * f)
        c.z = tr.z0 + (tr.z1 - tr.z0) * f
        if tr.progress >= tr.length - 1e-7:
            c.pos = tr.p1
            c.z = tr.z1
            c.transfer = None
            self.eng.on_transfer_done(c, tr.kind, tr.vehicle)
