"""EPB-Fahrlogik: Zustände, kontinuierliche Bewegung im Schienennetz, Mindestabstand, Weichen.

Abstandsregel: Eine EPB fährt nur so weit, dass der Mindestabstand (Mitte-Mitte entlang ihres
geplanten Fahrwegs) zur vorausfahrenden EPB jederzeit eingehalten wird. Freie (IDLE) EPBs, die einer
beauftragten EPB im Weg stehen, werden "angeschoben", d. h. sie fahren entsprechend weiter.

Weichen: Eine Weiche darf immer nur von einer EPB befahren werden. Vor der Einfahrt reserviert die
EPB die Weiche; ohne Reservierung wartet sie mit dem halben Mindestabstand vor der Weiche. Die
Reservierung endet, wenn die EPB die Weiche um den halben Mindestabstand verlassen hat. Dadurch
bleibt auch an Zusammenführungen der Abstand zwischen EPBs aus verschiedenen Zweigen gewahrt.

Vorpositionierung (Parameter epb_prepos): Eine freie EPB ohne Auftrag fährt schon zum nächsten
Aufnahmepunkt in Fahrtrichtung, an dem Behälter anstehen könnten. Aufnahmepunkte, die direkt von einer
Quelle gespeist werden, haben Vorrang; gibt es keine, zählt jeder Aufnahmepunkt (z. B. hinter einer
RBG-Abgabe). Mehrere freie EPBs stellen sich hintereinander an. Kommt ein echter Auftrag, gilt die
normale Disposition.
"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING

from matflow.core.geometry import center
from matflow.model.components import SOURCE
from matflow.sim.entities import CState, Epb, EpbState
from matflow.sim.tracks import Track

if TYPE_CHECKING:
    from matflow.sim.engine import Engine

ARRIVE = 1e-6
INF = math.inf


def epb_speed(track: Track, s: float, params) -> float:
    return params.epb_curve_speed if track.cell_at(s).is_curve else params.epb_straight_speed


class EpbControl:
    def __init__(self, eng: "Engine"):
        self.eng = eng
        self.topo = eng.topo
        self.net = eng.topo.network
        self.tracks = eng.topo.tracks
        self.holder: dict[str, Epb | None] = {}
        self.park_points: dict[int, list[tuple[int, float]]] = self._park_points()

    def _park_points(self) -> dict[int, list[tuple[int, float]]]:
        """Je Schienennetz die Aufnahmepunkte für die Vorpositionierung (Quell-Aufnahmen bevorzugt)."""
        topo = self.topo
        feeders: dict = {}
        for c, fn in topo.flow.items():
            outs = list(fn.branches)
            if fn.out_kind == "flow" and fn.out is not None:
                outs.append(fn.out)
            for o in outs:
                feeders.setdefault(o, []).append(c)

        def sourced(cell) -> bool:
            seen, stack = {cell}, [cell]
            while stack:
                cur = stack.pop()
                if topo.flow[cur].type == SOURCE:
                    return True
                for p in feeders.get(cur, []):
                    if p not in seen:
                        seen.add(p)
                        stack.append(p)
            return False

        by_net: dict[int, list[tuple[bool, tuple[int, float]]]] = {}
        for c, h in sorted(topo.epb_picks.items()):
            if h.net_id < 0 or h.rail_cell not in topo.rail_track:
                continue
            by_net.setdefault(h.net_id, []).append((sourced(c), topo.rail_point(h.rail_cell)))
        out = {}
        for nid, lst in by_net.items():
            pref = [pt for src, pt in lst if src]
            out[nid] = sorted(set(pref or [pt for _, pt in lst]))
        return out

    def _park_dist(self, e: Epb, pt: tuple[int, float]) -> float:
        """Fahrstrecke bis zum Wartepunkt; knapp überfahren zählt als angekommen."""
        if self.net.path_dist(pt[0], pt[1], e.track.id, e.s) < 1e-6:
            return 0.0
        return self.net.path_dist(e.track.id, e.s, pt[0], pt[1])

    def update_parking(self, epbs: list[Epb]) -> None:
        on = self.eng.params.epb_prepos
        for e in epbs:
            e.park = None
            if not on or e.state != EpbState.IDLE or e.request is not None:
                continue
            best, bd = None, INF
            for pt in self.park_points.get(e.net, []):
                d = self._park_dist(e, pt)
                if d < bd - 1e-9:
                    best, bd = pt, d
            e.park = best

    # ------------------------------------------------------------------ Grundlagen
    @property
    def clear(self) -> float:
        return 0.5 * self.eng.params.epb_min_distance

    def init_holds(self) -> None:
        """Startbelegung: EPBs in oder direkt hinter einer Weiche halten deren Reservierung."""
        for e in sorted(self.eng.epbs, key=lambda v: v.id):
            tr = e.track
            if tr.switch_id is not None and self.holder.get(tr.switch_id) is None:
                self.holder[tr.switch_id] = e
                e.held[tr.switch_id] = None
            elif not tr.closed and e.s < self.clear:
                for p in tr.pred:
                    sw = self.tracks[p].switch_id
                    if sw is not None and self.holder.get(sw) is None:
                        self.holder[sw] = e
                        e.held[sw] = e.s

    def dist_to(self, e: Epb, tgt: tuple[int, float] | None) -> float:
        if tgt is None:
            return INF
        return self.net.path_dist(e.track.id, e.s, tgt[0], tgt[1])

    def next_track(self, e: Epb, cur: int) -> int | None:
        tgt = e.target()
        return self.net.next_toward(cur, tgt[0] if tgt else None)

    def look(self, e: Epb, horizon: float) -> list[tuple[int, float]]:
        """Geplanter Fahrweg als Liste (Strecke, Abstand bis Streckenanfang); aktuelle Strecke zuerst."""
        tr = e.track
        out = [(tr.id, -e.s)]
        if tr.closed:
            return out
        tgt = e.target()
        reached = tgt is None or (tgt[0] == tr.id and tgt[1] >= e.s - 1e-9)
        total = tr.length - e.s
        cur = tr.id
        guard = 0
        while total < horizon and guard < 64:
            guard += 1
            nxt = self.net.next_toward(cur, None if reached else tgt[0])
            if nxt is None:
                break
            if not reached and nxt == tgt[0]:
                reached = True
            out.append((nxt, total))
            total += self.tracks[nxt].length
            cur = nxt
        return out

    def leader(self, e: Epb, look: list[tuple[int, float]], others: list[Epb]) -> tuple[float, Epb | None]:
        """Nächste EPB voraus auf dem geplanten Fahrweg (Abstand Mitte-Mitte)."""
        best, lead = INF, None
        for f in others:
            if f is e:
                continue
            for i, (tid, off) in enumerate(look):
                if f.track.id != tid:
                    # anderer Fahrweg derselben Verzweigung: gleicher Einfahrtspunkt, zählt als voraus
                    tr = self.tracks[tid]
                    sw = tr.switch_id
                    if i == 0 or sw is None or f.track.switch_id != sw or tr.cells[0].comp.switch_merge:
                        continue
                if i == 0:
                    tr = e.track
                    d = tr.dist_ahead(e.s, f.s) if tr.closed else f.s - e.s
                    if d <= 1e-12:
                        continue
                else:
                    d = off + f.s
                if d < best:
                    best, lead = d, f
        return best, lead

    def _count(self, e: Epb, d: float) -> None:
        for sw, cnt in e.held.items():
            if cnt is not None:
                e.held[sw] = cnt + d

    def _release(self, e: Epb, sw: str) -> None:
        e.held.pop(sw, None)
        if self.holder.get(sw) is e:
            self.holder[sw] = None

    def release_remaining(self, e: Epb) -> float:
        """Fahrstrecke, bis alle Weichen-Reservierungen dieser EPB frei werden."""
        need = 0.0
        for sw, cnt in e.held.items():
            if cnt is None:
                if e.track.switch_id == sw:
                    need = max(need, e.track.length - e.s + self.clear)
            else:
                need = max(need, self.clear - cnt)
        return max(0.0, need)

    # ------------------------------------------------------------------ Bewegung
    def advance(self, e: Epb, step: float) -> float:
        rem = step
        guard = 0
        while rem > 1e-12 and guard < 32:
            guard += 1
            tr = e.track
            if tr.closed:
                e.s = (e.s + rem) % tr.length
                self._count(e, rem)
                rem = 0.0
                break
            room = tr.s_max - e.s
            if rem < room - 1e-12 or not tr.succ:
                mv = min(rem, max(0.0, room))
                e.s += mv
                self._count(e, mv)
                rem -= mv
                break
            nxt = self.next_track(e, tr.id)
            if nxt is None:
                break
            e.s = tr.length
            self._count(e, room)
            rem -= room
            if tr.switch_id is not None and tr.switch_id in e.held:
                e.held[tr.switch_id] = 0.0
            e.track = self.tracks[nxt]
            e.s = 0.0
        for sw, cnt in list(e.held.items()):
            if cnt is not None and cnt >= self.clear - 1e-9:
                self._release(e, sw)
        return step - rem

    def move_net(self, epbs: list[Epb], dt: float, desire: dict[str, float]) -> None:
        params = self.eng.params
        min_d = params.epb_min_distance
        clear = self.clear
        if not epbs:
            return
        vmax = max(params.epb_straight_speed, params.epb_curve_speed)
        horizon = min_d + vmax * dt + 2.0 + clear
        by_id = {e.id: e for e in epbs}
        looks = {e.id: self.look(e, horizon) for e in epbs}
        # Reservierungen für Weichen, die nicht mehr auf dem Fahrweg liegen, freigeben
        for e in epbs:
            ahead = {self.tracks[t].switch_id for t, _ in looks[e.id]}
            for sw, cnt in list(e.held.items()):
                if cnt is None and e.track.switch_id != sw and sw not in ahead:
                    self._release(e, sw)
        lead: dict[str, tuple[float, Epb | None]] = {e.id: self.leader(e, looks[e.id], epbs) for e in epbs}
        want = {e.id: min(epb_speed(e.track, e.s, params) * dt, desire[e.id]) for e in epbs}
        # Anschieben freier EPBs (auch über mehrere Fahrzeuge hinweg). Schieben dürfen nur beauftragte EPBs,
        # EPBs, die eine Weiche räumen, und selbst angeschobene; freie EPBs auf dem Weg zu ihrem Wartepunkt
        # stellen sich dagegen hinten an.
        pushers = {e.id for e in epbs if e.state != EpbState.IDLE or e.held}
        for _ in range(len(epbs)):
            changed = False
            for e in sorted(epbs, key=lambda v: v.id):
                if want[e.id] <= 0 or e.id not in pushers:
                    continue
                g, u = lead[e.id]
                if u is None or u.state != EpbState.IDLE:
                    continue
                need = want[e.id] - (g - min_d)
                if need > want[u.id] + 1e-12:
                    want[u.id] = need
                    pushers.add(u.id)
                    changed = True
            if not changed:
                break
        # Reihenfolge: Vorausfahrende zuerst; Kreise werden bei der größten Lücke aufgetrennt
        done: set[str] = set()
        busy: set[str] = set()

        def step_one(e: Epb) -> None:
            e.moved = 0.0
            w = want[e.id]
            if w <= 1e-12:
                return
            look = self.look(e, horizon)
            g, _ = self.leader(e, look, epbs)
            step = min(epb_speed(e.track, e.s, params) * dt, w, g - min_d)
            if step <= 1e-12:
                return
            for tid, off in look[1:]:
                if off - clear >= step:
                    break
                sw = self.tracks[tid].switch_id
                if sw is None or sw in e.held:
                    continue
                if self.holder.get(sw) is None:
                    self.holder[sw] = e
                    e.held[sw] = None
                    continue
                step = min(step, max(0.0, off - clear))
                break
            if step <= 1e-12:
                return
            e.moved = self.advance(e, step)

        def process(e: Epb) -> None:
            if e.id in done or e.id in busy:
                return
            busy.add(e.id)
            u = lead[e.id][1]
            if u is not None and u.id in by_id:
                process(u)
            step_one(e)
            done.add(e.id)

        for e in sorted(epbs, key=lambda v: (-lead[v.id][0], v.id)):
            u = lead[e.id][1]
            if u is not None and u.id not in done:
                process(u)
            process(e)

    # ------------------------------------------------------------------ Takt
    def update(self, dt: float) -> None:
        eng = self.eng
        mf = eng.flow
        for nid, epbs in eng.epbs_by_net.items():
            # ---- Zustandslogik
            for e in epbs:
                req = e.request
                if e.state == EpbState.MOVING_TO_PICKUP and req is not None:
                    if self.dist_to(e, req.pick) < ARRIVE:
                        e.track, e.s = self.tracks[req.pick[0]], req.pick[1]
                        e.state = EpbState.WAITING_FOR_CONTAINER
                if e.state == EpbState.WAITING_FOR_CONTAINER and e.request is not None:
                    queue = mf.waiting_at_pick.get(e.request.leg.pick_rail, [])
                    if queue:
                        c = queue[0]
                        if eng.dispatcher.by_container.get(c.id) is not e.request:
                            eng.dispatcher.swap_for_container(e, c)
                        if e.request is not None and e.request.container is c:
                            queue.pop(0)
                            e.state = EpbState.LOADING
                            x, y, _ = e.track.pos(e.s)
                            c.set_state(CState.TRANSFER_TO_EPB, eng.time)
                            mf.start_transfer(c, "to_epb", (x, y), float(e.track.level), "epb_transfer_speed")
                            c.transfer.vehicle = e
                if e.state == EpbState.TRANSPORTING and e.request is not None:
                    if self.dist_to(e, e.request.drop) < ARRIVE:
                        e.track, e.s = self.tracks[e.request.drop[0]], e.request.drop[1]
                        e.state = EpbState.UNLOADING
                if e.state == EpbState.UNLOADING and e.container is not None and e.container.transfer is None:
                    c = e.container
                    to_cell = e.request.leg.to_cell
                    tx, ty, tz = mf.node_pos(to_cell)
                    if mf.reserve(c, to_cell):
                        c.set_state(CState.TRANSFER_FROM_EPB, eng.time)
                        c.pos = (e.xy[0], e.xy[1])
                        mf.start_transfer(c, "from_epb", (tx, ty), tz, "epb_transfer_speed")
                        c.transfer.vehicle = e
                        e.container = None
            # ---- Bewegung
            self.update_parking(epbs)
            desire: dict[str, float] = {}
            for e in epbs:
                if e.state == EpbState.IDLE:
                    d = self.release_remaining(e)
                    if e.park is not None:
                        dp = self._park_dist(e, e.park)
                        if dp != INF and dp >= d:
                            d = dp
                else:
                    d = self.dist_to(e, e.target())
                desire[e.id] = 0.0 if d == INF else d
            self.move_net(epbs, dt, desire)
            # ---- Statistik + Position mitgeführter Behälter
            for e in epbs:
                if e.moved > 0 and e.state != EpbState.IDLE:
                    e.stats.t_moving += dt
                elif e.state != EpbState.IDLE:
                    e.stats.t_waiting += dt
                else:
                    e.stats.t_idle += dt
                if e.container is not None and e.container.carrier is e:
                    x, y, _ = e.track.pos(e.s)
                    e.container.pos = (x, y)
                    e.container.z = float(e.track.level)


__all__ = ["EpbControl", "epb_speed", "center"]
