"""RBG-Ablauf: Einlagerung (Aufnahme vom Förderer, zufällige Lagerplatzwahl, seitliches Einschieben)
und Auslagerung (Behälter aus dem Lagerplatz holen und an einer RBG-Abgabe auf den Förderer geben).

Einlagerung:
  MOVING_TO_PICKUP → LOADING (Ausleger fährt aus, Behälter wird aufgenommen)
  → Lagerplatz zufällig wählen → MOVING_TO_STORAGE → STORING (Einschieben mit
  Einlagerungsgeschwindigkeit, Ausleger zurück) → IDLE
Auslagerung:
  MOVING_TO_RETRIEVE → RETRIEVING (Ausleger fährt in den Lagerplatz, Behälter wird mit
  Auslagerungsgeschwindigkeit übernommen) → MOVING_TO_DROP → DROPPING (Übergabe auf den Förderer) → IDLE
Einlagerungen haben Vorrang. Eine Auslagerung beginnt nur, wenn die Abgabezelle frei ist; sie wird
dann für den Behälter reserviert. So kann ein RBG nie mit einem Behälter blockiert stehen bleiben.
Ist kein Auftrag da, aber ein Behälter unterwegs zu diesem RBG, fährt das RBG vorausschauend
zum Aufnahmepunkt (WAITING_FOR_CONTAINER).

Mehrere Ebenen: Liegen RBG-Schienen übereinander, bedient ein RBG alle diese Ebenen. Fahrt (Achse) und
Hub (Ebenenabstand) laufen gleichzeitig mit derselben Geschwindigkeit; die Fahrzeit ist das Maximum
aus beiden Wegen.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from matflow.core.geometry import center, dir_between
from matflow.sim.entities import OUT, CState, Container, Rbg, RbgState, StoragePlace
from matflow.sim.routing import RbgLeg

if TYPE_CHECKING:
    from matflow.sim.engine import Engine

ARM_REACH = 1.0   # m, Mittelpunkt RBG → Mittelpunkt Nachbarzelle
FREE_STATES = (RbgState.IDLE, RbgState.WAITING_FOR_CONTAINER, RbgState.MOVING_TO_PICKUP)


class RbgControl:
    def __init__(self, eng: "Engine"):
        self.eng = eng
        self.queue: dict[int, list[tuple[Container, RbgLeg]]] = {}
        self.announced: dict[int, list[tuple[Container, RbgLeg]]] = {}
        self.retrieve_orders: dict[int, list[StoragePlace]] = {}

    def announce(self, c: Container, leg: RbgLeg) -> None:
        self.announced.setdefault(leg.system_id, []).append((c, leg))

    def enqueue(self, c: Container, leg: RbgLeg) -> None:
        self.queue.setdefault(leg.system_id, []).append((c, leg))
        lst = self.announced.get(leg.system_id, [])
        self.announced[leg.system_id] = [(cc, lg) for cc, lg in lst if cc is not c]

    def order_retrieval(self, sp: StoragePlace) -> None:
        sp.retrieving = True
        self.retrieve_orders.setdefault(sp.info.system_id, []).append(sp)

    def open_retrievals(self) -> int:
        return sum(len(v) for v in self.retrieve_orders.values())

    # ------------------------------------------------------------------ Lagerwahl
    def choose_storage(self, sid: int) -> StoragePlace | None:
        free = sorted((sp for sp in self.eng.storages.values()
                       if sp.info.system_id == sid and not sp.occupied and not sp.reserved),
                      key=lambda sp: sp.id)
        if not free:
            return None
        return self.eng.rng_storage.choice(free)

    # ------------------------------------------------------------------ Takt
    def update(self, dt: float) -> None:
        for r in self.eng.rbgs:
            r.moved = 0.0
            self._logic(r, dt)
            if r.moved > 0:
                r.stats.t_moving += dt
            elif r.state == RbgState.STORING:
                r.stats.t_storing += dt
            elif r.state in (RbgState.RETRIEVING, RbgState.DROPPING):
                r.stats.t_retrieving += dt
            elif r.state != RbgState.IDLE:
                r.stats.t_waiting += dt
            else:
                r.stats.t_idle += dt
            if r.container is not None and r.container.carrier is r:
                r.container.pos = r.xy
                r.container.z = r.z

    def _aim(self, r: Rbg, cell) -> None:
        """Fahrziel auf eine RBG-Schienenzelle setzen (Achsposition + Ebene)."""
        r.target_p = r.system.coord(cell)
        r.target_z = float(cell[2])

    def _drive(self, r: Rbg, target: float, dt: float, target_z: float | None = None) -> bool:
        """Fährt gleichzeitig entlang der Achse und in der Höhe; True wenn angekommen."""
        v = self.eng.params.rbg_travel_speed * dt
        h = max(1e-6, self.eng.params.level_height)
        tz = r.z if target_z is None else target_z
        d = target - r.p
        dz = (tz - r.z) * h                     # Hubweg in m
        step = min(abs(d), v)
        lift = min(abs(dz), v)
        r.p += step if d > 0 else -step
        r.z += (lift if dz > 0 else -lift) / h
        r.moved = max(step, lift)
        if abs(target - r.p) < 1e-7:
            r.p = target
        if abs(tz - r.z) * h < 1e-7:
            r.z = tz
        return r.p == target and r.z == tz

    def _try_retrieval(self, r: Rbg) -> bool:
        """Startet den nächsten Auslagerauftrag, wenn die Abgabezelle frei ist."""
        eng = self.eng
        sid = r.system.id
        orders = self.retrieve_orders.get(sid)
        if not orders:
            return False
        out = eng.out_routes.get(sid)
        if out is None:
            return False
        opts = eng.out_options.get(sid, []) if eng.params.random_sink else [out]

        def free(o) -> bool:
            cell = o[0].flow_cell
            x, y, z = eng.flow.node_pos(cell)
            return eng.flow.res.get(cell) is None and eng.flow.clear_at((x, y), z)

        opts = [o for o in opts if free(o)]
        if not opts:
            return False
        drop, route = opts[0] if len(opts) == 1 else eng.rng_sink.choice(opts)
        cell = drop.flow_cell
        sp = orders.pop(0)
        c = eng.container_by_id(sp.container_id)
        c.route = route.copy()
        c.kind = OUT
        c.leg_idx = 0
        eng.flow.reserve(c, cell)
        r.task_container = c
        r.storage = sp
        r.drop = drop
        self._aim(r, sp.info.rail_cell)
        r.state = RbgState.MOVING_TO_RETRIEVE
        return True

    def _logic(self, r: Rbg, dt: float) -> None:
        eng = self.eng
        sid = r.system.id
        q = self.queue.get(sid, [])
        sysm = r.system
        if r.retracting:
            speed = eng.params.rbg_store_speed if r.state == RbgState.STORING else eng.params.conveyor_speed
            r.arm = max(0.0, r.arm - speed * dt)
            if r.arm <= 1e-9:
                r.arm = 0.0
                r.retracting = False
                r.state = RbgState.IDLE
                r.storage = None
                r.drop = None
            return
        if r.state in FREE_STATES and r.task_container is None:
            if q:
                c, leg = q[0]
                r.task_container = c
                self._aim(r, leg.rail_cell)
                r.state = RbgState.MOVING_TO_PICKUP
            elif not self._try_retrieval(r):
                ann = [a for a in self.announced.get(sid, []) if a[0].state != CState.STORED]
                if ann:
                    cell = ann[0][1].rail_cell
                    if self._drive(r, sysm.coord(cell), dt, float(cell[2])):
                        r.state = RbgState.WAITING_FOR_CONTAINER
                    else:
                        r.state = RbgState.MOVING_TO_PICKUP
                else:
                    r.state = RbgState.IDLE
                return
            else:
                return
        # ---------------------------------------------------------- Einlagerung
        if r.state == RbgState.MOVING_TO_PICKUP and r.task_container is not None:
            if self._drive(r, r.target_p, dt, r.target_z):
                c = r.task_container
                leg = next(lg for cc, lg in q if cc is c)
                r.state = RbgState.LOADING
                r.arm_side = dir_between(leg.rail_cell, leg.from_cell)
            return
        if r.state == RbgState.LOADING:
            c = r.task_container
            if c.transfer is None and c.carrier is not r:
                # Ausleger ausfahren, dann Behälter aufnehmen
                r.arm = min(ARM_REACH, r.arm + eng.params.conveyor_speed * dt)
                if r.arm >= ARM_REACH - 1e-9:
                    self.queue[sid] = [(cc, lg) for cc, lg in q if cc is not c]
                    c.set_state(CState.TRANSFER_TO_RBG, eng.time)
                    eng.flow.start_transfer(c, "to_rbg", r.xy, r.z, "conveyor_speed")
                    c.transfer.vehicle = r
            elif c.transfer is not None:
                r.arm = ARM_REACH * (1.0 - c.transfer.progress / c.transfer.length)
            return
        if r.state == RbgState.MOVING_TO_STORAGE:
            if self._drive(r, r.target_p, dt, r.target_z):
                sp = r.storage
                r.state = RbgState.STORING
                r.arm_side = sp.info.side
                c = r.container
                c.set_state(CState.BEING_STORED, eng.time)
                eng.flow.start_transfer(c, "to_storage", center(sp.info.comp.cell), r.z,
                                        "rbg_store_speed", collide=False)
                c.transfer.vehicle = r
                r.container = None
            return
        if r.state == RbgState.STORING:
            self._arm_follow(r, "to_storage", outward=True)
            return
        # ---------------------------------------------------------- Auslagerung
        if r.state == RbgState.MOVING_TO_RETRIEVE:
            if self._drive(r, r.target_p, dt, r.target_z):
                r.state = RbgState.RETRIEVING
                r.arm_side = r.storage.info.side
            return
        if r.state == RbgState.RETRIEVING:
            c = r.task_container
            if c.transfer is None and c.carrier is not r:
                r.arm = min(ARM_REACH, r.arm + eng.params.rbg_retrieve_speed * dt)
                if r.arm >= ARM_REACH - 1e-9:
                    c.set_state(CState.BEING_RETRIEVED, eng.time)
                    eng.flow.start_transfer(c, "from_storage", r.xy, r.z, "rbg_retrieve_speed",
                                            collide=False)
                    c.transfer.vehicle = r
            elif c.transfer is not None:
                self._arm_follow(r, "from_storage", outward=False)
            return
        if r.state == RbgState.MOVING_TO_DROP:
            if self._drive(r, r.target_p, dt, r.target_z):
                c = r.container
                r.state = RbgState.DROPPING
                r.arm_side = dir_between(r.drop.rail_cell, r.drop.flow_cell)
                c.set_state(CState.TRANSFER_FROM_RBG, eng.time)
                x, y, z = eng.flow.node_pos(r.drop.flow_cell)
                eng.flow.start_transfer(c, "from_rbg", (x, y), z, "conveyor_speed", collide=False)
                c.transfer.vehicle = r
                r.container = None
            return
        if r.state == RbgState.DROPPING:
            self._arm_follow(r, "from_rbg", outward=True)

    def _arm_follow(self, r: Rbg, kind: str, outward: bool) -> None:
        for c in self.eng.containers:
            if c.transfer is not None and c.transfer.vehicle is r and c.transfer.kind == kind:
                f = c.transfer.progress / c.transfer.length
                r.arm = ARM_REACH * (f if outward else 1.0 - f)
                break

    # ------------------------------------------------------------------ Rückmeldungen
    def on_loaded(self, r: Rbg, c: Container) -> None:
        eng = self.eng
        c.carrier = r
        c.set_state(CState.ON_RBG, eng.time)
        r.container = c
        r.task_container = None
        r.arm = 0.0
        sp = self.choose_storage(r.system.id)
        if sp is None:        # darf durch Kapazitätsreservierung nicht passieren
            r.state = RbgState.IDLE
            c.set_state(CState.BLOCKED, eng.time)
            return
        sp.reserved = True
        c.storage_id = sp.id
        eng.inbound[r.system.id] = max(0, eng.inbound[r.system.id] - 1)
        r.storage = sp
        self._aim(r, sp.info.rail_cell)
        r.state = RbgState.MOVING_TO_STORAGE

    def on_stored(self, r: Rbg, c: Container) -> None:
        eng = self.eng
        sp = eng.storages[c.storage_id]
        sp.reserved = False
        sp.occupied = True
        sp.container_id = c.id
        c.carrier = None
        c.set_state(CState.STORED, eng.time)
        c.stored_t = eng.time
        r.retracting = True
        r.stats.jobs += 1
        eng.stats.stored += 1

    def on_retrieved(self, r: Rbg, c: Container) -> None:
        eng = self.eng
        sp = r.storage
        sp.occupied = False
        sp.prefilled = False
        sp.retrieving = False
        sp.container_id = None
        c.storage_id = None
        c.carrier = r
        c.out_t = eng.time
        c.set_state(CState.ON_RBG, eng.time)
        r.container = c
        r.task_container = None
        r.arm = 0.0
        self._aim(r, r.drop.rail_cell)
        r.state = RbgState.MOVING_TO_DROP
        eng.stats.retrieved += 1

    def on_dropped(self, r: Rbg, c: Container) -> None:
        r.stats.retrievals += 1
        r.retracting = True
        self.eng.flow.start_conveyor_leg(c, 0)
