"""EPB-Schienennetz: zerlegt verbundene Schienenzellen in Strecken und verknüpft sie zu einem Netz.

Ein Fahrweg (Link) ist ein Weg durch eine Zelle von einer Eintritts- zu einer Austrittsseite.
Gerade Schiene und Kurve haben einen Link, eine Weiche zwei (gerader Strang + 90°-Abzweig).
Eine Strecke (Track) ist eine geordnete Folge von Links ohne Verzweigung. Jeder Weichen-Link
ist eine eigene Strecke, an Weichen enden bzw. beginnen die angrenzenden Strecken.
Positionen auf einer Strecke werden als Bogenlänge s (in m) beschrieben.
Gerade = 1 m, Kurve = Viertelkreis mit r = 0,5 m (pi/4 m).

Das Netz kennt die gerichteten Verbindungen der Strecken (Nachfolger/Vorgänger) und liefert
kürzeste Fahrstrecken entlang der erlaubten Fahrtrichtung (für Dispatcher, Routing und Fahrlogik).
"""
from __future__ import annotations

import bisect
import heapq
import itertools
import math
from dataclasses import dataclass, field

from matflow.core.geometry import Cell, center, corner, edge_mid, neighbor, opposite
from matflow.model.components import EPB_RAIL_TYPES, EPB_SWITCH, Component

CURVE_LEN = math.pi / 4
INF = math.inf


@dataclass
class RailCell:
    comp: Component
    entry: int
    exit: int
    length: float
    s0: float = 0.0
    link: int = 0

    @property
    def cell(self) -> Cell:
        return self.comp.cell

    @property
    def is_curve(self) -> bool:
        return self.entry != opposite(self.exit)

    @property
    def s_center(self) -> float:
        return self.s0 + self.length / 2

    def local_pos(self, u: float) -> tuple[float, float, float]:
        """Position (x, y) und Fahrtwinkel für lokale Bogenlänge u in [0, length]."""
        cell = self.cell
        if not self.is_curve:
            p0 = edge_mid(cell, self.entry)
            p1 = edge_mid(cell, self.exit)
            f = u / self.length
            ang = math.atan2(p1[1] - p0[1], p1[0] - p0[0])
            return (p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f, ang)
        c = corner(cell, self.entry, self.exit)
        p0 = edge_mid(cell, self.entry)
        p1 = edge_mid(cell, self.exit)
        a0 = math.atan2(p0[1] - c[1], p0[0] - c[0])
        a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
        da = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi
        a = a0 + da * (u / self.length)
        x, y = c[0] + 0.5 * math.cos(a), c[1] + 0.5 * math.sin(a)
        heading = a + (math.pi / 2 if da > 0 else -math.pi / 2)
        return (x, y, heading)


def link_length(entry: int, exit_: int) -> float:
    return 1.0 if entry == opposite(exit_) else CURVE_LEN


@dataclass
class Track:
    id: int
    level: int
    cells: list[RailCell]
    closed: bool
    index: dict[Cell, int] = field(default_factory=dict)
    length: float = 0.0
    succ: list[int] = field(default_factory=list)
    pred: list[int] = field(default_factory=list)
    switch_id: str | None = None      # gesetzt, wenn die Strecke ein Weichen-Link ist
    net: int = -1
    _starts: list[float] = field(default_factory=list)

    def __post_init__(self) -> None:
        s = 0.0
        for i, rc in enumerate(self.cells):
            rc.s0 = s
            s += rc.length
            self.index[rc.cell] = i
        self.length = s
        self._starts = [rc.s0 for rc in self.cells]

    # Grenzen: ohne Anschluss halten Fahrzeuge am Mittelpunkt der ersten bzw. letzten Zelle
    @property
    def s_min(self) -> float:
        return 0.0 if (self.closed or self.pred) else self.cells[0].s_center

    @property
    def s_max(self) -> float:
        return self.length if (self.closed or self.succ) else self.cells[-1].s_center

    def normalize(self, s: float) -> float:
        if self.closed:
            return s % self.length
        return min(max(s, self.s_min), self.s_max)

    def locate(self, s: float) -> tuple[int, float]:
        s = self.normalize(s)
        i = bisect.bisect_right(self._starts, s) - 1
        i = max(0, min(i, len(self.cells) - 1))
        return i, s - self.cells[i].s0

    def pos(self, s: float) -> tuple[float, float, float]:
        i, u = self.locate(s)
        rc = self.cells[i]
        return rc.local_pos(min(max(u, 0.0), rc.length))

    def cell_at(self, s: float) -> RailCell:
        return self.cells[self.locate(s)[0]]

    def center_s(self, cell: Cell) -> float:
        return self.cells[self.index[cell]].s_center

    def dist_ahead(self, s_from: float, s_to: float) -> float:
        """Fahrstrecke auf DIESER Strecke entlang der Fahrtrichtung von s_from nach s_to."""
        if self.closed:
            d = (s_to - s_from) % self.length
            return 0.0 if d > self.length - 1e-9 else d
        d = s_to - s_from
        return d if d >= -1e-9 else INF

    def advance(self, s: float, ds: float) -> float:
        return self.normalize(s + ds)


class RailNetwork:
    """Gerichteter Graph der Strecken mit kürzesten Fahrstrecken (vorberechnet)."""

    def __init__(self, tracks: list[Track]):
        self.tracks = tracks
        n = len(tracks)
        # dist_end[a][b]: Fahrstrecke vom Ende von a bis zum Anfang von b; hop[a][b]: erster Nachfolger
        self.dist_end: list[dict[int, float]] = []
        self.hop: list[dict[int, int]] = []
        for a in range(n):
            d: dict[int, float] = {}
            first: dict[int, int] = {}
            cnt = itertools.count()
            heap = []
            for t in tracks[a].succ:
                if 0.0 < d.get(t, INF):
                    d[t] = 0.0
                    first[t] = t
                    heapq.heappush(heap, (0.0, next(cnt), t))
            while heap:
                du, _, u = heapq.heappop(heap)
                if du > d.get(u, INF):
                    continue
                for v in tracks[u].succ:
                    nd = du + tracks[u].length
                    if nd < d.get(v, INF) - 1e-12:
                        d[v] = nd
                        first[v] = first[u]
                        heapq.heappush(heap, (nd, next(cnt), v))
            self.dist_end.append(d)
            self.hop.append(first)
        # Standard-Nachfolger für freie Fahrzeuge: bevorzugt nicht in eine Sackgasse, sonst gerade
        dead = {t.id for t in tracks if not t.succ and not t.closed}
        changed = True
        while changed:
            changed = False
            for t in tracks:
                if t.id not in dead and t.succ and all(s in dead for s in t.succ):
                    dead.add(t.id)
                    changed = True
        self.dead_end = dead
        self.default: dict[int, int] = {}
        for t in tracks:
            if not t.succ:
                continue
            opts = sorted(t.succ, key=lambda s: (s in dead, tracks[s].cells[0].link, s))
            self.default[t.id] = opts[0]

    def path_dist(self, ta: int, sa: float, tb: int, sb: float) -> float:
        """Kürzeste Fahrstrecke entlang der erlaubten Fahrtrichtung von (ta, sa) nach (tb, sb)."""
        a = self.tracks[ta]
        if a.closed:
            return a.dist_ahead(sa, sb) if ta == tb else INF
        best = INF
        if ta == tb and sb >= sa - 1e-9:
            best = max(0.0, sb - sa)
        via = self.dist_end[ta].get(tb)
        if via is not None:
            best = min(best, a.length - sa + via + sb)
        return best

    def next_toward(self, cur: int, target: int | None) -> int | None:
        """Nächste Strecke nach cur auf dem kürzesten Weg zu target (None = Standardweg)."""
        if target is not None:
            h = self.hop[cur].get(target)
            if h is not None:
                return h
        return self.default.get(cur)


def build_tracks(rails: dict[Cell, Component]) -> tuple[list[Track], list[tuple[str, list[Cell]]]]:
    """Zerlegt Schienenzellen in Strecken und verknüpft sie. Liefert (Strecken, Fehler)."""
    errors: list[tuple[str, list[Cell]]] = []
    links: dict[tuple[Cell, int], tuple[int, int]] = {}
    for c, comp in rails.items():
        for k, (en, ex) in enumerate(comp.rail_links()):
            links[(c, k)] = (en, ex)
    succ: dict[tuple[Cell, int], list[tuple[Cell, int]]] = {lk: [] for lk in links}
    preds: dict[tuple[Cell, int], list[tuple[Cell, int]]] = {lk: [] for lk in links}
    reported: set[tuple[Cell, Cell]] = set()
    for (c, k), (_en, ex) in links.items():
        n = neighbor(c, ex)
        if n not in rails:
            continue
        hits = [(n, j) for j, (nen, _) in enumerate(rails[n].rail_links()) if nen == opposite(ex)]
        if hits:
            for h in hits:
                succ[(c, k)].append(h)
                preds[h].append((c, k))
        elif (c, n) not in reported:
            reported.add((c, n))
            errors.append((f"{rails[c].id} führt in {rails[n].id}, aber die Fahrtrichtungen passen nicht zusammen",
                           [c, n]))

    def is_switch(c: Cell) -> bool:
        return rails[c].type == EPB_SWITCH

    def chain_next(lk: tuple[Cell, int]) -> tuple[Cell, int] | None:
        """Nachfolger innerhalb derselben Strecke (keine Weiche beteiligt)."""
        if is_switch(lk[0]) or len(succ[lk]) != 1:
            return None
        nx = succ[lk][0]
        if is_switch(nx[0]) or len(preds[nx]) != 1:
            return None
        return nx

    has_chain_pred: set[tuple[Cell, int]] = set()
    for lk in links:
        nx = chain_next(lk)
        if nx is not None:
            has_chain_pred.add(nx)

    tracks: list[Track] = []
    track_of: dict[tuple[Cell, int], int] = {}
    visited: set[tuple[Cell, int]] = set()

    def mk(seq: list[tuple[Cell, int]], closed: bool) -> None:
        cells = []
        for (c, k) in seq:
            en, ex = links[(c, k)]
            cells.append(RailCell(rails[c], en, ex, link_length(en, ex), link=k))
        tr = Track(len(tracks), seq[0][0][2], cells, closed)
        if is_switch(seq[0][0]):
            tr.switch_id = rails[seq[0][0]].id
        for lk in seq:
            track_of[lk] = tr.id
        tracks.append(tr)

    order = sorted(links, key=lambda lk: (lk[0][2], lk[0][1], lk[0][0], lk[1]))
    for lk in order:
        if lk in has_chain_pred or lk in visited:
            continue
        seq = []
        cur: tuple[Cell, int] | None = lk
        while cur is not None and cur not in visited:
            visited.add(cur)
            seq.append(cur)
            cur = chain_next(cur)
        mk(seq, False)
    for lk in order:                       # übrige: geschlossene Ringe ohne Weiche
        if lk in visited:
            continue
        seq = []
        cur = lk
        while cur is not None and cur not in visited:
            visited.add(cur)
            seq.append(cur)
            cur = chain_next(cur)
        mk(seq, cur == lk)

    for tr in tracks:
        if tr.closed:
            continue
        first = (tr.cells[0].cell, tr.cells[0].link)
        last = (tr.cells[-1].cell, tr.cells[-1].link)
        tr.succ = sorted({track_of[s] for s in succ[last]})
        tr.pred = sorted({track_of[p] for p in preds[first]})
    # Netze (zusammenhängende Teilsysteme)
    parent = list(range(len(tracks)))

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for tr in tracks:
        for s in tr.succ:
            parent[find(tr.id)] = find(s)
    roots: dict[int, int] = {}
    for tr in tracks:
        r = find(tr.id)
        if r not in roots:
            roots[r] = len(roots)
        tr.net = roots[r]
    return tracks, errors


def is_rail(comp: Component | None) -> bool:
    return comp is not None and comp.type in EPB_RAIL_TYPES


__all__ = ["Track", "RailCell", "RailNetwork", "build_tracks", "is_rail", "center", "CURVE_LEN"]
