"""Simulationsengine: fester Zeitschritt, Behältererzeugung, Koordination aller Teilsysteme.

Die Engine arbeitet auf einer Kopie des Layouts. Ein Reset baut die Engine einfach neu auf:
vom Benutzer vorbelegte Lagerplätze bleiben belegt, während der Simulation belegte werden geleert.
"""
from __future__ import annotations

import random
import time as _time
from collections import deque

from matflow.core.geometry import center
from matflow.model.components import NIO, SINK, SOURCE
from matflow.model.layout import Layout
from matflow.model.params import SimParams
from matflow.sim.dispatcher import Dispatcher
from matflow.sim.entities import IO, NIO_KIND, CState, Container, Epb, EpbState, Rbg, StoragePlace
from matflow.sim.epb_control import EpbControl
from matflow.sim.material_flow import MaterialFlow
from matflow.sim.rbg_control import RbgControl
from matflow.sim.routing import EpbLeg, ExitLeg, RbgLeg, Route, Router
from matflow.sim.statistics import Stats
from matflow.sim.validation import ValidationResult, validate

DT = 0.02          # s, interner Zeitschritt
STALL_LIMIT = 600  # s Simulationszeit ohne Bewegung → Stillstandswarnung


class SimulationError(Exception):
    pass


class Engine:
    def __init__(self, layout: Layout, params: SimParams | None = None):
        self.layout = layout.clone()
        self.params = params if params is not None else self.layout.params.copy()
        self.validation: ValidationResult = validate(self.layout)
        if not self.validation.ok:
            raise SimulationError("\n".join(i.msg for i in self.validation.errors))
        self.topo = self.validation.topo
        self.router = Router(self.topo, self.params)

        seed = self.params.random_seed if self.params.use_seed else int(_time.time() * 1000) & 0x7FFFFFFF
        self.seed = seed
        master = random.Random(seed)
        self.rng_arrival = random.Random(master.getrandbits(32))
        self.rng_source = random.Random(master.getrandbits(32))
        self.rng_storage = random.Random(master.getrandbits(32))
        self.rng_nio = random.Random(master.getrandbits(32))
        self.rng_retrieve = random.Random(master.getrandbits(32))
        self.rng_retrieve_arrival = random.Random(master.getrandbits(32))
        self.rng_target = random.Random(master.getrandbits(32))     # Ziel-RBG der Einlagerung
        self.rng_sink = random.Random(master.getrandbits(32))       # Ausgang der Auslagerung

        self.time = 0.0
        self.ended = False
        self.end_reason = ""
        self.stalled = False
        self._last_motion = 0.0
        self._acc = 0.0
        self.stats = Stats()
        # abgeschlossene Übergaben (Position, Fahrzeug) nur für die Darstellung; begrenzt, beeinflusst nichts
        self.fx: deque = deque(maxlen=64)
        self.containers: list[Container] = []
        self._cnt = 0

        self.flow = MaterialFlow(self)
        self.dispatcher = Dispatcher(self)
        self.epb_ctrl = EpbControl(self)
        self.rbg = RbgControl(self)

        # Lager
        self.storages: dict[str, StoragePlace] = {}
        for sid, info in sorted(self.topo.storages.items()):
            sp = StoragePlace(info)
            if info.comp.prefilled:
                sp.occupied = sp.prefilled = True
                self._cnt += 1
                c = Container(f"V_{self._cnt:04d}", "", 0.0, state=CState.STORED, prefilled=True,
                              pos=center(info.comp.cell), z=float(info.comp.level), storage_id=sid)
                sp.container_id = c.id
                self.containers.append(c)
            self.storages[sid] = sp
        self.inbound: dict[int, int] = {s.id: 0 for s in self.topo.rbg_systems}

        # Fahrzeuge
        self.epbs: list[Epb] = []
        self.epbs_by_net: dict[int, list[Epb]] = {}
        for nid, comps in sorted(self.topo.net_epbs.items()):
            lst = []
            for v in sorted(comps, key=lambda v: v.id):
                tid, s = self.topo.rail_point(v.cell)
                lst.append(Epb(v.id, v.display_name, self.topo.tracks[tid], s, nid))
            self.epbs_by_net[nid] = lst
            self.epbs.extend(lst)
        self.epbs.sort(key=lambda e: e.id)
        self.epb_ctrl.init_holds()
        self.rbgs: list[Rbg] = []
        for sysm in self.topo.rbg_systems:
            if sysm.vehicles:
                v = sysm.vehicles[0]
                self.rbgs.append(Rbg(v.id, v.display_name, sysm, sysm.coord(v.cell), z=float(v.level)))

        # Quellen
        self.sources = [s for s in self.layout.components(SOURCE) if s.cell in self.topo.flow]
        self.backlog: dict[str, list[Container]] = {s.id: [] for s in self.sources}
        self._nio_routes: dict[str, Route | None] = {
            s.id: self.router.find_exit(s.cell, NIO) for s in self.sources}
        # Einlagerung: welche RBG-Systeme sind von welcher Quelle erreichbar
        self.src_systems: dict[str, set[int]] = {
            s.id: {sid for sid in self.router.reachable_systems(s.cell) if self.topo.rbg_systems[sid].storages}
            for s in self.sources}
        # Auslagerung: je RBG-System der kürzeste Weg von einer RBG-Abgabe zu einem Ausgang (out_routes)
        # sowie je erreichbarem Ausgang der beste Weg (out_options, für die zufällige Ausgangswahl)
        self.out_routes = {}
        self.out_options: dict[int, list] = {}
        for sysm in self.topo.rbg_systems:
            best = None
            per_exit: dict = {}
            for h in sysm.drops:
                r = self.router.find_exit(h.flow_cell, SINK)
                if r is not None and (best is None or r.cost < best[1].cost - 1e-12):
                    best = (h, r)
                for cell in self.router.reachable_exits(h.flow_cell, SINK):
                    rr = self.router.find_exit_cell(h.flow_cell, cell)
                    if rr is not None and (cell not in per_exit or rr.cost < per_exit[cell][1].cost - 1e-12):
                        per_exit[cell] = (h, rr)
            if best is not None:
                self.out_routes[sysm.id] = best
                self.out_options[sysm.id] = [per_exit[k] for k in sorted(per_exit)]
        self.retrieval_active = self.params.retrieval_rate > 0 and bool(self.out_routes)
        self.next_arrival = self._interarrival(self.params.container_rate, self.rng_arrival)
        self.next_retrieval = (self._interarrival(self.params.retrieval_rate, self.rng_retrieve_arrival)
                               if self.retrieval_active else float("inf"))
        self.end_time = self.params.sim_duration * 60.0 if self.params.sim_duration > 0 else float("inf")
        self._check_end()

    # ------------------------------------------------------------------ Kapazität
    def capacity(self, sid: int) -> int:
        free = sum(1 for sp in self.storages.values()
                   if sp.info.system_id == sid and not sp.occupied and not sp.reserved)
        return free - self.inbound.get(sid, 0)

    def route_for(self, source_cell) -> Route | None:
        return self.router.find(source_cell, lambda sid: self.capacity(sid) > 0)

    def _random_target_routes(self) -> list:
        """Zufälliges Ziel-RBG (gewichtet nach freier Kapazität, d. h. jeder freie Lagerplatz ist gleich
        wahrscheinlich) und alle Quellen, die dieses RBG erreichen, mit ihrem Weg dorthin."""
        free = {}
        for sid in sorted(set().union(*self.src_systems.values()) if self.src_systems else set()):
            cap = self.capacity(sid)
            if cap > 0:
                free[sid] = cap
        if not free:
            return []
        opts = sorted(free)
        sid = opts[0] if len(opts) == 1 else self.rng_target.choices(opts, weights=[free[k] for k in opts])[0]
        cands = []
        for s in self.sources:
            if sid in self.src_systems[s.id]:
                r = self.router.find(s.cell, lambda x, t=sid: x == t)
                if r is not None:
                    cands.append((s, r))
        return cands

    def container_by_id(self, cid: str) -> Container:
        return next(c for c in self.containers if c.id == cid)

    # ------------------------------------------------------------------ Erzeugung
    def _interarrival(self, rate_per_min: float, rng: random.Random) -> float:
        if rate_per_min <= 0:
            return float("inf")
        return self.time + rng.expovariate(rate_per_min / 60.0)

    def _arrival(self) -> None:
        nio = False
        if self.params.nio_rate > 0:
            nio = self.rng_nio.random() * 100.0 < self.params.nio_rate
        cands = []
        if nio:
            cands = [(s, self._nio_routes[s.id].copy()) for s in self.sources if self._nio_routes[s.id] is not None]
            if not cands:
                nio = False
        if not nio:
            if self.params.random_rbg:
                cands = self._random_target_routes()
            else:
                for s in self.sources:
                    r = self.route_for(s.cell)
                    if r is not None:
                        cands.append((s, r))
        if not cands:
            self.stats.rejected += 1
            return
        src, route = self.rng_source.choice(cands)
        self._cnt += 1
        c = Container(f"B_{self._cnt:04d}", src.id, self.time, route=route, kind=NIO_KIND if nio else IO)
        c.nodes = route.legs[0].nodes
        c.state_since = self.time
        self.containers.append(c)
        self.stats.created += 1
        if nio:
            self.stats.nio_created += 1
        else:
            self.inbound[route.system_id] += 1
        self.backlog[src.id].append(c)
        if len(route.legs) > 1 and isinstance(route.legs[1], EpbLeg):
            self.dispatcher.request(c, route.legs[1])       # vorausschauend: EPB fährt schon los
        for leg in route.legs:
            if isinstance(leg, RbgLeg):
                self.rbg.announce(c, leg)

    def _retrieval_order(self) -> None:
        cands = sorted((sp for sp in self.storages.values()
                        if sp.occupied and not sp.retrieving and sp.info.system_id in self.out_routes),
                       key=lambda sp: sp.id)
        if not cands:
            self.stats.retrieve_rejected += 1
            return
        sp = self.rng_retrieve.choice(cands)
        self.rbg.order_retrieval(sp)
        self.stats.retrieve_orders += 1

    def on_exit(self, c: Container, leg: ExitLeg) -> None:
        """Behälter erreicht einen Ausgang bzw. NIO-Ausgang und verlässt die Anlage."""
        self.flow.release_all(c)
        c.set_state(CState.LEFT, self.time)
        c.pos = None
        c.carrier = None
        if c in self.containers:
            self.containers.remove(c)
        if leg.kind == NIO:
            self.stats.nio_out += 1
        else:
            self.stats.out_done += 1
            if c.out_t is not None:
                self.stats.out_lead.append(self.time - c.out_t)

    def _spawn(self) -> None:
        for s in self.sources:
            q = self.backlog[s.id]
            if not q:
                continue
            c = q[0]
            x, y, z = self.flow.node_pos(s.cell)
            if self.flow.res.get(s.cell) is not None or not self.flow.clear_at((x, y), z):
                continue
            q.pop(0)
            self.flow.reserve(c, s.cell)
            self.flow.start_conveyor_leg(c, 0)

    # ------------------------------------------------------------------ Rückmeldungen
    def on_transfer_done(self, c: Container, kind: str, veh) -> None:
        if c.pos is not None and veh is not None:
            self.fx.append((c.pos, veh))
        if kind == "to_epb":
            e: Epb = veh
            c.carrier = e
            e.container = c
            c.set_state(CState.ON_EPB, self.time)
            e.state = EpbState.TRANSPORTING
        elif kind == "from_epb":
            e = veh
            req = e.request
            e.request = None
            e.state = EpbState.IDLE
            e.stats.jobs += 1
            if req is not None:
                self.dispatcher.finish(req)
            self.flow.start_conveyor_leg(c, c.leg_idx + 2)
        elif kind == "to_rbg":
            c.leg_idx = len(c.route.legs) - 1
            self.rbg.on_loaded(veh, c)
        elif kind == "to_storage":
            self.rbg.on_stored(veh, c)
        elif kind == "from_storage":
            self.rbg.on_retrieved(veh, c)
        elif kind == "from_rbg":
            self.rbg.on_dropped(veh, c)

    # ------------------------------------------------------------------ Takt
    def step(self, dt: float = DT) -> None:
        if self.ended:
            return
        self.time += dt
        while self.next_arrival <= self.time and not self.ended:
            self._arrival()
            self.next_arrival = self._interarrival(self.params.container_rate, self.rng_arrival)
        while self.next_retrieval <= self.time and not self.ended:
            self._retrieval_order()
            self.next_retrieval = self._interarrival(self.params.retrieval_rate, self.rng_retrieve_arrival)
        self._spawn()
        self.dispatcher.update()
        self.flow.update(dt)
        self.epb_ctrl.update(dt)
        self.rbg.update(dt)
        self._watchdog()
        self._check_end()

    def advance(self, sim_seconds: float, max_steps: int = 2000) -> None:
        """Simulationszeit voranschreiten lassen (vom UI pro Frame aufgerufen)."""
        self._acc += sim_seconds
        n = 0
        while self._acc >= DT and n < max_steps and not self.ended:
            self.step(DT)
            self._acc -= DT
            n += 1
        if n >= max_steps:
            self._acc = 0.0

    def run_until(self, t: float) -> None:
        while self.time < t - 1e-9 and not self.ended:
            self.step(DT)

    def _watchdog(self) -> None:
        moving = any(e.moved > 0 for e in self.epbs) or any(r.moved > 0 for r in self.rbgs) or any(
            c.state in (CState.ON_CONVEYOR, CState.ON_LIFT) or c.transfer is not None
            for c in self.containers if c.state != CState.STORED)
        in_transit = any(c.state != CState.STORED for c in self.containers)
        if moving or not in_transit:
            self._last_motion = self.time
            self.stalled = False
        elif self.time - self._last_motion > STALL_LIMIT:
            self.stalled = True

    def _check_end(self) -> None:
        if self.ended:
            return
        if self.time >= self.end_time - 1e-9:
            self._end("SIMULATIONSDAUER ERREICHT")
            return
        if self.retrieval_active:
            return                  # mit Auslagerung läuft die Anlage im Dauerbetrieb weiter
        free = sum(1 for sp in self.storages.values() if not sp.occupied)
        if free == 0:
            self._end("LAGER VOLL")
            return
        in_transit = any(c.state != CState.STORED for c in self.containers)
        if not in_transit and all(self.route_for(s.cell) is None for s in self.sources):
            self._end("LAGER VOLL (alle erreichbaren Lagerplätze belegt)")

    def _end(self, reason: str) -> None:
        self.ended = True
        self.end_reason = reason
        if self.stats.time_full is None and "LAGER VOLL" in reason:
            self.stats.time_full = self.time

    def stop(self) -> None:
        """Simulation durch den Benutzer beenden (Zustand bleibt sichtbar)."""
        if not self.ended:
            self.ended = True
            self.end_reason = "DURCH BENUTZER BEENDET"

    # ------------------------------------------------------------------ Abfragen
    def free_storages(self) -> int:
        return sum(1 for sp in self.storages.values() if not sp.occupied)
