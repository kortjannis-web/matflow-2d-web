"""Laufzeitobjekte der Simulation: Behälter, EPB, RBG, Lagerplatz."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

from matflow.core.geometry import Cell

if TYPE_CHECKING:
    from matflow.sim.routing import EpbLeg, Route
    from matflow.sim.topology import Handover, RbgSystem, StorageInfo
    from matflow.sim.tracks import Track


class CState(str, Enum):
    CREATED = "CREATED"
    ON_CONVEYOR = "ON_CONVEYOR"
    ON_LIFT = "ON_LIFT"
    WAITING_FOR_EPB = "WAITING_FOR_EPB"
    TRANSFER_TO_EPB = "TRANSFER_TO_EPB"
    ON_EPB = "ON_EPB"
    TRANSFER_FROM_EPB = "TRANSFER_FROM_EPB"
    WAITING_FOR_RBG = "WAITING_FOR_RBG"
    TRANSFER_TO_RBG = "TRANSFER_TO_RBG"
    ON_RBG = "ON_RBG"
    BEING_STORED = "BEING_STORED"
    STORED = "STORED"
    BEING_RETRIEVED = "BEING_RETRIEVED"
    TRANSFER_FROM_RBG = "TRANSFER_FROM_RBG"
    LEFT = "LEFT"
    BLOCKED = "BLOCKED"


# Behälterart: IO = normale Einlagerung, NIO = fehlerhaft (zum NIO-Ausgang), OUT = ausgelagert (zum Ausgang)
IO, NIO_KIND, OUT = "IO", "NIO", "OUT"
KIND_LABELS = {IO: "Einlagerung", NIO_KIND: "NIO (Fehlerausgang)", OUT: "Auslagerung"}


C_LABELS = {
    CState.CREATED: "erzeugt, wartet an Quelle",
    CState.ON_CONVEYOR: "auf Fördertechnik",
    CState.ON_LIFT: "im Heber",
    CState.WAITING_FOR_EPB: "wartet auf EPB",
    CState.TRANSFER_TO_EPB: "Übergabe auf EPB",
    CState.ON_EPB: "auf EPB",
    CState.TRANSFER_FROM_EPB: "Übergabe von EPB",
    CState.WAITING_FOR_RBG: "wartet auf RBG",
    CState.TRANSFER_TO_RBG: "Übergabe auf RBG",
    CState.ON_RBG: "auf RBG",
    CState.BEING_STORED: "wird eingelagert",
    CState.STORED: "eingelagert",
    CState.BEING_RETRIEVED: "wird ausgelagert",
    CState.TRANSFER_FROM_RBG: "Übergabe vom RBG",
    CState.LEFT: "hat die Anlage verlassen",
    CState.BLOCKED: "blockiert (kein Weiterweg)",
}
WAITING_STATES = {CState.CREATED, CState.WAITING_FOR_EPB, CState.WAITING_FOR_RBG, CState.BLOCKED}


class EpbState(str, Enum):
    IDLE = "IDLE"
    MOVING_TO_PICKUP = "MOVING_TO_PICKUP"
    WAITING_FOR_CONTAINER = "WAITING_FOR_CONTAINER"
    LOADING = "LOADING"
    TRANSPORTING = "TRANSPORTING"
    UNLOADING = "UNLOADING"


class RbgState(str, Enum):
    IDLE = "IDLE"
    MOVING_TO_PICKUP = "MOVING_TO_PICKUP"
    WAITING_FOR_CONTAINER = "WAITING_FOR_CONTAINER"
    LOADING = "LOADING"
    MOVING_TO_STORAGE = "MOVING_TO_STORAGE"
    STORING = "STORING"
    MOVING_TO_RETRIEVE = "MOVING_TO_RETRIEVE"
    RETRIEVING = "RETRIEVING"
    MOVING_TO_DROP = "MOVING_TO_DROP"
    DROPPING = "DROPPING"


@dataclass
class Transfer:
    """Geradlinige Übergabebewegung eines Behälters (seitlich, in m)."""
    kind: str                        # to_epb | from_epb | to_rbg | to_storage | from_storage | from_rbg
    p0: tuple[float, float]
    p1: tuple[float, float]
    z0: float
    z1: float
    speed_attr: str                  # Name des Geschwindigkeitsparameters
    length: float
    progress: float = 0.0
    collide: bool = True             # Abstandsprüfung zu anderen Behältern
    vehicle: Any = None              # beteiligtes Fahrzeug (EPB/RBG)


@dataclass
class Container:
    id: str
    source_id: str
    created_t: float
    route: "Route | None" = None
    kind: str = IO
    leg_idx: int = 0
    state: CState = CState.CREATED
    # Förderbewegung
    nodes: list[Cell] = field(default_factory=list)
    seg: int = 0
    t: float = 0.0
    holds: set[Cell] = field(default_factory=set)
    # Darstellung / Position
    pos: tuple[float, float] | None = None
    z: float = 0.0
    carrier: Any = None
    transfer: Transfer | None = None
    # Lager
    storage_id: str | None = None
    stored_t: float | None = None
    prefilled: bool = False
    state_since: float = 0.0
    out_t: float | None = None           # Zeitpunkt der Auslagerung (verlässt den Lagerplatz)

    def set_state(self, s: CState, now: float) -> None:
        if s != self.state:
            self.state = s
            self.state_since = now

    @property
    def active_on_floor(self) -> bool:
        """Befindet sich auf Fördertechnik oder in einer Übergabe (für Abstandsprüfung)."""
        return self.pos is not None and self.carrier is None and self.state != CState.STORED


@dataclass
class EpbRequest:
    container: Container
    leg: "EpbLeg"
    pick: tuple[int, float]          # (Strecke, s)
    drop: tuple[int, float]
    created_t: float
    epb: "Epb | None" = None


@dataclass
class VehicleStats:
    t_moving: float = 0.0
    t_waiting: float = 0.0           # beschäftigt, aber stehend
    t_idle: float = 0.0
    t_storing: float = 0.0
    t_retrieving: float = 0.0
    jobs: int = 0
    retrievals: int = 0

    @property
    def busy(self) -> float:
        return self.t_moving + self.t_waiting + self.t_storing + self.t_retrieving


@dataclass
class Epb:
    id: str
    label: str
    track: "Track"
    s: float
    net: int = 0
    state: EpbState = EpbState.IDLE
    request: EpbRequest | None = None
    container: Container | None = None
    stats: VehicleStats = field(default_factory=VehicleStats)
    moved: float = 0.0
    # reservierte Weichen: Weichen-ID → zurückgelegter Weg seit Verlassen (None = noch in der Weiche)
    held: dict[str, float | None] = field(default_factory=dict)
    park: tuple[int, float] | None = None    # freie EPB: Warteposition am nächsten Aufnahmepunkt

    def target(self) -> tuple[int, float] | None:
        """Fahrziel (Strecke, s) je Zustand."""
        r = self.request
        if r is None:
            return self.park if self.state == EpbState.IDLE else None
        if self.state == EpbState.MOVING_TO_PICKUP:
            return r.pick
        if self.state == EpbState.TRANSPORTING:
            return r.drop
        return None

    @property
    def xy(self) -> tuple[float, float, float]:
        return self.track.pos(self.s)


@dataclass
class StoragePlace:
    info: "StorageInfo"
    occupied: bool = False
    reserved: bool = False
    prefilled: bool = False
    retrieving: bool = False             # Auslagerauftrag vorhanden
    container_id: str | None = None

    @property
    def id(self) -> str:
        return self.info.comp.id


@dataclass
class Rbg:
    id: str
    label: str
    system: "RbgSystem"
    p: float                         # Position auf der Achse (Weltkoordinate in m)
    z: float = 0.0                   # Höhe des Hubwagens als Ebene (Gleitkomma, Ebenenabstand s. Parameter)
    state: RbgState = RbgState.IDLE
    container: Container | None = None
    task_container: Container | None = None
    target_p: float | None = None
    target_z: float | None = None
    storage: StoragePlace | None = None
    arm: float = 0.0                 # Auslegerausfahrt 0..1 (m)
    arm_side: int = 0
    retracting: bool = False
    drop: "Handover | None" = None       # Auslagerung: Abgabepunkt
    stats: VehicleStats = field(default_factory=VehicleStats)
    moved: float = 0.0

    @property
    def xy(self) -> tuple[float, float]:
        return self.system.point(self.p)

    @property
    def level(self) -> int:
        """Ebene, auf der sich der Hubwagen gerade befindet."""
        return int(round(self.z))
