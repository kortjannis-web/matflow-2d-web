"""Topologie: leitet aus dem Layout alle Verbindungen, Übergabepunkte und Teilsysteme ab.

Die Topologie ist rein aus der Geometrie berechnet. Nichts davon ist fest codiert.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from matflow.core.geometry import (
    Cell, DVEC, center, dir_between, is_perpendicular, neighbor, opposite,
)
from matflow.model.components import (
    CONVEYOR, CONVEYOR_SWITCH, EPB, EPB_CURVE, EPB_RAIL, EPB_RAIL_TYPES, EPB_SWITCH, EXIT_TYPES, FLOW_TYPES, LIFT, RBG,
    RBG_RAIL, SOURCE, STORAGE, Component,
)
from matflow.model.layout import Layout
from matflow.sim.tracks import RailNetwork, Track, build_tracks

ERROR, WARNING = "error", "warning"


@dataclass
class Issue:
    level: str
    msg: str
    cells: list[Cell] = field(default_factory=list)


@dataclass
class FlowNode:
    """Förderknoten (Fördertechnik-, Heber- oder Quellenzelle)."""
    comp: Component
    out: Cell | None = None          # Zielzelle in Pfeilrichtung (ggf. auf Zielebene)
    out_kind: str = "dead"          # flow | epb | rbg | exit | dead | invalid
    z: float = 0.0                  # Höhe am Mittelpunkt (Heber interpoliert)
    lift_chain: int = -1
    lift_index: int = 0
    lift_len: int = 0
    branches: list[Cell] = field(default_factory=list)   # FT-Weiche: gültige Abzweig-Zielzellen

    @property
    def cell(self) -> Cell:
        return self.comp.cell

    @property
    def type(self) -> str:
        return self.comp.type


@dataclass
class Handover:
    kind: str                        # epb_pick | epb_drop | rbg_pick | rbg_drop
    flow_cell: Cell                  # Förderzelle
    rail_cell: Cell                  # Schienenzelle
    track_id: int = -1               # EPB: Strecke der Schienenzelle
    system_id: int = -1              # RBG
    net_id: int = -1                 # EPB: Schienennetz


@dataclass
class StorageInfo:
    comp: Component
    rail_cell: Cell
    side: int                        # Richtung von der RBG-Schiene zum Lagerplatz
    system_id: int


@dataclass
class RbgSystem:
    """Eine RBG-Gasse. Übereinanderliegende RBG-Schienen gleicher Linie gehören zur selben Gasse:
    das RBG fährt dann auch zwischen den Ebenen (Hub), solange dort Schienen liegen."""
    id: int
    level: int                       # Grundebene (Ebene des RBG bzw. unterste Ebene)
    axis: int                        # 0 = Nord-Süd-Linie, 1 = Ost-West-Linie
    cells: list[Cell]                # geordnet entlang der Achse, dann nach Ebene
    vehicles: list[Component] = field(default_factory=list)
    storages: list[StorageInfo] = field(default_factory=list)
    pickups: list[Handover] = field(default_factory=list)
    drops: list[Handover] = field(default_factory=list)

    def coord(self, cell: Cell) -> float:
        """Achskoordinate des Zellmittelpunkts."""
        return center(cell)[1] if self.axis == 0 else center(cell)[0]

    def point(self, p: float, cell_ref: Cell | None = None) -> tuple[float, float]:
        ref = self.cells[0] if cell_ref is None else cell_ref
        cx, cy = center(ref)
        return (cx, p) if self.axis == 0 else (p, cy)

    @property
    def levels(self) -> list[int]:
        return sorted({c[2] for c in self.cells})

    @property
    def label(self) -> str:
        if self.vehicles:
            return self.vehicles[0].display_name
        return f"RBG-System {self.id + 1}"


@dataclass
class Topology:
    layout: Layout
    flow: dict[Cell, FlowNode] = field(default_factory=dict)
    tracks: list[Track] = field(default_factory=list)
    network: RailNetwork | None = None
    rail_track: dict[Cell, int] = field(default_factory=dict)       # Zelle → Strecke (Weiche: gerader Strang)
    epb_picks: dict[Cell, Handover] = field(default_factory=dict)      # Förderzelle → Übergabe
    epb_drops: list[Handover] = field(default_factory=list)
    rbg_systems: list[RbgSystem] = field(default_factory=list)
    rbg_cell_system: dict[Cell, int] = field(default_factory=dict)
    rbg_picks: dict[Cell, Handover] = field(default_factory=dict)
    rbg_drops: list[Handover] = field(default_factory=list)
    storages: dict[str, StorageInfo] = field(default_factory=dict)
    net_epbs: dict[int, list[Component]] = field(default_factory=dict)
    exits: dict[Cell, Component] = field(default_factory=dict)
    issues: list[Issue] = field(default_factory=list)

    def error(self, msg: str, cells: list[Cell] | None = None) -> None:
        self.issues.append(Issue(ERROR, msg, cells or []))

    def warn(self, msg: str, cells: list[Cell] | None = None) -> None:
        self.issues.append(Issue(WARNING, msg, cells or []))

    @property
    def sources(self) -> list[Component]:
        return self.layout.components(SOURCE)

    def track_of(self, cell: Cell) -> Track | None:
        tid = self.rail_track.get(cell)
        return None if tid is None else self.tracks[tid]

    def net_of(self, cell: Cell) -> int:
        tid = self.rail_track.get(cell)
        return -1 if tid is None else self.tracks[tid].net

    def rail_point(self, cell: Cell) -> tuple[int, float]:
        """(Strecke, s) des Mittelpunkts einer Schienenzelle."""
        tr = self.tracks[self.rail_track[cell]]
        return tr.id, tr.center_s(cell)

    def seg_len(self, a: Cell, b: Cell) -> float:
        ax, ay = center(a)
        bx, by = center(b)
        return max(1e-6, ((ax - bx) ** 2 + (ay - by) ** 2) ** 0.5)

    def connections(self) -> list[dict[str, Any]]:
        """Verbindungsliste (informativ, für die Projektdatei)."""
        out: list[dict[str, Any]] = []
        st = self.layout.static
        for c, fn in sorted(self.flow.items()):
            if fn.out is not None and fn.out_kind in ("flow", "epb", "rbg"):
                tgt = st.get(fn.out)
                out.append({"from": fn.comp.id, "to": tgt.id if tgt else None, "kind": fn.out_kind})
            for b in fn.branches:
                tgt = st.get(b)
                out.append({"from": fn.comp.id, "to": tgt.id if tgt else None, "kind": "flow"})
        for tr in self.tracks:
            for i, rc in enumerate(tr.cells):
                if i + 1 < len(tr.cells) or tr.closed:
                    nxt = tr.cells[(i + 1) % len(tr.cells)]
                    out.append({"from": rc.comp.id, "to": nxt.comp.id, "kind": "rail"})
            for sid in tr.succ:
                out.append({"from": tr.cells[-1].comp.id, "to": self.tracks[sid].cells[0].comp.id, "kind": "rail"})
        for d in self.epb_drops:
            out.append({"from": st[d.rail_cell].id, "to": st[d.flow_cell].id, "kind": "epb_drop"})
        for d in self.rbg_drops:
            out.append({"from": st[d.rail_cell].id, "to": st[d.flow_cell].id, "kind": "rbg_drop"})
        for s in self.storages.values():
            out.append({"from": st[s.rail_cell].id, "to": s.comp.id, "kind": "storage"})
        return out


def _accepts(target: Component, move_dir: int) -> bool:
    """Nimmt die Förderzelle target einen Behälter an, der sich in move_dir hineinbewegt?"""
    if target.type == CONVEYOR:
        return target.direction != opposite(move_dir)
    if target.type in (LIFT, CONVEYOR_SWITCH):
        return target.direction == move_dir
    if target.type in EXIT_TYPES:
        return True
    return False


def build_topology(layout: Layout) -> Topology:
    topo = Topology(layout)
    st = layout.static

    # ---------------------------------------------------------------- EPB-Strecken
    rails = {c: comp for c, comp in st.items() if comp.type in EPB_RAIL_TYPES}
    tracks, errs = build_tracks(rails)
    topo.tracks = tracks
    topo.network = RailNetwork(tracks)
    for msg, cells in errs:
        topo.error(msg, cells)
    for tr in tracks:
        for rc in tr.cells:
            if rc.link == 0:
                topo.rail_track[rc.cell] = tr.id
        topo.net_epbs.setdefault(tr.net, [])
    for v in layout.components(EPB):
        tid = topo.rail_track.get(v.cell)
        if tid is not None:
            topo.net_epbs[tracks[tid].net].append(v)

    # ---------------------------------------------------------------- Heberketten
    lift_cells = {c: comp for c, comp in st.items() if comp.type == LIFT}
    chain_id = 0
    seen: set[Cell] = set()

    def same_chain(a: Component, b: Component | None) -> bool:
        return (b is not None and b.type == LIFT and b.direction == a.direction
                and b.target_level == a.target_level and b.level == a.level)

    for c, comp in sorted(lift_cells.items()):
        if c in seen:
            continue
        # zum Kettenanfang laufen
        start = comp
        guard = {start.cell}
        while True:
            prev = st.get(neighbor(start.cell, opposite(start.direction)))
            if same_chain(start, prev) and prev.cell not in guard:
                start = prev
                guard.add(prev.cell)
            else:
                break
        chain = [start]
        while True:
            nxt = st.get(neighbor(chain[-1].cell, start.direction))
            if same_chain(start, nxt) and nxt not in chain:
                chain.append(nxt)
            else:
                break
        n = len(chain)
        for i, lc in enumerate(chain):
            seen.add(lc.cell)
            z = lc.level if n == 1 else lc.level + (lc.target_level - lc.level) * i / (n - 1)
            topo.flow[lc.cell] = FlowNode(lc, z=z, lift_chain=chain_id, lift_index=i, lift_len=n)
        chain_id += 1

    # ---------------------------------------------------------------- Förderknoten
    for c, comp in st.items():
        if comp.type in (CONVEYOR, CONVEYOR_SWITCH, SOURCE):
            topo.flow[c] = FlowNode(comp, z=float(comp.level))
        elif comp.type in EXIT_TYPES:
            topo.flow[c] = FlowNode(comp, out_kind="exit", z=float(comp.level))
            topo.exits[c] = comp

    for c, fn in topo.flow.items():
        if fn.out_kind == "exit":
            continue
        comp = fn.comp
        d = comp.direction
        nxt = neighbor(c, d)
        if comp.type == LIFT:
            same = st.get(nxt)
            if not (fn.lift_index < fn.lift_len - 1 and same_chain(comp, same)):
                nxt = (nxt[0], nxt[1], comp.target_level)
        fn.out = nxt
        tgt = st.get(nxt)
        if tgt is None:
            fn.out_kind = "dead"
            continue
        if tgt.type in FLOW_TYPES or tgt.type in EXIT_TYPES:
            if _accepts(tgt, d):
                fn.out_kind = "flow"
            else:
                fn.out_kind = "invalid"
                topo.error(f"{comp.id} kann nicht an {tgt.id} übergeben (Richtung passt nicht)", [c, nxt])
        elif tgt.type == EPB_RAIL:
            if is_perpendicular(d, tgt.direction):
                fn.out_kind = "epb"
                tid = topo.rail_track.get(nxt, -1)
                topo.epb_picks[c] = Handover("epb_pick", c, nxt, track_id=tid,
                                             net_id=tracks[tid].net if tid >= 0 else -1)
            else:
                fn.out_kind = "invalid"
                topo.error(f"{comp.id}: Übergabe an EPB-Schiene {tgt.id} nur seitlich (90° zur Fahrtrichtung)",
                           [c, nxt])
        elif tgt.type == EPB_CURVE:
            fn.out_kind = "invalid"
            topo.error(f"{comp.id}: Übergabe an Kurvenschiene {tgt.id} ist nicht möglich", [c, nxt])
        elif tgt.type == EPB_SWITCH:
            fn.out_kind = "invalid"
            topo.error(f"{comp.id}: Übergabe an Weiche {tgt.id} ist nicht möglich (nur an gerader Schiene)",
                       [c, nxt])
        elif tgt.type == RBG_RAIL:
            fn.out_kind = "rbg"
        elif tgt.type == STORAGE:
            fn.out_kind = "invalid"
            topo.error(f"{comp.id} fördert direkt in Lagerplatz {tgt.id} (nur über RBG möglich)", [c, nxt])
        else:
            fn.out_kind = "invalid"
            topo.error(f"{comp.id}: keine gültige Verbindung zu {tgt.id}", [c, nxt])

    # FT-Weiche: Abzweige übergeben nur an Fördertechnik, Heber, FT-Weiche oder Ausgang
    for c, fn in sorted(topo.flow.items()):
        if fn.type != CONVEYOR_SWITCH:
            continue
        for side in fn.comp.branch_sides():
            nxt = neighbor(c, side)
            tgt = st.get(nxt)
            if tgt is None:
                continue
            if (tgt.type in FLOW_TYPES or tgt.type in EXIT_TYPES) and _accepts(tgt, side):
                fn.branches.append(nxt)
            else:
                topo.error(f"{fn.comp.id}: Abzweig kann nur an Fördertechnik, Heber oder Ausgang übergeben "
                           f"(nicht an {tgt.id})", [c, nxt])

    # EPB-Abgabepunkte: Fördertechnik seitlich an gerader Schiene, Pfeil zeigt von ihr weg
    for c, fn in topo.flow.items():
        if fn.type != CONVEYOR:
            continue
        back = neighbor(c, opposite(fn.comp.direction))
        r = st.get(back)
        if r is not None and r.type == EPB_RAIL and is_perpendicular(fn.comp.direction, r.direction):
            tid = topo.rail_track.get(back, -1)
            topo.epb_drops.append(Handover("epb_drop", c, back, track_id=tid,
                                           net_id=tracks[tid].net if tid >= 0 else -1))
    topo.epb_drops.sort(key=lambda h: h.flow_cell)

    # ---------------------------------------------------------------- RBG-Systeme
    rbg_rails = {c: comp for c, comp in st.items() if comp.type == RBG_RAIL}
    assigned: set[Cell] = set()
    for c in sorted(rbg_rails, key=lambda k: (k[2], k[1], k[0])):
        if c in assigned:
            continue
        axis = rbg_rails[c].rbg_axis
        along = (0, 2) if axis == 0 else (1, 3)
        group = [c]
        assigned.add(c)
        stack = [c]
        while stack:
            cur = stack.pop()
            # entlang der Achse auf gleicher Ebene sowie direkt darüber/darunter (Hub zwischen Ebenen)
            nbrs = [neighbor(cur, d) for d in along] + [(cur[0], cur[1], cur[2] + 1), (cur[0], cur[1], cur[2] - 1)]
            for n in nbrs:
                if n in rbg_rails and n not in assigned and rbg_rails[n].rbg_axis == axis:
                    assigned.add(n)
                    group.append(n)
                    stack.append(n)
        group.sort(key=lambda k: ((k[1] if axis == 0 else k[0]), k[2]))
        sysm = RbgSystem(len(topo.rbg_systems), min(k[2] for k in group), axis, group)
        topo.rbg_systems.append(sysm)
        for g in group:
            topo.rbg_cell_system[g] = sysm.id
    # Nachbarn mit abweichender Achse
    for c, comp in rbg_rails.items():
        along = (0, 2) if comp.rbg_axis == 0 else (1, 3)
        for d in along:
            n = neighbor(c, d)
            if n in rbg_rails and rbg_rails[n].rbg_axis != comp.rbg_axis:
                topo.warn(f"RBG-Schienen {comp.id} und {rbg_rails[n].id} sind nicht verbunden "
                          f"(RBG-Schienen verlaufen nur gerade)", [c, n])
    for v in layout.components(RBG):
        sid = topo.rbg_cell_system.get(v.cell)
        if sid is not None:
            topo.rbg_systems[sid].vehicles.append(v)
            topo.rbg_systems[sid].level = topo.rbg_systems[sid].vehicles[0].level

    # Lagerplätze
    for comp in layout.components(STORAGE):
        cands = []
        for d in range(4):
            n = neighbor(comp.cell, d)
            r = st.get(n)
            if r is not None and r.type == RBG_RAIL:
                side = dir_between(n, comp.cell)
                lateral = (side % 2) != r.rbg_axis
                cands.append((lateral, n, side))
        lat = [cnd for cnd in cands if cnd[0]]
        if not lat:
            if cands:
                topo.error(f"{comp.id} liegt am Ende einer RBG-Schiene; Lagerplätze müssen seitlich liegen",
                           [comp.cell])
            else:
                topo.error(f"{comp.id} liegt nicht direkt neben einer RBG-Schiene", [comp.cell])
            continue
        if len(lat) > 1:
            topo.warn(f"{comp.id} grenzt an mehrere RBG-Schienen, verwendet wird {st[lat[0][1]].id}",
                      [comp.cell])
        _, rail, side = lat[0]
        sid = topo.rbg_cell_system[rail]
        info = StorageInfo(comp, rail, side, sid)
        topo.storages[comp.id] = info
        topo.rbg_systems[sid].storages.append(info)

    # RBG-Aufnahmepunkte
    for c, fn in topo.flow.items():
        if fn.out_kind == "rbg" and fn.out is not None:
            sid = topo.rbg_cell_system[fn.out]
            h = Handover("rbg_pick", c, fn.out, system_id=sid)
            topo.rbg_picks[c] = h
            topo.rbg_systems[sid].pickups.append(h)
    # RBG-Abgabepunkte (Auslagerung): Fördertechnik oder FT-Weiche direkt neben einer RBG-Schiene,
    # kein Ausgang zeigt in die Schiene (hinten oder seitlich, z. B. parallel neben dem Gassenende)
    for c, fn in sorted(topo.flow.items()):
        if fn.out_kind == "rbg":
            continue
        for rail in rbg_drop_rails(fn.comp, st):
            sid = topo.rbg_cell_system.get(rail)
            if sid is None or any(h.flow_cell == c for h in topo.rbg_systems[sid].drops):
                continue
            h = Handover("rbg_drop", c, rail, system_id=sid)
            topo.rbg_drops.append(h)
            topo.rbg_systems[sid].drops.append(h)
    return topo


def rbg_drop_rails(comp: Component, static: dict[Cell, Component]) -> list[Cell]:
    """RBG-Schienenzellen, von denen ein RBG an diese Förderzelle abgeben kann (hinten zuerst)."""
    if comp.type not in (CONVEYOR, CONVEYOR_SWITCH):
        return []
    d = comp.direction
    outs = comp.flow_outputs()
    out = []
    for s in (opposite(d), (d + 1) % 4, (d + 3) % 4):
        if s in outs:
            continue
        n = neighbor(comp.cell, s)
        r = static.get(n)
        if r is not None and r.type == RBG_RAIL:
            out.append(n)
    return out


__all__ = ["build_topology", "rbg_drop_rails", "Topology", "FlowNode", "Handover", "RbgSystem", "StorageInfo", "Issue",
           "ERROR", "WARNING", "DVEC"]
