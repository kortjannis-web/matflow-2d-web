"""Layoutprüfung vor dem Simulationsstart."""
from __future__ import annotations

from dataclasses import dataclass, field

from matflow.core.geometry import Cell
from matflow.model.components import CONVEYOR_SWITCH, EPB, LIFT, NIO, RBG, SINK, SOURCE, STORAGE
from matflow.model.layout import Layout
from matflow.sim.routing import EpbLeg, Route, Router
from matflow.sim.topology import ERROR, WARNING, Issue, Topology, build_topology


@dataclass
class ValidationResult:
    topo: Topology
    issues: list[Issue] = field(default_factory=list)

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.level == ERROR]

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.level == WARNING]

    @property
    def ok(self) -> bool:
        return not self.errors

    def cells(self, level: str | None = None) -> set[Cell]:
        return {c for i in self.issues if level is None or i.level == level for c in i.cells}


def validate(layout: Layout) -> ValidationResult:
    topo = build_topology(layout)
    res = ValidationResult(topo, list(topo.issues))

    def err(msg: str, cells: list[Cell] | None = None) -> None:
        res.issues.append(Issue(ERROR, msg, cells or []))

    def warn(msg: str, cells: list[Cell] | None = None) -> None:
        res.issues.append(Issue(WARNING, msg, cells or []))

    p = layout.params
    sources = layout.components(SOURCE)
    storages = layout.components(STORAGE)
    if not sources:
        err("Es gibt keine Behälterquelle")
    if not storages:
        err("Es gibt keinen Lagerplatz")

    # Heber
    for c in layout.components(LIFT):
        if not 0 <= c.target_level < layout.levels:
            err(f"{c.id}: Zielebene E{c.target_level} existiert nicht", [c.cell])
    for c, fn in topo.flow.items():
        if fn.type == CONVEYOR_SWITCH and not fn.branches:
            warn(f"{fn.comp.id}: Abzweig der FT-Weiche hat keinen Anschluss", [c])
        if fn.out_kind == "dead" and fn.type != SOURCE and not fn.branches:
            warn(f"{fn.comp.id}: Förderstrecke endet ohne Anschluss (Behälter bleiben dort stehen)", [c])
        if fn.type == SOURCE and fn.out_kind == "dead":
            err(f"{fn.comp.id}: Quelle hat keinen Anschluss in Pfeilrichtung", [c])

    # EPB-Strecken und -Netze
    net = topo.network
    for tr in topo.tracks:
        cells = [rc.cell for rc in tr.cells]
        if not tr.closed and not tr.succ and tr.switch_id is None and len(tr.cells) > 1:
            warn(f"EPB-Strecke ab {tr.cells[0].comp.id} endet ohne Anschluss; EPBs halten am Ende",
                 [cells[0], cells[-1]])
        if tr.switch_id is not None and (not tr.succ or not tr.pred):
            side = "Ausfahrt" if not tr.succ else "Einfahrt"
            kind = "gerader Strang" if tr.cells[0].link == 0 else "Abzweig"
            warn(f"Weiche {tr.switch_id}: {kind} hat keinen Anschluss ({side})", cells)
        if tr.closed:
            epbs = [v for v in topo.net_epbs.get(tr.net, []) if topo.rail_track.get(v.cell) == tr.id]
            if epbs and len(epbs) * p.epb_min_distance >= tr.length - 1e-6:
                err(f"Zu viele EPBs für den Ring ab {tr.cells[0].comp.id} ({tr.length:.1f} m)", cells)
    for nid, comps in topo.net_epbs.items():
        pts = [(v, topo.rail_point(v.cell)) for v in comps]
        bad: set = set()
        for i in range(len(pts)):
            for j in range(i + 1, len(pts)):
                (va, (ta, sa)), (vb, (tb, sb)) = pts[i], pts[j]
                d = min(net.path_dist(ta, sa, tb, sb), net.path_dist(tb, sb, ta, sa))
                if d < p.epb_min_distance - 1e-6:
                    bad |= {va.cell, vb.cell}
        if bad:
            err(f"EPBs stehen zu dicht (Mindestabstand {p.epb_min_distance:g} m entlang der Schiene)", sorted(bad))
    for v in layout.components(EPB):
        if v.cell not in topo.rail_track:
            err(f"{v.id} steht nicht auf einer EPB-Schiene", [v.cell])

    # RBG
    for sysm in topo.rbg_systems:
        cells = list(sysm.cells)
        if len(sysm.vehicles) > 1:
            err(f"{sysm.label}: mehr als ein RBG in derselben RBG-Gasse (ein RBG bedient alle Ebenen "
                f"übereinanderliegender RBG-Schienen)", [v.cell for v in sysm.vehicles])
        if not sysm.vehicles and (sysm.storages or sysm.pickups):
            err(f"RBG-Schiene ab {layout.static[cells[0]].id} hat kein RBG", cells)
        if sysm.pickups and not sysm.storages:
            warn(f"{sysm.label}: RBG-Schiene ohne Lagerplätze", cells)
        if sysm.storages and not sysm.pickups:
            warn(f"{sysm.label}: keine Fördertechnik liefert an dieses RBG", cells)

    # Wege von den Quellen
    router = Router(topo, p)
    reachable: set[int] = set()
    for s in sources:
        if s.cell not in topo.flow:
            continue
        systems = router.reachable_systems(s.cell)
        systems = {sid for sid in systems if topo.rbg_systems[sid].storages}
        if not systems:
            err(f"Von {s.display_name} gibt es keinen gültigen Transportweg zu einem Lagerplatz", [s.cell])
            continue
        reachable |= systems
        _epb_check(topo, router.find(s.cell), err, s.display_name)
    unreach = [info.comp.cell for sysm in topo.rbg_systems if sysm.id not in reachable
               for info in sysm.storages]
    if unreach and sources:
        warn(f"{len(unreach)} Lagerplätze sind von keiner Quelle erreichbar", unreach)
    if storages and all(c.prefilled for c in storages) and p.retrieval_rate <= 0:
        warn("Alle Lagerplätze sind bereits vorbelegt; die Simulation endet sofort")
    # NIO-Ausgang und Auslagerung
    for c, comp in topo.exits.items():
        fed = any((fn.out == c and fn.out_kind == "flow") or c in fn.branches for fn in topo.flow.values())
        if not fed:
            warn(f"{comp.display_name}: keine Fördertechnik führt in diesen Ausgang", [c])
    if p.nio_rate > 0:
        nio_ok = [s for s in sources if s.cell in topo.flow and router.find_exit(s.cell, NIO) is not None]
        if not nio_ok:
            warn("NIO-Anteil ist eingestellt, aber von keiner Quelle führt ein Weg zu einem NIO-Ausgang "
                 "(NIO-Behälter werden normal eingelagert)")
        else:
            _epb_check(topo, router.find_exit(nio_ok[0].cell, NIO), err, nio_ok[0].display_name)
    if p.retrieval_rate > 0:
        any_out = False
        for sysm in topo.rbg_systems:
            if not sysm.storages:
                continue
            routes = [router.find_exit(h.flow_cell, SINK) for h in sysm.drops]
            routes = [r for r in routes if r is not None]
            if routes:
                any_out = True
                _epb_check(topo, routes[0], err, sysm.label)
            elif sysm.drops:
                warn(f"{sysm.label}: RBG-Abgabe vorhanden, aber kein Weg zu einem Ausgang",
                     [h.flow_cell for h in sysm.drops])
        if not any_out:
            warn("Auslagerrate ist eingestellt, aber kein RBG hat eine Abgabe mit Weg zu einem Ausgang "
                 "(RBG-Abgabe = Fördertechnik direkt neben der RBG-Schiene, Pfeil zeigt nicht in die Schiene)")
    if not layout.components(EPB) and topo.epb_picks:
        err("Es gibt EPB-Übergabepunkte, aber keine EPB")
    if not layout.components(RBG) and storages:
        err("Es gibt Lagerplätze, aber kein RBG")
    return res


def _epb_check(topo: Topology, route: Route | None, err, name: str) -> None:
    if route is None:
        return
    for leg in route.legs:
        if isinstance(leg, EpbLeg) and not topo.net_epbs.get(leg.net_id):
            err(f"Der Weg von {name} braucht eine EPB, aber auf dem Schienennetz steht keine", [leg.pick_rail])
