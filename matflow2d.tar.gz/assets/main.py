import asyncio

import pygame  # noqa: F401  (pygbag lädt nur Pakete, die main.py direkt importiert)

from matflow.ui.app import App


async def main():
    await App().run_async()


asyncio.run(main())
